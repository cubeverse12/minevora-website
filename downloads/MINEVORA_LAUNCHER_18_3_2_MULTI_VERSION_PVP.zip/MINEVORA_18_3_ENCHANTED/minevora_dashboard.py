"""MINEVORA 14: Native Enchanted start screen, shared with functional launcher pages.
Every CTA is a real Qt button wired to the existing launcher API.
"""
from pathlib import Path
from PySide6.QtCore import Qt, QRectF
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPixmap, QLinearGradient, QBrush, QPen
from PySide6.QtWidgets import (QWidget,QScrollArea,QVBoxLayout,QHBoxLayout,QGridLayout,
                              QLabel,QPushButton,QFrame,QSizePolicy)

BASE=Path(__file__).resolve().parent
ASSETS=BASE/'assets'

class ArtPanel(QFrame):
    def __init__(self, filename, parent=None):
        super().__init__(parent)
        self.pixmap=QPixmap(str(ASSETS/filename))
        self.setAttribute(Qt.WA_StyledBackground,False)

    def paintEvent(self,event):
        p=QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        r=QRectF(self.rect()).adjusted(1.5,1.5,-2,-2)
        clip=QPainterPath();clip.addRoundedRect(r,15,15)
        p.setClipPath(clip)
        p.fillRect(r,QColor('#141b38'))
        if not self.pixmap.isNull():
            ow,oh=self.pixmap.width(),self.pixmap.height()
            sw,sh=r.width(),r.height()
            aspect=max(sw/ow,sh/oh)  # cover, preserving source aspect ratio
            nw,nh=ow*aspect,oh*aspect
            p.drawPixmap(QRectF(r.x()+(sw-nw)/2,r.y()+(sh-nh)/2,nw,nh),self.pixmap,QRectF(self.pixmap.rect()))
        gradient=QLinearGradient(r.left(),r.top(),r.left(),r.bottom())
        gradient.setColorAt(0,QColor(6,12,34,188))
        gradient.setColorAt(.40,QColor(10,12,35,55))
        gradient.setColorAt(1,QColor(7,11,32,247))
        p.fillPath(clip,QBrush(gradient))
        p.setClipping(False)
        p.setPen(QPen(QColor('#a55cfc'),1.7))
        p.drawRoundedRect(r,15,15)
        p.end()


def title(text, px=18, muted=False):
    w=QLabel(text)
    w.setWordWrap(True)
    w.setStyleSheet('background:transparent;color:'+('#bdbee2' if muted else '#ffffff')+
                    ';font-size:'+str(px)+'px;font-weight:'+('500' if muted else '800')+';')
    return w


def action(caption, callback, primary=True):
    b=QPushButton(caption)
    b.setObjectName('primary' if primary else 'enchantedOutline')
    b.setCursor(Qt.PointingHandCursor)
    b.setFocusPolicy(Qt.StrongFocus)
    b.setAccessibleName(caption)
    b.clicked.connect(callback)
    return b

class FeatureCard(ArtPanel):
    def __init__(self, symbol, name, tagline, image, callback, parent=None):
        super().__init__('en_'+image+'.jpg',parent)
        self.setObjectName('featureCard')
        self.setMinimumHeight(191)
        self.setMinimumWidth(176)
        layout=QVBoxLayout(self)
        layout.setContentsMargins(14,13,14,12)
        layout.setSpacing(4)
        head=QHBoxLayout()
        symbol_label=title(symbol,25);head.addWidget(symbol_label)
        head.addStretch()
        layout.addLayout(head)
        layout.addStretch(1)
        layout.addWidget(title(name,15))
        caption=title(tagline,11,True)
        caption.setMaximumHeight(36)
        layout.addWidget(caption)
        go=action('Otwórz  →',callback,primary=False)
        go.setMinimumHeight(31)
        layout.addWidget(go)

class EnchantedDashboard(QScrollArea):
    SECTIONS=(
      ('▶','GRAJ / WERSJE','Instalacje Minecraft','versions','instances'),
      ('✦','MODY I DODATKI','Modrinth i shadery','mods','mods'),
      ('🎮','MINIGRY','9 trybów MINEVORA','minigames','minigames'),
      ('▣','MARKETPLACE','Mapy i dodatki','marketplace','market'),
      ('🏆','RANKING','Statystyki graczy','ranking','leaderboard'),
      ('◉','DISCORD','Dołącz do społeczności','discord','discord_page'),
      ('⚙','USTAWIENIA','Dostosuj launcher','settings','settings'),
      ('♡','TOGETHER','Graj ze znajomymi','together','together'),
      ('⚔','PVP HUD','Instalacja i konfiguracja','pvp','pvp_mod_menu'),
    )
    def __init__(self, launcher, parent=None):
        super().__init__(parent)
        self.launcher=launcher
        self.setObjectName('enchantedDashboard')
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        content=QWidget();content.setObjectName('dashboardBody')
        self.setWidget(content)
        self.content=content
        self.root=QVBoxLayout(content)
        self.root.setContentsMargins(20,14,20,16)
        self.root.setSpacing(12)
        hero=ArtPanel('enchanted_hero.jpg')
        hero.setObjectName('dashboardHero')
        hero.setMinimumHeight(226)
        hero.setMaximumHeight(320)
        hero_layout=QVBoxLayout(hero)
        hero_layout.setContentsMargins(24,21,22,20)
        hero_layout.setSpacing(6)
        hero_layout.addWidget(title('✦  THE ENCHANTED LAUNCHER  •  18.3',11))
        hero_layout.addWidget(title('TWÓJ ŚWIAT MINECRAFT.\nTWOJE ZASADY.',30))
        hero_layout.addWidget(title('Profile, mody i PvP HUD w jednym miejscu — ten sam styl co na stronie WWW.',12,True))
        hero_layout.addStretch(1)
        buttons=QHBoxLayout()
        buttons.setSpacing(8)
        buttons.addWidget(action('▶  GRAJ W MINECRAFT',launcher.play,True))
        buttons.addWidget(action('↓  Wybierz wersję',launcher.instances,False))
        buttons.addWidget(action('⚔  PvP HUD',launcher.pvp_mod_menu,False))
        buttons.addStretch(1)
        hero_layout.addLayout(buttons)
        self.root.addWidget(hero)
        release_row=QFrame();release_row.setObjectName('newsCard')
        release_layout=QHBoxLayout(release_row)
        release_layout.addWidget(title('✦  NOWOŚĆ 18.3  •  WSPÓLNY MOTYW STRONY I LAUNCHERA',12))
        release_layout.addStretch(1)
        release_layout.addWidget(action('Co nowego →',launcher.release_notes,False))
        self.root.addWidget(release_row)
        section=QHBoxLayout()
        section.addWidget(title('ODKRYJ MINEVORA',19))
        section.addStretch(1)
        section.addWidget(title('Wszystkie funkcje • jeden styl',11,True))
        self.root.addLayout(section)
        self.grid=QGridLayout()
        self.grid.setSpacing(10)
        self.cards=[]
        for icon,name,subtitle,image,method in self.SECTIONS:
            c=FeatureCard(icon,name,subtitle,image,getattr(launcher,method),content)
            self.cards.append(c)
        self.root.addLayout(self.grid)
        bottom=QFrame();bottom.setObjectName('panel')
        row=QHBoxLayout(bottom)
        row.setContentsMargins(16,9,16,9)
        label=title('KONTO • MICROSOFT',11)
        row.addWidget(label)
        self.account_label=title('Niepołączone',12,True)
        row.addWidget(self.account_label)
        row.addStretch(1)
        row.addWidget(action('Zaloguj',launcher.login,False))
        row.addWidget(action('Minigry',launcher.minigames,True))
        self.root.addWidget(bottom)
        self.root.addStretch(1)
        self._columns=0
        self._arrange(4)

    def _arrange(self,cols):
        if cols==self._columns:return
        self._columns=cols
        for c in self.cards:
            self.grid.removeWidget(c)
        for i,c in enumerate(self.cards):
            self.grid.addWidget(c,i//cols,i%cols)
        for i in range(4):
            self.grid.setColumnStretch(i,1 if i<cols else 0)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        width=self.viewport().width()
        self._arrange(4 if width>=1040 else 3 if width>=710 else 2 if width>=440 else 1)

    def update_state(self):
        session=getattr(self.launcher,'session',None)
        logged=isinstance(session,dict) and bool(session.get('access_token'))
        self.account_label.setText(str(session.get('name',''))[:30] if logged else 'Niepołączone')
