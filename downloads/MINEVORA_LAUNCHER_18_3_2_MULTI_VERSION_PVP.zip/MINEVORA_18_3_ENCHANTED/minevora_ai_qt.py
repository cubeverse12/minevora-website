"""MINEVORA AI support chat: offline knowledge base + opt-in configured backend."""
from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QTextEdit, QLineEdit, QPushButton, QCheckBox,
                               QMessageBox)
from minevora_ai_core import backend_url, offline_reply, ask_backend

class AIWorker(QThread):
    finished_answer = Signal(str)
    failed = Signal(str)
    def __init__(self, question, lang):
        super().__init__(); self.question = question; self.lang = lang
    def run(self):
        try: self.finished_answer.emit(ask_backend(self.question,self.lang))
        except Exception as exc: self.failed.emit(str(exc)[:300])

class MinevoraAIPanel(QWidget):
    def __init__(self, language_getter, parent=None):
        super().__init__(parent)
        self.language_getter=language_getter
        self.worker=None
        root=QVBoxLayout(self);root.setContentsMargins(30,25,30,25);root.setSpacing(14)
        heading=QLabel('✧  MINEVORA AI — ASYSTENT LAUNCHERA')
        heading.setStyleSheet('font-size:24px;font-weight:800;color:#e9d5ff')
        root.addWidget(heading)
        info=QLabel('Pomoc przy instalacji, modach, PvP, Marketplace, rangach i Discordzie.\nOffline: odpowiedzi z bazy porad. AI online: opcjonalny prywatny backend API.')
        info.setWordWrap(True);info.setStyleSheet('color:#bdbbd6');root.addWidget(info)
        self.mode=QLabel('');root.addWidget(self.mode)
        self.transcript=QTextEdit();self.transcript.setReadOnly(True);self.transcript.setMinimumHeight(260)
        self.transcript.setStyleSheet('QTextEdit{background:#111b31;border:1px solid #5e548e;border-radius:14px;padding:13px}')
        root.addWidget(self.transcript,1)
        self.online=QCheckBox('Wyślij moje pytanie do skonfigurowanego prywatnego serwera AI (online)')
        self.online.setChecked(False);self.online.setEnabled(bool(backend_url()))
        root.addWidget(self.online)
        safe=QLabel('Nie wpisuj haseł, tokenów Microsoft/Discord ani danych osobowych. W trybie online treść pytania trafia do skonfigurowanej usługi.')
        safe.setWordWrap(True);safe.setStyleSheet('color:#b8b0c5');root.addWidget(safe)
        r=QHBoxLayout()
        self.input=QLineEdit();self.input.setPlaceholderText('Napisz pytanie o MINEVORA…')
        self.input.setMaxLength(2500);self.input.returnPressed.connect(self.send)
        r.addWidget(self.input,1)
        self.send_btn=QPushButton('Wyślij ➜');self.send_btn.clicked.connect(self.send);r.addWidget(self.send_btn)
        root.addLayout(r)
        examples=QHBoxLayout()
        for label,question in [('Mody','Jak zaktualizować mody?'),('XP ×2','Jak aktywować bonus XP?'),('Tickety','Jak zgłosić problem na Discordzie?')]:
            button=QPushButton(label)
            button.clicked.connect(lambda checked=False,q=question:self.example(q))
            examples.addWidget(button)
        root.addLayout(examples)
        self.refresh_mode()
    def example(self, question):
        self.input.setText(question);self.send()
    def refresh_mode(self):
        enabled=bool(backend_url());self.online.setEnabled(enabled)
        if not enabled:self.online.setChecked(False)
        self.mode.setText('● Pomoc offline dostępna' + ('  ·  prywatny backend AI skonfigurowany' if enabled else '  ·  AI online niepodłączone'))
    def _append(self,speaker,message):
        self.transcript.moveCursor(QTextCursor.End)
        self.transcript.insertPlainText(f'{speaker}: {message}\n\n')
    def send(self):
        question=self.input.text().strip()
        if not question:return
        self.input.clear();self._append('TY',question)
        lang=self.language_getter()
        if not self.online.isChecked():
            self._append('MINEVORA',offline_reply(question,lang));return
        self.send_btn.setEnabled(False);self.input.setEnabled(False)
        self.worker=AIWorker(question,lang)
        self.worker.finished_answer.connect(self._done)
        self.worker.failed.connect(self._error)
        self.worker.finished.connect(lambda:self.send_btn.setEnabled(True))
        self.worker.finished.connect(lambda:self.input.setEnabled(True))
        self.worker.start()
    def _done(self,answer):self._append('MINEVORA AI',answer)
    def _error(self,message):self._append('MINEVORA',f'Połączenie AI nie powiodło się: {message}')
