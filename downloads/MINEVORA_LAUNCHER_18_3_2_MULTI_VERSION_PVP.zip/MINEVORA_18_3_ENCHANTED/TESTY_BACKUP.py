"""Testy bez GUI i bez ingerencji w prawdziwe dane."""
import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from minevora_backup_core import (create_backup, restore_backup, roots, validate_backup, is_private_name, _check_archive_path)


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.home = self.root / 'home'
        self.appdata = self.root / 'appdata'
        self.base = self.root / 'minevora_app'
        self.env = roots(self.base, self.home, self.appdata)
        self.base.mkdir()
        (self.base / 'minevora_qt.py').write_text('print("MINEVORA")')
        (self.base / 'MINEVORA_BACKUP_RESTORE.py').write_text('print("backup")')
        minevora = self.env['minevora']
        minevora.mkdir(parents=True)
        (minevora / 'market_demo.json').write_text('{"mvc":450}')
        (minevora / 'auth_token.json').write_text('PRIVATE')
        (minevora / 'profiles.json').write_text('[{"name":"Test"}]')
        (self.env['appconfig']).mkdir(parents=True)
        (self.env['appconfig'] / 'config.json').write_text(json.dumps({'client_id':'12345678-1234-1234-1234-123456789abc', 'refresh_token':'TOP_SECRET'}))
        mc = self.env['minecraft']
        (mc / 'saves' / 'world').mkdir(parents=True)
        (mc / 'saves' / 'world' / 'level.dat').write_bytes(b'world data')
        (mc / 'libraries').mkdir()
        (mc / 'libraries' / 'huge.dat').write_bytes(b'skip')
        (mc / 'launcher_accounts.json').write_text('PRIVATE')
        self.archive = self.root / 'MINEVORA_KOPIA_TEST.minevora-backup.zip'

    def tearDown(self):
        self.tmp.cleanup()

    def backup(self):
        return create_backup(self.archive, {'launcher':True,'minevora':True,'minecraft':True,'minecraft_full':False,'config':True,'projects':[]}, self.env)

    def test_backup_manifest_and_sanitization(self):
        self.backup()
        manifest = validate_backup(self.archive)
        paths = {f['path'] for f in manifest['files']}
        self.assertIn('launcher/MINEVORA_BACKUP_RESTORE.py', paths)
        self.assertIn('minecraft/saves/world/level.dat', paths)
        self.assertIn('minevora/market_demo.json', paths)
        self.assertIn('appconfig/config.json', paths)
        self.assertNotIn('minecraft/libraries/huge.dat', paths)
        self.assertNotIn('minecraft/launcher_accounts.json', paths)
        self.assertNotIn('minevora/auth_token.json', paths)
        with zipfile.ZipFile(self.archive) as z:
            self.assertNotIn(b'TOP_SECRET', z.read('appconfig/config.json'))

    def test_restores_to_new_roots(self):
        self.backup()
        env2 = roots(self.root/'newlauncher', self.root/'newhome', self.root/'newappdata')
        output = restore_backup(self.archive, env2)
        self.assertGreater(output['restored'], 3)
        self.assertEqual((env2['minevora']/'market_demo.json').read_text(), '{"mvc":450}')
        self.assertEqual((env2['minecraft']/'saves/world/level.dat').read_bytes(), b'world data')
        self.assertTrue((env2['launcher']/'MINEVORA_BACKUP_RESTORE.py').is_file())

    def test_existing_file_skipped(self):
        self.backup()
        env2 = roots(self.root/'newlauncher', self.root/'newhome', self.root/'newappdata')
        env2['minevora'].mkdir(parents=True)
        (env2['minevora']/'market_demo.json').write_text('EXISTING')
        output = restore_backup(self.archive, env2, overwrite=False)
        self.assertGreater(output['skipped'],0)
        self.assertEqual((env2['minevora']/'market_demo.json').read_text(), 'EXISTING')

    def test_tamper_detection(self):
        self.backup()
        corrupted = self.root/'corrupt.zip'
        with zipfile.ZipFile(self.archive) as z, zipfile.ZipFile(corrupted,'w') as w:
            for n in z.namelist():
                value = z.read(n)
                if n == 'minevora/market_demo.json': value = b'X' * len(value)
                w.writestr(n, value)
        env2 = roots(self.root/'newlauncher', self.root/'newhome', self.root/'newappdata')
        with self.assertRaises(ValueError):
            restore_backup(corrupted, env2)
        self.assertFalse((env2['minevora']/'market_demo.json').exists())

    def test_prevent_traversal(self):
        for path in ('launcher/../../out.txt','minevora/../out.txt','launcher/C:\\temp','/absolute.txt','appconfig/secret.json'):
            with self.assertRaises(ValueError):
                _check_archive_path(path)

    def test_extra_projects(self):
        extra = self.root/'models'
        extra.mkdir()
        (extra/'house.bbmodel').write_text('{"elements":[]}')
        create_backup(self.archive,{'launcher':False,'minevora':False,'minecraft':False,'config':False,'projects':[str(extra)]},self.env)
        env2 = roots(self.root/'newlauncher', self.root/'newhome', self.root/'newappdata')
        restore_backup(self.archive,env2)
        self.assertTrue((env2['projects']/'01_models'/'house.bbmodel').exists())

    def test_overwrite_creates_rescue_copy(self):
        self.backup()
        env2 = roots(self.root/'newlauncher', self.root/'newhome', self.root/'newappdata')
        env2['minevora'].mkdir(parents=True)
        old = env2['minevora']/'market_demo.json'
        old.write_text('OLD')
        with patch('minevora_backup_core.Path.home', return_value=self.root/'newhome'):
            output = restore_backup(self.archive, env2, overwrite=True)
        self.assertEqual(old.read_text(), '{\"mvc\":450}')
        self.assertTrue(Path(output['safety_folder']).exists())
        backups = list(Path(output['safety_folder']).rglob('market_demo.json'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_text(), 'OLD')

    def test_known_private_names(self):
        self.assertTrue(is_private_name('microsoft_refresh_token.json'))
        self.assertTrue(is_private_name('launcher_accounts.json'))
        self.assertFalse(is_private_name('MINEVORA_BACKUP_RESTORE.py'))


if __name__=='__main__': unittest.main(verbosity=2)
