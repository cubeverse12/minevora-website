"""Minecraft Java 64x64 skin cuboids and UV coordinates.

Single source of truth shared by the launcher 3D renderer and its regression tests.
The same 6 face layout is used by MINEVORA WEB 17.6 (avatar-preview.js).
Face order: front, character-right (-X), character-left (+X), back, top, bottom.
All atlas rectangles are (x, y, width, height), in native skin pixels.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class SkinPart:
    name: str
    x: float
    y: float
    z: float
    width: int
    height: int
    depth: int
    base_uv: tuple
    overlay_uv: tuple


def face_uvs(u: int, v: int, w: int, h: int, d: int) -> tuple:
    """Return official Java skin box atlas faces matching MINEVORA website."""
    return (
        (u+d, v+d, w, h),         # front
        (u, v+d, d, h),           # character right (negative X)
        (u+d+w, v+d, d, h),       # character left (positive X)
        (u+2*d+w, v+d, w, h),     # back
        (u+d, v, w, d),           # top
        (u+d+w, v, w, d),         # bottom
    )


# name, x,y,z, width,height,depth, base atlas (u,v), second layer atlas (u,v)
# Head MUST be a full 8x8x8 cube (older versions incorrectly used depth=4).
_SPECS = (
    ('head', -4,-16,-4, 8,8,8, 0,0, 32,0),
    ('body', -4,-8,-2, 8,12,4, 16,16, 16,32),
    ('right_arm', -8,-8,-2, 4,12,4, 40,16, 40,32),
    ('left_arm', 4,-8,-2, 4,12,4, 32,48, 48,48),
    ('right_leg', -4,4,-2, 4,12,4, 0,16, 0,32),
    ('left_leg', 0,4,-2, 4,12,4, 16,48, 0,48),
)


def model_parts(slim: bool=False) -> tuple:
    """Generate Steve or Alex geometry; both are real solid 3D cuboids."""
    result=[]
    for name, x,y,z,w,h,d, u,v, ou,ov in _SPECS:
        if slim and name.endswith('_arm'):
            w=3
            # Keep arm aligned at the shoulder rather than moving the whole limb.
            if name=='right_arm': x=-7
        result.append(SkinPart(name,x,y,z,w,h,d,
                               face_uvs(u,v,w,h,d),face_uvs(ou,ov,w,h,d)))
    return tuple(result)


def validate_skin_uv(slim: bool=False) -> None:
    """Raise if any of the 72 atlas rectangles lies outside a 64x64 PNG."""
    parts=model_parts(slim)
    assert len(parts)==6
    for part in parts:
        assert part.width > 0 and part.height > 0 and part.depth > 0
        for uvset in (part.base_uv,part.overlay_uv):
            assert len(uvset)==6
            for x,y,w,h in uvset:
                if not (0<=x<64 and 0<=y<64 and w>0 and h>0 and x+w<=64 and y+h<=64):
                    raise ValueError(f'Invalid UV for {part.name}: {(x,y,w,h)}')
