"""MINEVORA Chat Plus 10.3: skin heads, flags and server-authorized Guard Bot moderation."""
import json
import re
import urllib.error
import urllib.request
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal, QUrl, QSize
from PySide6.QtGui import QPixmap, QFont, QCursor
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtWidgets import (QWidget,QFrame,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QLineEdit,QComboBox,QDialog,QDialogButtonBox,QFormLayout,QCheckBox,QScrollArea,
    QInputDialog,QMessageBox,QMenu,QListWidget,QAbstractItemView,QSpinBox,QPlainTextEdit)

CHAT_CONFIG=Path.home()/'.minevora'/'chat_settings.json'
FLAGS={'Polska':'🇵🇱','Niemcy':'🇩🇪','Wielka Brytania':'🇬🇧','USA':'🇺🇸','Ukraina':'🇺🇦','Francja':'🇫🇷','Hiszpania':'🇪🇸','Inny':'🌍'}

class ChatHTTP(QThread):
    success=Signal(object)
    failure=Signal(str)
    def __init__(self,url,data=None,token=''):
        super().__init__()
        self.url=url;self.data=data;self.token=token
    def run(self):
        try:
            body=json.dumps(self.data,ensure_ascii=False).encode('utf-8') if self.data is not None else None
            headers={'Content-Type':'application/json','User-Agent':'MINEVORA-ChatPlus/10.3'}
            if self.token:headers['Authorization']='Bearer '+self.token
            request=urllib.request.Request(self.url,body,headers=headers,method='POST' if body is not None else 'GET')
            with urllib.request.urlopen(request,timeout=6) as response:
                data=json.loads(response.read(256_000).decode('utf-8'))
            if not isinstance(data,dict):raise ValueError('Nieprawidłowa odpowiedź serwera')
            self.success.emit(data)
        except urllib.error.HTTPError as exc:
            try:
                error=json.loads(exc.read(4096).decode('utf-8')).get('error',str(exc))
            except (ValueError,UnicodeError):error=str(exc)
            self.failure.emit(str(error))
        except Exception as exc:self.failure.emit(str(exc))

class ChatPlus(QFrame):
    stats=Signal(int,int,object)
    def __init__(self,parent=None):
        super().__init__(parent)
        try:self.config=json.loads(CHAT_CONFIG.read_text(encoding='utf-8'))
        except (OSError,ValueError,TypeError):self.config={}
        if not isinstance(self.config,dict):self.config={}
        self.config.setdefault('server','http://127.0.0.1:8766')
        self.config.setdefault('country','Polska')
        self.config.setdefault('skin_heads',False)
        self.token='';self.busy=False;self.workers=[];self.fingerprint=None
        self.avatar_cache={};self.avatar_pending=set();self.avatar_labels={}
        self.avatar_network=QNetworkAccessManager(self)
        self.setObjectName('chatSidebar')
        root=QVBoxLayout(self);root.setContentsMargins(10,13,10,12);root.setSpacing(8)
        title=QLabel('💬  MINEVORA CHAT');title.setStyleSheet('font-size:17px;font-weight:800;color:#f1e4ff');root.addWidget(title)
        sub=QLabel('Społeczność • główki Minecraft • flagi');sub.setStyleSheet('color:#adbde2;font-size:11px');root.addWidget(sub)
        bar=QHBoxLayout();bar.setSpacing(5)
        self.profile_button=QPushButton('⚙ Profil');self.profile_button.clicked.connect(self.edit_profile);bar.addWidget(self.profile_button)
        self.moderation_button=QPushButton('🛡 Moderacja');self.moderation_button.clicked.connect(self.moderation_dialog);bar.addWidget(self.moderation_button)
        root.addLayout(bar)
        self.status=QLabel('Łączenie z czatem...');self.status.setWordWrap(True);self.status.setStyleSheet('color:#a8d2ef;font-size:11px');root.addWidget(self.status)
        self.scroller=QScrollArea();self.scroller.setWidgetResizable(True);self.scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroller.setStyleSheet('QScrollArea{background:#101531;border:1px solid #7d52bb;border-radius:12px;}')
        self.messages_widget=QWidget();self.messages_widget.setStyleSheet('background:#101531')
        self.messages_layout=QVBoxLayout(self.messages_widget);self.messages_layout.setContentsMargins(6,8,6,8);self.messages_layout.setSpacing(7)
        self.messages_layout.addStretch();self.scroller.setWidget(self.messages_widget);root.addWidget(self.scroller,1)
        inp=QHBoxLayout();inp.setSpacing(5)
        self.input=QLineEdit();self.input.setPlaceholderText('Napisz wiadomość...');self.input.setMaxLength(300)
        self.input.returnPressed.connect(self.send);inp.addWidget(self.input,1)
        self.send_button=QPushButton('➤');self.send_button.setToolTip('Wyślij wiadomość');self.send_button.clicked.connect(self.send)
        self.send_button.setFixedWidth(43);inp.addWidget(self.send_button);root.addLayout(inp)
        foot=QLabel('Flaga jest wybierana przez gracza. Nick nie jest zweryfikowany. Nie podawaj danych osobowych.')
        foot.setWordWrap(True);foot.setStyleSheet('font-size:10px;color:#aebcda');root.addWidget(foot)
        from PySide6.QtCore import QTimer
        self.timer=QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(4000)
        self.refresh()

    def _allowed(self,url):
        from urllib.parse import urlsplit
        p=urlsplit(url)
        return bool(p.hostname) and (p.scheme=='https' or (p.scheme=='http' and p.hostname in ('localhost','127.0.0.1','::1')))

    def request(self,path,data=None,success=None,failure=None,token=''):
        base=self.config.get('server','').rstrip('/')
        if not self._allowed(base):
            QMessageBox.warning(self,'Czat','Serwer wymaga HTTPS (lokalny 127.0.0.1 może używać HTTP).');return
        worker=ChatHTTP(base+path,data,token);self.workers.append(worker)
        if success:worker.success.connect(success)
        if failure:worker.failure.connect(failure)
        else:worker.failure.connect(lambda error:self._status('Błąd: '+error))
        worker.finished.connect(lambda w=worker:self.workers.remove(w) if w in self.workers else None)
        worker.start()

    def _status(self,value):self.status.setText(value[:190])

    def edit_profile(self):
        dlg=QDialog(self);dlg.setWindowTitle('MINEVORA • Profil czatu');dlg.setMinimumWidth(360)
        lay=QVBoxLayout(dlg);form=QFormLayout()
        nick=QLineEdit(str(self.config.get('name','')));nick.setMaxLength(24);form.addRow('Nick Minecraft:',nick)
        country=QComboBox();country.addItems(list(FLAGS));country.setCurrentText(self.config.get('country','Polska'));form.addRow('Flaga:',country)
        url=QLineEdit(str(self.config.get('server','http://127.0.0.1:8766')));form.addRow('Serwer czatu:',url)
        avatar=QCheckBox('Pobieraj główki skinów (zewnętrzny serwis mc-heads.net)');avatar.setWordWrap(True) if hasattr(avatar,'setWordWrap') else None
        avatar.setChecked(bool(self.config.get('skin_heads',False)))
        form.addRow('Skórki:',avatar);lay.addLayout(form)
        tip=QLabel('Flaga i nick to deklaracje użytkownika. Główki pobierane są na podstawie nicku przez HTTPS; możesz je wyłączyć.')
        tip.setWordWrap(True);lay.addWidget(tip)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept);buttons.rejected.connect(dlg.reject);lay.addWidget(buttons)
        if dlg.exec()!=QDialog.Accepted:return
        name=nick.text().strip();target=url.text().strip().rstrip('/')
        if not re.fullmatch(r'[^<>&\r\n]{1,24}',name) or not self._allowed(target):
            QMessageBox.warning(self,'Czat','Podaj poprawny nick i serwer HTTPS (lub lokalny HTTP).');return
        self.config={'name':name,'country':country.currentText(),'server':target,'skin_heads':avatar.isChecked()}
        CHAT_CONFIG.parent.mkdir(parents=True,exist_ok=True)
        CHAT_CONFIG.write_text(json.dumps(self.config,ensure_ascii=False,indent=2),encoding='utf-8')
        self.avatar_cache.clear();self.fingerprint=None;self.token=''
        self.stats.emit(0,0,self.config)
        self.refresh()

    def refresh(self):
        if self.busy:return
        self.busy=True
        def ok(payload):
            self.busy=False
            messages=payload.get('messages',[])
            if not isinstance(messages,list):messages=[]
            fingerprint=tuple((m.get('id'),m.get('body')) for m in messages if isinstance(m,dict))
            if fingerprint != self.fingerprint:
                self.fingerprint=fingerprint
                self.render(messages)
            total=int(payload.get('total',0));online=int(payload.get('online',0))
            self._status(f'● Połączono  •  {online} aktywnych  •  {total} wiadomości  •  🛡 Bot: '+('ON' if payload.get('bot_enabled') else 'OFF'))
            self.stats.emit(total,online,self.config)
        def fail(error):
            self.busy=False;self._status('Czat niedostępny: '+error)
        self.request('/messages',success=ok,failure=fail)

    def _clear(self):
        while self.messages_layout.count():
            item=self.messages_layout.takeAt(0)
            if item.widget():item.widget().deleteLater()
            elif item.layout():item.layout().deleteLater()
        self.avatar_labels={}

    def _avatar(self,nick,label):
        if not self.config.get('skin_heads'):return
        if not re.fullmatch(r'[A-Za-z0-9_]{3,16}',nick):return
        key=nick.lower();self.avatar_labels.setdefault(key,[]).append(label)
        if key in self.avatar_cache:
            label.setPixmap(self.avatar_cache[key]);return
        if key in self.avatar_pending or len(self.avatar_pending)>8:return
        self.avatar_pending.add(key)
        from urllib.parse import quote
        url='https://mc-heads.net/avatar/'+quote(nick,safe='')+'/40'
        reply=self.avatar_network.get(QNetworkRequest(QUrl(url)))
        def done():
            self.avatar_pending.discard(key)
            if reply.error()==reply.NetworkError.NoError:
                raw=reply.readAll().data()
                if len(raw)<=250000:
                    pm=QPixmap()
                    if pm.loadFromData(raw):
                        pm=pm.scaled(38,38,Qt.KeepAspectRatio,Qt.SmoothTransformation)
                        self.avatar_cache[key]=pm
                        for widget in self.avatar_labels.get(key,[]):
                            try:widget.setPixmap(pm)
                            except RuntimeError:pass
            reply.deleteLater()
        reply.finished.connect(done)

    def render(self,messages):
        scrollbar=self.scroller.verticalScrollBar()
        bottom=scrollbar.maximum()-scrollbar.value()<=75
        oldpos=scrollbar.value()
        self._clear()
        for m in messages[-80:]:
            if not isinstance(m,dict):continue
            mid=m.get('id');name=str(m.get('name','?'))[:24]
            is_bot=m.get('kind')=='bot'
            row=QFrame();row.setStyleSheet('QFrame#chatMessage{background:'+('#122e40' if is_bot else '#241a48')+';border:1px solid '+('#299ab1' if is_bot else '#5f4392')+';border-radius:10px} QLabel{background:transparent}')
            row.setObjectName('chatMessage')
            main=QHBoxLayout(row);main.setContentsMargins(6,6,6,7);main.setSpacing(6)
            avatar=QLabel('🛡' if is_bot else (name or '?')[:1].upper());avatar.setFixedSize(38,38);avatar.setAlignment(Qt.AlignCenter)
            avatar.setStyleSheet('background:#3c306a;color:#e8d5ff;font-weight:800;border-radius:7px;font-size:17px')
            main.addWidget(avatar,0,Qt.AlignTop)
            if not is_bot:self._avatar(name,avatar)
            right=QVBoxLayout();right.setSpacing(3)
            top=QHBoxLayout();top.setSpacing(3)
            flag=QLabel('🤖' if is_bot else FLAGS.get(str(m.get('country','Inny')),'🌍'));flag.setFont(QFont('Segoe UI Emoji',13));top.addWidget(flag)
            namelabel=QLabel(name + ('  •  BOT' if is_bot else ''));namelabel.setStyleSheet('color:'+('#78e5fa' if is_bot else '#dcbcff')+';font-size:12px;font-weight:700');top.addWidget(namelabel,1)
            time_label=QLabel(str(m.get('time',''))[:16]);time_label.setStyleSheet('color:#afbfdd;font-size:9px');top.addWidget(time_label)
            more=QPushButton('⋯');more.setFixedSize(26,24);more.setToolTip('Zgłoś / moderuj wiadomość')
            more.setStyleSheet('QPushButton{padding:0;background:#2a3b5d;border:1px solid #4a5783;border-radius:6px}')
            more.clicked.connect(lambda checked=False,msg_id=mid,user=name:self.message_menu(msg_id,user))
            if not is_bot:top.addWidget(more)
            else:more.deleteLater()
            right.addLayout(top)
            body=QLabel(str(m.get('body',''))[:300]);body.setWordWrap(True);body.setTextInteractionFlags(Qt.TextSelectableByMouse)
            body.setTextFormat(Qt.PlainText);body.setStyleSheet('color:#f4f1ff;font-size:12px');right.addWidget(body)
            main.addLayout(right,1);self.messages_layout.addWidget(row)
        self.messages_layout.addStretch()
        from PySide6.QtCore import QTimer
        QTimer.singleShot(30,lambda:scrollbar.setValue(scrollbar.maximum() if bottom else min(oldpos,scrollbar.maximum())))

    def send(self):
        body=self.input.text().strip()
        if not body:return
        name=str(self.config.get('name','')).strip()
        if not name:
            QMessageBox.information(self,'Czat','Najpierw ustaw profil i nick.');self.edit_profile();return
        self.input.setEnabled(False);self.send_button.setEnabled(False)
        def ok(_):
            self.input.clear();self.input.setEnabled(True);self.send_button.setEnabled(True);self.refresh()
        def fail(error):
            self.input.setEnabled(True);self.send_button.setEnabled(True)
            self._status('Nie wysłano: '+error)
        self.request('/send',{'name':name,'country':self.config.get('country','Polska'),'body':body},success=ok,failure=fail)

    def message_menu(self,mid,name):
        menu=QMenu(self)
        report=menu.addAction('🚩 Zgłoś wiadomość')
        delete=mute10=mute60=mute24=ban=unmute=unban=None
        if self.token:
            menu.addSeparator()
            delete=menu.addAction('🗑 Usuń wiadomość')
            mute10=menu.addAction('🔇 Wycisz nick na 10 minut')
            mute60=menu.addAction('🔇 Wycisz nick na 1 godzinę')
            mute24=menu.addAction('🔇 Wycisz nick na 24 godziny')
            ban=menu.addAction('⛔ Zablokuj nick')
            unmute=menu.addAction('🔊 Cofnij wyciszenie')
            unban=menu.addAction('✅ Cofnij blokadę')
        selected=menu.exec(QCursor.pos())
        if selected is None:return
        if selected==report:
            reasons=['Spam','Wulgaryzmy lub obrażanie','Nękanie','Niebezpieczne treści','Inne']
            reason,ok=QInputDialog.getItem(self,'Zgłoszenie','Powód zgłoszenia:',reasons,0,False)
            if ok:self.request('/report',{'message_id':mid,'reason':reason},success=lambda _:QMessageBox.information(self,'Czat','Wysłano zgłoszenie moderatorom.'))
        elif selected==delete:self.admin_action('/admin/delete',{'message_id':mid})
        elif selected in (mute10,mute60,mute24):self.admin_action('/admin/mute',{'name':name,'minutes':{mute10:10,mute60:60,mute24:1440}[selected]})
        elif selected==ban:
            if QMessageBox.question(self,'Blokada','Zablokować nick '+name+'?')==QMessageBox.Yes:self.admin_action('/admin/ban',{'name':name})
        elif selected==unmute:self.admin_action('/admin/unmute',{'name':name})
        elif selected==unban:self.admin_action('/admin/unban',{'name':name})

    def admin_action(self,path,data,refresh_reports=None):
        def ok(_):
            self._status('✔ Działanie moderatora wykonane')
            self.fingerprint=None;self.refresh()
            if refresh_reports:refresh_reports()
        self.request(path,data,success=ok,token=self.token)

    def moderation_dialog(self):
        if not self.token:
            token,ok=QInputDialog.getText(self,'Dostęp moderatora','Token z konsoli serwera czatu:',QLineEdit.Password)
            if not ok or not token:return
            def authorized(_):
                self.token=token
                self._status('🛡 Zalogowano do panelu moderatora')
                self.open_reports()
            self.request('/admin/status',success=authorized,failure=lambda err:QMessageBox.warning(self,'Moderacja',err),token=token)
        else:self.open_reports()

    def open_reports(self):
        dialog=QDialog(self);dialog.setWindowTitle('MINEVORA • Raporty moderacji');dialog.resize(580,430)
        lay=QVBoxLayout(dialog)
        lay.addWidget(QLabel('🛡 ZGŁOSZENIA • Dane wyłącznie z tego serwera czatu'))
        report_list=QListWidget();report_list.setSelectionMode(QAbstractItemView.SingleSelection);lay.addWidget(report_list)
        report_ids=[]
        bot_button=QPushButton('🤖 Guard Bot — ustawienia i dziennik');bot_button.clicked.connect(self.guard_bot_dialog);lay.addWidget(bot_button)
        def reload():
            def got(data):
                report_list.clear();report_ids.clear()
                for report in data.get('reports',[]):
                    report_ids.append(report.get('id'))
                    report_list.addItem(f"#{report.get('id')} [{report.get('status')}]  {report.get('name')}: {report.get('reason')}  |  {str(report.get('body',''))[:65]}")
            self.request('/admin/reports',success=got,token=self.token)
        def resolve():
            idx=report_list.currentRow()
            if idx<0 or idx>=len(report_ids):return
            self.admin_action('/admin/resolve',{'report_id':report_ids[idx]},refresh_reports=reload)
        btns=QHBoxLayout()
        for label,func in [('↻ Odśwież',reload),('✓ Oznacz jako rozpatrzone',resolve),('Wyloguj moderatora',lambda:(setattr(self,'token',''),dialog.accept()))]:
            b=QPushButton(label);b.clicked.connect(func);btns.addWidget(b)
        lay.addLayout(btns)
        note=QLabel('Uwaga: nicki są deklarowane samodzielnie. Blokady nicków nie zastępują prawdziwego systemu kont.')
        note.setWordWrap(True);lay.addWidget(note)
        reload();dialog.exec()

    def guard_bot_dialog(self):
        if not self.token:
            QMessageBox.warning(self,'Guard Bot','Zaloguj się jako moderator.');return
        dlg=QDialog(self);dlg.setWindowTitle('MINEVORA • Guard Bot — panel administratora');dlg.resize(670,650)
        lay=QVBoxLayout(dlg)
        title=QLabel('🤖  MINEVORA GUARD BOT  •  AUTOMATYCZNA MODERACJA')
        title.setStyleSheet('font-size:15px;font-weight:800;color:#9fe6ff');lay.addWidget(title)
        hint=QLabel('Bot sprawdza spam, powtórzenia, flood, nadmiar linków i oznaczeń oraz wskazane frazy. Nie stosuje automatycznych permanentnych banów.')
        hint.setWordWrap(True);lay.addWidget(hint)
        enabled=QCheckBox('🛡 Włącz automatyczną moderację');lay.addWidget(enabled)
        caps=QCheckBox('Filtruj wiadomości pisane niemal wyłącznie WIELKIMI LITERAMI');lay.addWidget(caps)
        form=QFormLayout()
        fields={}
        specs=[('max_messages','Limit wiadomości w oknie:',3,20),('flood_seconds','Czas okna (sekundy):',5,120),
               ('max_repeats','Dopuszczalne powtórzenia:',1,5),('repeat_seconds','Sprawdzaj powtórzenia (sekundy):',10,300),
               ('max_mentions','Maks. oznaczeń @:',1,15),('link_limit','Maks. linków na wiadomość:',0,10),
               ('mute_after','Wycisz po ilu naruszeniach:',2,10),('mute_minutes','Wyciszenie (minuty):',1,1440),
               ('warning_window_minutes','Okno ostrzeżeń (minuty):',10,1440)]
        for key,label,minimum,maximum in specs:
            field=QSpinBox();field.setRange(minimum,maximum);fields[key]=field;form.addRow(label,field)
        lay.addLayout(form)
        blocked=QPlainTextEdit();blocked.setPlaceholderText('Jedna blokowana fraza w każdej linii (opcjonalnie)')
        blocked.setFixedHeight(78);lay.addWidget(QLabel('Blokowane frazy (ręcznie ustalone przez moderatora):'));lay.addWidget(blocked)
        log=QListWidget();lay.addWidget(QLabel('Historia automatycznych ostrzeżeń i wyciszeń:'));lay.addWidget(log,1)
        bot_users={}
        def load():
            def ok(result):
                rules=result.get('rules',{})
                enabled.setChecked(bool(rules.get('enabled',True)))
                caps.setChecked(bool(rules.get('caps_filter',True)))
                for key,field in fields.items():field.setValue(int(rules.get(key,field.minimum())))
                blocked.setPlainText('\n'.join(rules.get('blocked_phrases',[])))
                log.clear();bot_users.clear()
                from datetime import datetime
                for event in result.get('events',[]):
                    name=str(event.get('name',''))
                    when=datetime.fromtimestamp(int(event.get('timestamp',0))).strftime('%d.%m %H:%M')
                    entry=f"{when} | {name} | {event.get('action')} | {event.get('reason')}"
                    index=log.count();log.addItem(entry);bot_users[index]=name
            self.request('/admin/bot',success=ok,token=self.token,failure=lambda error:QMessageBox.warning(dlg,'Guard Bot',error))
        def save():
            payload={'enabled':enabled.isChecked(),'caps_filter':caps.isChecked(),
                     'blocked_phrases':[t.strip() for t in blocked.toPlainText().splitlines() if t.strip()]}
            payload.update({key:field.value() for key,field in fields.items()})
            self.request('/admin/bot/settings',payload,token=self.token,
                         success=lambda _: (self._status('✔ Ustawienia Guard Bot zapisane na serwerze'),load()),
                         failure=lambda error:QMessageBox.warning(dlg,'Guard Bot',error))
        def clear_warnings():
            row=log.currentRow()
            if row<0 or row not in bot_users:return
            name=bot_users[row]
            if QMessageBox.question(dlg,'Cofanie ostrzeżeń',f'Usunąć historię ostrzeżeń bota dla nicku {name}? Nie cofnie to automatycznie aktywnego wyciszenia.')!=QMessageBox.Yes:return
            self.request('/admin/bot/clear',{'name':name},token=self.token,success=lambda _:load())
        buttons=QHBoxLayout()
        for label,fn in [('💾 Zapisz ustawienia',save),('↻ Odśwież',load),('Wyczyść ostrzeżenia',clear_warnings),('Zamknij',dlg.accept)]:
            button=QPushButton(label);button.clicked.connect(lambda checked=False,handler=fn:handler());buttons.addWidget(button)
        lay.addLayout(buttons)
        note=QLabel('Ograniczenie: w tej wersji nick nie jest zweryfikowany. Bot nie określa intencji użytkownika i może popełniać błędy. Moderator może cofnąć wyciszenie w menu wiadomości.')
        note.setWordWrap(True);note.setStyleSheet('color:#b7c5e7;font-size:11px');lay.addWidget(note)
        load();dlg.exec()

    def shutdown(self):
        self.timer.stop()
        for worker in list(self.workers):
            if worker.isRunning():worker.wait(7000)
