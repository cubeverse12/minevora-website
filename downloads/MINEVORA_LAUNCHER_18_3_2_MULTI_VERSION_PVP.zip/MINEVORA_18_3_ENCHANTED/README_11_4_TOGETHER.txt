MINEVORA 11.4 — TOGETHER
=======================

NOWOSC: panel «♡ Together» w MINEVORA Launcher.

CO DZIALA
- Instalator oficjalnego Essential Mod bez posrednictwa innego instalatora.
- Weryfikacja projektu, zgodnosci Fabric/Forge/NeoForge oraz SHA-512 pobranego moda.
- Pobieranie z Modrinth wyłącznie po Twoim zatwierdzeniu.
- Automatyczne sprawdzenie i pobranie wymaganych zaleznosci Modrinth.
- Brak podmiany juz zainstalowanych plikow; rollback nowego moda w razie bledu.
- Lokalna lista zapisanych adresow serwerow i znajomych (bez obecnosci online).
- Kopiowanie adresu serwera do schowka.
- Dostep do istniejacego czatu MINEVORA oraz edytora skinow.
- Galeria screenshotow z folderu screenshots aktywnej instancji.

CO JEST PO STRONIE ESSENTIAL, A NIE MINEVORA
- Hosting swiata bez przekierowywania portow, zaproszenia do swiata,
  znajomi i wiadomosci wewnatrz gry to funkcje ZEWNETRZNEGO Essential.
- Zainstalowany mod moze wymagac wlasnego konta i komunikowac sie
  z serwerami Essential wedlug zasad tego uslugodawcy.
- MINEVORA nie sprzedaje Essential, nie tworzy jego kopii i nie zawiera
  kodu ani plikow JAR Essential w tej paczce. Plik pobierany jest
  z oficjalnej strony projektu w Modrinth po zgodzie uzytkownika.
- To nie jest nowa usluga P2P MINEVORA ani w pelni osobny mod.

INSTALACJA
1) Zamknij Minecraft i zrob kopie folderu mods oraz waznych swiatow.
2) Rozpakuj caly ZIP do osobnego folderu.
3) W razie potrzeby uruchom INSTALUJ_ZALEZNOSCI.bat.
4) Uruchom URUCHOM_MINEVORA.bat.
5) Wybierz zgodna instalacje Fabric/Forge/NeoForge (np. 1.21.1).
6) Otworz «♡ Together», kliknij «WLACZ GRE ZE ZNAJOMYMI» i potwierdz.
7) Uruchom Minecraft. Zaproszenia/hostowanie swiatow znajdziesz w menu Essential.

W przypadku zwyklej (vanilla) instancji trzeba najpierw zainstalowac loader.
Pobieranie wymaga internetu, a wsparcie zalezy od wersji Minecraft i Essential.

TESTY
- python TESTY_TOGETHER.py (testy offline)
- python -m unittest discover -s tests -v
- python -m compileall -q .
- Sprawdz GUI, pobieranie modow oraz zaproszenia na Windows 11 z Minecraft.

BEZPIECZENSTWO
JAR modow jest kodem uruchamianym przez Minecraft. Instaluj tylko zaufane
projekty. Nie wklejaj nigdzie tokenow Microsoft. Prywatne adresy serwerow
udostepniaj jedynie zaufanym osobom.
