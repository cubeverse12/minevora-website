"""Pure marketplace filtering, sorting and lazy-page helpers."""
from pathlib import Path
from minevora_easy_core import fold_text

PAGE_SIZE = 18

def find_offers(listings, query='', category='Wszystkie', price_mode='Wszystkie',
                style='Dowolny', fmt='Każdy format', sort='Najnowsze'):
    terms = fold_text(query).split()
    out = []
    for listing in listings:
        if not isinstance(listing, dict):
            continue
        price=listing.get('price',0)
        if type(price) is not int or price < 0:
            continue
        kind=str(listing.get('category',''))
        if category not in ('Wszystkie','') and kind != category:
            continue
        # Style is meaningful only for buildings; never hide unrelated categories
        # when a category is selected explicitly.
        if style != 'Dowolny' and kind != 'Budowle':
            continue
        if style != 'Dowolny' and str(listing.get('style','Inny')).casefold()!=style.casefold():
            continue
        current_fmt=str(listing.get('asset_format','')).lower().strip()
        if current_fmt and not current_fmt.startswith('.'):
            current_fmt='.'+current_fmt
        if fmt != 'Każdy format' and current_fmt != fmt.lower():
            continue
        currency=str(listing.get('currency','MVC')).upper()
        if price_mode=='Darmowe' and price!=0:continue
        if price_mode=='Za MVC' and (price==0 or currency!='MVC'):continue
        if price_mode=='Cena PLN (informacyjnie)' and (price==0 or currency!='PLN'):continue
        if terms:
            haystack=fold_text(' '.join(str(listing.get(key,'')) for key in
                ('title','description','category','author','tags','asset_format','style')))
            if not all(term in haystack for term in terms):continue
        out.append(listing)
    if sort=='Nazwa A–Z':out.sort(key=lambda x:fold_text(x.get('title','')))
    elif sort=='Cena rosnąco':out.sort(key=lambda x:(x['price'],fold_text(x.get('title',''))))
    elif sort=='Cena malejąco':out.sort(key=lambda x:(-x['price'],fold_text(x.get('title',''))))
    else:out.reverse()
    return out
