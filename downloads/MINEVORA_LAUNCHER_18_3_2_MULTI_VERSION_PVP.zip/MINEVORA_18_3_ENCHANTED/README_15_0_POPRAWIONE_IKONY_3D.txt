MINEVORA 15.0 — ENCHANTED / 3D / OSTRE IKONY

Zmiany:
* Poprawione proporcje bannerów (kadrowanie COVER, bez rozciągania).
* Zachowane proporcje i filtrowanie wysokiej jakości miniaturek.
* Jednolite ikony 256x256 PNG we wszystkich sekcjach Qt (skalowane do 21x21 px).
* Panel dziewięciu minigier w przejrzystej siatce.
* Podgląd skinów: obrót przeciąganiem, zoom kółkiem myszy, zachowane ostre piksele.
* Zachowana logika istniejących funkcji, w tym logowania, pobierania, Modrinth, Marketplace, Together i Discord.

URUCHOMIENIE (Windows 11):
1. Rozpakuj ZIP do nowego folderu.
2. Uruchom INSTALUJ_ZALEZNOSCI.bat (Python + PySide6 itd.).
3. Uruchom URUCHOM_MINEVORA.bat.
4. Jeżeli pojawi się błąd, uruchom SPRAWDZ_LAUNCHER.bat.

To źródłowa paczka aplikacji, nie skompilowany plik EXE.
Nie weryfikowano połączenia z zewnętrznymi serwerami ani logowania Microsoft w tym środowisku.
Graficzny podgląd postaci jest rendererem 3D-perspektywy opartym na Qt (nie pełnym OpenGL).
Mapy Minecraft i serwery wymagają oddzielnej instalacji i hostingu.
W razie problemów wyślij zrzut i plik ostatni_blad.txt (bez tokenów i sekretów).
