"""MINEVORA local ranking. Manually entered/self-reported data only.

No network/official player verification. Public exports contain only chosen Minecraft
nickname and aggregate gameplay values. No IPs, bans or tokens are exported.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import re

DATA_PATH = Path.home() / '.minevora' / 'ranking_local.json'
MAX_PLAYERS = 250
FIELDS = ('xp', 'wins', 'losses', 'kills', 'deaths')
NICK_RE = re.compile(r'^[A-Za-z0-9_]{3,16}$')


def clean_nick(value):
    if not isinstance(value, str) or not NICK_RE.fullmatch(value.strip()):
        raise ValueError('Nick Minecraft powinien mieć 3–16 znaków: litery, cyfry lub _.')
    return value.strip()


def clean_score(value):
    if type(value) is not int or value < 0 or value > 10**9:
        raise ValueError('Statystyka musi być liczbą całkowitą od 0 do 1 000 000 000.')
    return value


def clean_player(row):
    if not isinstance(row, dict):
        raise ValueError('Nieprawidłowy rekord gracza.')
    result = {'nick': clean_nick(row.get('nick'))}
    for field in FIELDS:
        result[field] = clean_score(row.get(field, 0))
    return result


def normalize(source):
    if not isinstance(source, dict):
        return {'version': 1, 'players': []}
    out, seen = [], set()
    raw = source.get('players', [])
    if not isinstance(raw, list):
        raw=[]
    for record in raw[:MAX_PLAYERS*2]:
        try: row=clean_player(record)
        except ValueError: continue
        key=row['nick'].casefold()
        if key in seen: continue
        seen.add(key); out.append(row)
        if len(out) >= MAX_PLAYERS: break
    return {'version': 1, 'players': out}


def load_local(path=DATA_PATH):
    try:
        return normalize(json.loads(Path(path).read_text(encoding='utf-8')))
    except (OSError, ValueError, TypeError):
        return normalize({})


def save_local(data, path=DATA_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    fixed=normalize(data)
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(fixed,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(path)
    return fixed


def put_player(data, row):
    updated=clean_player(row)
    clean=normalize(data)
    index=next((i for i,p in enumerate(clean['players']) if p['nick'].casefold()==updated['nick'].casefold()),None)
    if index is None:
        if len(clean['players']) >= MAX_PLAYERS:
            raise ValueError('Osiągnięto limit 250 wpisów lokalnych.')
        clean['players'].append(updated)
    else:
        clean['players'][index]=updated
    return clean


def delete_player(data, nick):
    clean=normalize(data)
    clean['players']=[p for p in clean['players'] if p['nick'].casefold()!=str(nick).casefold()]
    return clean


def ranked(data, metric='xp', query=''):
    if metric not in ('xp','pvp'): raise ValueError('Nieznany tryb rankingu.')
    players=normalize(data)['players']
    query=str(query).casefold().strip()
    if query:players=[p for p in players if query in p['nick'].casefold()]
    if metric=='xp':
        return sorted(players,key=lambda p:(-p['xp'],p['nick'].casefold()))
    return sorted(players,key=lambda p:(-p['wins'],p['losses'],-p['kills'],p['nick'].casefold()))


def public_snapshot(data, now=None):
    """Strict allowlist: no UUID, real names, bans, identifiers, or account tokens."""
    players=normalize(data)['players']
    stamp=(now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat(timespec='seconds')
    return {'version':1,'updated_at':stamp,'source':'local_unverified',
            'description':'Wyniki demonstracyjne, ręcznie wpisane lub lokalne. Bez serwera weryfikującego.',
            'players':[{'nick':p['nick'],**{key:p[key] for key in FIELDS}} for p in players]}


def export_public(data, destination):
    destination=Path(destination)
    snapshot=public_snapshot(data)
    temp=destination.with_name(destination.name+'.tmp')
    temp.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(destination)
    return len(snapshot['players'])
