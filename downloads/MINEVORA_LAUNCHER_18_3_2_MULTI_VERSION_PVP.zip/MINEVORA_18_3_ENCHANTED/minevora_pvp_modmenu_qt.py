"""MINEVORA PvP HUD: in-launcher controls and Fabric mod installation.
No client modification/cheats are installed without the user's action.
"""
import json
import os
import shutil
import zipfile
from pathlib import Path
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,
 QPushButton,QFrame,QScrollArea,QCheckBox,QComboBox,QMessageBox,QFileDialog,QColorDialog)
from minevora_engine import MC_DIR
from minevora_pvp_auto import cache_jar, CACHE_JAR, read_auto_enabled, set_auto_enabled, supports_hud, provision, is_hud_jar, profile_target, available_jar, jar_minecraft_version

CONFIG_NAME='minevora_pvp.json'
MOD_ID='minevorapvphud'
FEATURES={
 'CPS Counter': {'enabled':True,'style':'Nowoczesny','position':'Lewy górny','color':'#913bff'},
 'Keystrokes (WASD)': {'enabled':True,'style':'Box','position':'Prawy górny','color':'#1583ff'},
 'Armor HUD': {'enabled':True,'style':'Ikony + %','position':'Lewy środek','color':'#21d5ed'},
 'Potion HUD': {'enabled':True,'style':'Lista','position':'Prawy środek','color':'#f8dc46'},
 'FPS Counter': {'enabled':True,'style':'Prosty','position':'Lewy dolny','color':'#24d35c'},
 'Crosshair Editor': {'enabled':True,'style':'Kropka + linie','position':'Środek','color':'#fc315f'},
 'Combo / Hit Color': {'enabled':False,'style':'Nowoczesny','position':'Środek górny','color':'#b967ff'}
}
STYLES=['Nowoczesny','Prosty','Box','Lista','Ikony + %','Kropka + linie']
POSITIONS=['Lewy górny','Prawy górny','Lewy środek','Prawy środek','Lewy dolny','Prawy dolny','Środek','Środek górny']


def compatible_jar(jar_path):
    """Avoid copying arbitrary/mislabelled jar files into the Minecraft mods directory."""
    if Path(jar_path).name.endswith(('-sources.jar','-dev.jar')):
        return False
    with zipfile.ZipFile(jar_path) as archive:
        data=json.loads(archive.read('fabric.mod.json').decode('utf-8'))
        has_class='pl/minevora/pvphud/MinevoraPvpHud.class' in archive.namelist()
    return isinstance(data,dict) and data.get('id')==MOD_ID and data.get('environment')=='client' and bool(jar_minecraft_version(jar_path)) and has_class


class GitHubHudWorker(QThread):
 done=Signal(str)
 failed=Signal(str)
 progress=Signal(str)
 def __init__(self, version, game_dir):
  super().__init__()
  self.version=version
  self.game_dir=Path(game_dir)
 def run(self):
  try:
   from minevora_pvp_github import update_from_github
   result=update_from_github(version=self.version,progress=self.progress.emit)
   if supports_hud(self.version):
    state,message=provision(self.version,self.game_dir)
    if state!='ready':raise RuntimeError(message)
    result+='\n'+message
   else:
    result+='\nBrak zgodnego wydania dla wybranego profilu. Nie instaluję moda z innej wersji.'
   self.done.emit(result)
  except Exception as exc:
   self.failed.emit(str(exc))


class PvPModMenu(QWidget):
 def __init__(self,parent=None,get_game_dir=None,get_version=None,is_running=None):
  super().__init__(parent)
  self.get_game_dir=get_game_dir or (lambda: str(MC_DIR))
  self.get_version=get_version or (lambda: None)
  self.is_running=is_running or (lambda: False)
  self.controls={};self.colors={};self.github_worker=None
  root=QVBoxLayout(self);root.setContentsMargins(20,16,20,16);root.setSpacing(10)
  title=QLabel('⚔  MINEVORA • PvP MOD MENU');title.setStyleSheet('font-size:27px;font-weight:900;color:#f5edff');root.addWidget(title)
  subtitle=QLabel('Włącz funkcje w launcherze → zapisz → uruchom Fabric → używaj HUD podczas gry na serwerach.')
  subtitle.setWordWrap(True);subtitle.setStyleSheet('color:#c8b6ef');root.addWidget(subtitle)
  warn=QLabel('Działa z wersją Fabric, dla której wydano osobny zgodny MINEVORA PvP HUD .jar. W paczce jest obecnie Fabric 1.21.1. Inne wersje pojawią się po publikacji ich kompilacji. Zasady serwerów mogą ograniczać używanie modów.')
  warn.setWordWrap(True);warn.setStyleSheet('background:#2b2144;color:#f7d78f;padding:10px;border:1px solid #6f5892;border-radius:8px');root.addWidget(warn)
  tools=QFrame();tools.setStyleSheet('QFrame{background:#16132a;border:1px solid #453474;border-radius:12px} QFrame QLabel{border:0;background:transparent}')
  box=QVBoxLayout(tools)
  self.instance_label=QLabel('');self.instance_label.setWordWrap(True);box.addWidget(self.instance_label)
  self.state_label=QLabel('');self.state_label.setWordWrap(True);box.addWidget(self.state_label)
  actions=QHBoxLayout()
  for label,callback in [('＋  Zainstaluj mod .jar',self.install_jar),('◉  Włącz / wyłącz mod',self.toggle_jar),('📁  Folder modów',self.open_mods_folder)]:
   b=QPushButton(label);b.clicked.connect(callback);actions.addWidget(b)
  box.addLayout(actions)
  self.github_button=QPushButton('⬇  POBIERZ I ZAINSTALUJ PVP HUD Z GITHUBA')
  self.github_button.setStyleSheet('background:#7141d8;color:white;border-radius:9px;padding:10px;font-weight:700')
  self.github_button.clicked.connect(self.install_github)
  box.addWidget(self.github_button)
  self.github_info=QLabel('Sprawdzanie GitHub Releases, pobranie JAR i instalacja jednym kliknieciem. Gdy nie ma kompilacji dla wybranej wersji, launcher odmówi instalacji niezgodnego pliku. Plik zapasowy jest tylko dla Fabric 1.21.1.')
  self.github_info.setWordWrap(True)
  self.github_info.setStyleSheet('color:#b9a9e3')
  box.addWidget(self.github_info)
  auto_row=QHBoxLayout()
  self.auto_checkbox=QCheckBox('Automatyczny PvP HUD w profilach z dostępną zgodną kompilacją Fabric')
  self.auto_checkbox.setChecked(read_auto_enabled())
  self.auto_checkbox.toggled.connect(self.change_auto)
  auto_row.addWidget(self.auto_checkbox);box.addLayout(auto_row)
  root.addWidget(tools)
  scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setStyleSheet('border:0;background:transparent')
  body=QWidget();grid=QGridLayout(body);grid.setSpacing(11)
  for i,(name,d) in enumerate(FEATURES.items()):
   card=QFrame();card.setStyleSheet('QFrame{background:#19162c;border:1px solid #554080;border-radius:13px} QLabel{border:0;background:transparent;color:#eee9ff} QCheckBox{border:0;background:transparent;color:#fff} QComboBox{background:#100e22;border:1px solid #604a8c;border-radius:7px;padding:6px;color:white}')
   v=QVBoxLayout(card);v.setContentsMargins(14,11,14,11);v.setSpacing(8)
   h=QHBoxLayout();t=QLabel(name);t.setStyleSheet('font-size:14px;font-weight:bold');h.addWidget(t);h.addStretch()
   enabled=QCheckBox('Włącz');enabled.setChecked(d['enabled']);h.addWidget(enabled);v.addLayout(h)
   sty=QComboBox();sty.addItems(STYLES);sty.setCurrentText(d['style'])
   pos=QComboBox();pos.addItems(POSITIONS);pos.setCurrentText(d['position'])
   for desc,widget in [('Styl',sty),('Pozycja',pos)]:
    row=QHBoxLayout();row.addWidget(QLabel(desc));row.addWidget(widget,1);v.addLayout(row)
   color=QPushButton('●  Kolor');color.setStyleSheet('background:'+d['color']+';color:white;border-radius:7px;padding:7px')
   color.clicked.connect(lambda _=False,n=name:self.choose_color(n))
   v.addWidget(color)
   self.controls[name]=(enabled,sty,pos,color);self.colors[name]=d['color']
   grid.addWidget(card,i//2,i%2)
  scroll.setWidget(body);root.addWidget(scroll,1)
  footer=QHBoxLayout()
  reset=QPushButton('↺  Przywróć domyślne');reset.clicked.connect(self.reset);footer.addWidget(reset)
  footer.addStretch()
  self.save_button=QPushButton('💾  Zapisz do Minecraft');self.save_button.setStyleSheet('background:#6b24c8;color:#fff;padding:11px 18px;font-weight:bold;border-radius:10px')
  self.save_button.clicked.connect(self.save);footer.addWidget(self.save_button);root.addLayout(footer)
  self.refresh_target()

 def game_dir(self):
  raw=self.get_game_dir()
  return Path(raw) if raw else MC_DIR

 def config_path(self):return self.game_dir()/'config'/CONFIG_NAME
 def mods_dir(self):return self.game_dir()/'mods'

 def refresh_target(self):
  directory=self.game_dir();version=self.get_version() or 'brak wyboru'
  self.instance_label.setText(f'Instancja: {version}  •  {directory}')
  self.load()
  self.refresh_state()

 def installed_files(self):
  location=self.mods_dir()
  return sorted(location.glob('minevora-pvp-hud-*.jar'))+sorted(location.glob('minevora-pvp-hud-*.jar.disabled'))

 def refresh_state(self):
  files=self.installed_files()
  active=[p for p in files if p.suffix=='.jar']
  loader,mc=profile_target(self.get_version())
  if loader!='fabric' or not mc:
   msg='Wybierz profil Fabric z wersją Minecrafta. Forge / NeoForge / Quilt wymagają oddzielnego moda.'
  elif available_jar(mc):
   if any(is_hud_jar(path,mc) for path in active):
    msg='✓ MINEVORA PvP HUD dla Fabric '+mc+' jest już zainstalowany.'
   else:msg='Zgodny mod dla Fabric '+mc+' jest dostępny; zainstaluj go lub włącz auto-instalację.'
  else:msg='Brak wersji MINEVORA PvP HUD dla Fabric '+mc+'. Kliknij pobieranie z GitHub Releases.'
  self.state_label.setText(msg)
  self.state_label.setStyleSheet('color:'+('#8ce7c3' if loader=='fabric' and mc and available_jar(mc) else '#f0bf7b'))

 def change_auto(self,checked):
  try:set_auto_enabled(checked)
  except OSError as exc:QMessageBox.warning(self,'PvP HUD',str(exc))

 def choose_color(self,name):
  selected=QColorDialog.getColor(QColor(self.colors[name]),self,'Kolor '+name)
  if selected.isValid():
   self.colors[name]=selected.name();self.controls[name][3].setStyleSheet('background:'+selected.name()+';color:white;border-radius:7px;padding:7px')

 def collect(self):
  return {name:{'enabled':bool(chk.isChecked()),'style':style.currentText(),'position':position.currentText(),'color':self.colors[name]}
          for name,(chk,style,position,_) in self.controls.items()}

 def load(self):
  try:data=json.loads(self.config_path().read_text(encoding='utf-8'))
  except (OSError,ValueError,TypeError):data={}
  if not isinstance(data,dict):data={}
  for name,(chk,sty,pos,color) in self.controls.items():
   item=data.get(name,{})
   if not isinstance(item,dict):item={}
   d=FEATURES[name]
   chk.setChecked(bool(item.get('enabled',d['enabled'])))
   for widget,key in ((sty,'style'),(pos,'position')):
    value=item.get(key,d[key]);widget.setCurrentText(value if widget.findText(value)>=0 else d[key])
   value=item.get('color',d['color'])
   value=value if isinstance(value,str) and QColor(value).isValid() else d['color']
   self.colors[name]=value;color.setStyleSheet('background:'+value+';color:white;border-radius:7px;padding:7px')

 def save(self):
  try:
   config=self.config_path();config.parent.mkdir(parents=True,exist_ok=True)
   tmp=config.with_name(config.name+'.tmp')
   tmp.write_text(json.dumps(self.collect(),ensure_ascii=False,indent=2),encoding='utf-8')
   tmp.replace(config)
   QMessageBox.information(self,'MINEVORA PvP HUD','Zapisano ustawienia do '+str(config)+'\nMod odczytuje zmiany automatycznie w grze.')
  except OSError as exc:QMessageBox.warning(self,'Błąd zapisu',str(exc))

 def reset(self):
  for name,(chk,sty,pos,color) in self.controls.items():
   d=FEATURES[name];chk.setChecked(d['enabled']);sty.setCurrentText(d['style']);pos.setCurrentText(d['position'])
   self.colors[name]=d['color'];color.setStyleSheet('background:'+d['color']+';color:white;border-radius:7px;padding:7px')

 def install_jar(self):
  if self.is_running():
   QMessageBox.warning(self,'Minecraft uruchomiony','Zamknij Minecraft przed instalowaniem moda.');return
  source,_=QFileDialog.getOpenFileName(self,'Dodaj raz MINEVORA PvP HUD .jar',str(Path.home()),'Mod Fabric (*.jar)')
  if not source:return
  try:
   if not compatible_jar(source):raise ValueError('To nie jest mod MINEVORA PvP HUD (wymagany fabric.mod.json / id).')
   cache_jar(source)
   if supports_hud(self.get_version()):
    state,message=provision(self.get_version(),self.game_dir())
   else:
    state,message='cached','Zapisano HUD. Zostanie dodany tylko do zgodnej wersji Fabric.'
   self.refresh_state()
   QMessageBox.information(self,'PvP HUD',message)
  except (OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:QMessageBox.warning(self,'Nie można zainstalować moda',str(exc))

 def install_github(self):
  if self.is_running():
   QMessageBox.warning(self,'Minecraft uruchomiony','Zamknij Minecraft przed aktualizacja PvP HUD.');return
  if self.github_worker is not None and self.github_worker.isRunning():return
  self.github_button.setEnabled(False)
  self.github_info.setText('Sprawdzam nowa wersje moda z GitHuba...')
  self.github_worker=GitHubHudWorker(self.get_version(),self.game_dir())
  self.github_worker.progress.connect(self.github_info.setText)
  self.github_worker.done.connect(self.github_success)
  self.github_worker.failed.connect(self.github_error)
  self.github_worker.finished.connect(lambda:self.github_button.setEnabled(True))
  self.github_worker.start()

 def github_success(self,message):
  self.github_info.setText(message.replace('\n',' • '))
  self.refresh_state()
  QMessageBox.information(self,'MINEVORA • PvP HUD',message)

 def github_error(self,message):
  self.github_info.setText('Blad aktualizacji: '+message)
  QMessageBox.warning(self,'MINEVORA • GitHub PvP HUD',message)

 def toggle_jar(self):
  if self.is_running():
   QMessageBox.warning(self,'Minecraft uruchomiony','Zamknij Minecraft przed włączaniem lub wyłączaniem moda.');return
  current=self.auto_checkbox.isChecked()
  self.auto_checkbox.setChecked(not current)
  if not current and supports_hud(self.get_version()):
   try:provision(self.get_version(),self.game_dir())
   except OSError as exc:QMessageBox.warning(self,'PvP HUD',str(exc))
  if current:
   for path in self.installed_files():
    if path.suffix=='.jar' and compatible_jar(path):
     try:path.rename(path.with_name(path.name+'.disabled'))
     except OSError as exc:QMessageBox.warning(self,'PvP HUD',str(exc))
  self.refresh_state()

 def open_mods_folder(self):
  folder=self.mods_dir();folder.mkdir(parents=True,exist_ok=True)
  QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
