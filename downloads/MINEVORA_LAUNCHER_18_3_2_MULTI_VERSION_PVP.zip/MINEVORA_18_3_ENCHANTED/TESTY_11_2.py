"""Headless tests for MINEVORA 11.2. Run: python TESTY_11_2.py"""
import json
import tempfile
import unittest
from pathlib import Path
from minevora_modpack_core import create_pack, check_pack, list_packs, PackError
from minevora_market_filters import find_offers, PAGE_SIZE
from minevora_auto_ranking import sync_local
from minevora_leaderboard_core import normalize, load_local


class MarketFilterTests(unittest.TestCase):
    def setUp(self):
        self.data = [
            {'title':'Średniowieczny Zamek','category':'Budowle','description':'Fantasy','price':0,'currency':'MVC','style':'Medieval'},
            {'title':'Skórka wilka','category':'Tekstury','price':50,'currency':'MVC','asset_format':'.bbmodel'},
            {'title':'Big castle','category':'Budowle','price':200,'currency':'PLN','style':'Modern','asset_format':'blend'},
            {'title':'DARMOWA MAPA','category':'Mapy','price':0,'currency':'MVC'},
            {'title':'Mod 1','category':'Mody','price':55,'currency':'MVC'},
        ]
    def test_accents_and_terms(self):
        self.assertEqual(find_offers(self.data, query='sredniowieczny zamek')[0]['title'], 'Średniowieczny Zamek')
    def test_combined_filters(self):
        self.assertEqual(len(find_offers(self.data,category='Budowle',style='Modern',fmt='.blend',price_mode='Cena PLN (informacyjnie)')),1)
    def test_currency_and_free(self):
        self.assertEqual(len(find_offers(self.data,price_mode='Darmowe')),2)
        self.assertEqual(len(find_offers(self.data,price_mode='Za MVC')),2)
    def test_sort(self):
        x=find_offers(self.data,sort='Cena rosnąco')
        self.assertEqual([z['price'] for z in x],[0,0,50,55,200])
    def test_invalid_and_multiple_terms(self):
        self.assertEqual(find_offers(self.data+[{'price':-1,'title':'invalid'}],query='zamEk FAntasy')[0]['category'],'Budowle')
        self.assertEqual(find_offers(self.data,query='nope'),[])
    def test_page_size(self):
        self.assertEqual(PAGE_SIZE,18)

class PackTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)/'modpacks'
    def tearDown(self):self.temp.cleanup()
    def test_create_pack(self):
        pack=create_pack('Nowa Paczka','1.21.1','fabric',self.root)
        self.assertTrue((pack/'mods').is_dir())
        self.assertEqual(check_pack(pack,self.root)['loader'],'fabric')
        self.assertEqual(len(list_packs(self.root)),1)
    def test_invalid_name_or_version(self):
        with self.assertRaises(PackError):create_pack('../data','1.21.1','fabric',self.root)
        with self.assertRaises(PackError):create_pack('test','invalid','fabric',self.root)
        with self.assertRaises(PackError):create_pack('test','1.21.1','unsafe',self.root)
    def test_cannot_update_plain_mod_folder(self):
        global_mods=Path(self.temp.name)/'.minecraft'
        (global_mods/'mods').mkdir(parents=True)
        with self.assertRaises(PackError):check_pack(global_mods,self.root)
    def test_cannot_update_unregistered_folder(self):
        unregistered=self.root/'ordinary'
        (unregistered/'mods').mkdir(parents=True)
        with self.assertRaises(OSError):check_pack(unregistered,self.root)
    def test_missing_manifest_rejected(self):
        pack=create_pack('Test','1.20.1','forge',self.root)
        (pack/'minevora_modpack.json').unlink()
        self.assertEqual(list_packs(self.root),[])

class AutoRankingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'ranking.json'
        self.market={'listings':[], 'creator_progress':{'xp':180}}
        self.pvp={'stats':{'wins':3,'losses':1,'kills':7,'deaths':2}}
    def tearDown(self):self.temp.cleanup()
    def test_sync_saved_stats(self):
        data,changed=sync_local(normalize({}), 'MyPlayer',self.market,self.pvp,self.path)
        self.assertTrue(changed)
        row=data['players'][0]
        self.assertEqual(row['nick'],'MyPlayer')
        self.assertEqual(row['wins'],3)
        self.assertEqual(row['kills'],7)
        self.assertEqual(row['xp'],180)
        self.assertEqual(load_local(self.path),data)
    def test_no_change_does_not_write(self):
        data,changed=sync_local(normalize({}), 'MyPlayer',self.market,self.pvp,self.path)
        data2,changed2=sync_local(data, 'MyPlayer',self.market,self.pvp,self.path)
        self.assertFalse(changed2)
        self.assertEqual(data2,data)
    def test_new_xp_auto_updates(self):
        data,_=sync_local(normalize({}), 'MyPlayer',self.market,self.pvp,self.path)
        self.market['creator_progress']['xp']=300
        newer,changed=sync_local(data,'MyPlayer',self.market,self.pvp,self.path)
        self.assertTrue(changed)
        self.assertEqual(newer['players'][0]['xp'],300)
    def test_no_private_fields(self):
        self.pvp['access_token']='private'
        data,_=sync_local(normalize({}),'MyPlayer',self.market,self.pvp,self.path)
        self.assertNotIn('access_token',json.dumps(data))
    def test_nick_validation(self):
        with self.assertRaises(ValueError):sync_local(normalize({}), '../evil',self.market,self.pvp,self.path)

if __name__=='__main__':unittest.main()
