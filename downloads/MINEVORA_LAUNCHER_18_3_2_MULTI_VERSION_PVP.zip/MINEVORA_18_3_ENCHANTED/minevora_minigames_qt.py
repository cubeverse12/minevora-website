"""A real, navigable minigames UI for the MINEVORA launcher.
Gameplay is server-side; this screen does not pretend to host or queue matches.
"""
from PySide6.QtCore import Qt, QSize
from minevora_dashboard import ArtPanel
from minevora_icons import icon_for_label
from PySide6.QtWidgets import QWidget,QVBoxLayout,QGridLayout,QFrame,QLabel,QPushButton,QScrollArea,QHBoxLayout
MODES=(
 ('🛏','BedWars','Sklep, żelazo i złoto z generatorów, obrona łóżka i reset mapy.','/mm join bedwars'),
 ('☁','SkyWars','Wyspy, wyposażenie startowe, skrzynie z łupami i ich uzupełnianie.','/mm join skywars'),
 ('💥','TNT Run','Znikające bloki, przyspieszające rundy i walka o przetrwanie.','/mm join tntrun'),
 ('🏃','Parkour','Checkpointy, osobisty rekord czasu i niezależna meta każdego gracza.','/mm join parkour'),
 ('🏗','Build Battle','Losowane tematy, osobne działki i głosowanie 1–5.','/mm join buildbattle'),
 ('❄','Spleef','Śnieżna arena, łopaty oraz śnieżki odpychające przeciwników.','/mm join spleef'),
 ('⚔','Duels','1v1 z zestawem Classic, Archer lub UHC wybranym na serwerze.','/mm join duels'),
 ('💎','Crystal PvP 1v1','Dwa identyczne zestawy, limity kryształów i krótkie cooldowny.','/mm join crystal_1v1'),
 ('💠','Crystal PvP FFA','Wielu graczy, automatyczne rozliczenie zwycięstwa i reset mapy.','/mm join crystal_ffa'),
)
class MinigamesHub(QScrollArea):
 def __init__(self, play, on_back, parent=None):
  super().__init__(parent)
  self.play=play;self.selected=None
  self.setWidgetResizable(True)
  panel=QWidget();self.setWidget(panel)
  main=QVBoxLayout(panel);main.setContentsMargins(30,26,30,26);main.setSpacing(15)
  row=QHBoxLayout()
  title=QLabel('🎮  MINEVORA MINIGRY');title.setStyleSheet('font-size:25px;font-weight:800;color:#fff')
  row.addWidget(title);row.addStretch()
  back=QPushButton('←  Powrót');back.clicked.connect(on_back);row.addWidget(back);main.addLayout(row)
  hint=QLabel('Wybierz tryb. Crystal PvP 1v1 i Crystal PvP FFA wymagają pluginu MinevoraMinigames 0.3.0 oraz aren na hostingu.')
  hint.setWordWrap(True);hint.setStyleSheet('color:#aec3e7;font-size:13px');main.addWidget(hint)
  grid=QGridLayout();grid.setSpacing(12);self.cards=[]
  for i,(emoji,name,desc,cmd) in enumerate(MODES):
   ident=['bedwars','skywars','tntrun','parkour','buildbattle','spleef','duels','crystal_1v1','crystal_ffa'][i]
   c=ArtPanel('en_'+ident+'.jpg');c.setObjectName('card');c.setMinimumHeight(194);lay=QVBoxLayout(c);lay.setSpacing(7);lay.setContentsMargins(16,13,16,13)
   label=QLabel(name);label.setStyleSheet('font-size:20px;font-weight:800');lay.addWidget(label)
   lay.addStretch(1)
   d=QLabel(desc);d.setWordWrap(True);d.setStyleSheet('color:#ebe1ff;font-size:12px;background:rgba(12,15,44,200);padding:6px;border-radius:6px');lay.addWidget(d)
   b=QPushButton('Wybierz tryb');b.setObjectName('primary');b.clicked.connect(lambda checked=False,n=name:self.choose(n))
   ico=icon_for_label(name)
   if not ico.isNull():b.setIcon(ico);b.setIconSize(QSize(20,20))
   lay.addWidget(b);grid.addWidget(c,i//3,i%3);self.cards.append((name,c,b))
  main.addLayout(grid)
  self.status=QLabel('Żaden tryb nie został wybrany.');self.status.setWordWrap(True)
  self.status.setStyleSheet('font-size:14px;color:#c5b2f5');main.addWidget(self.status)
  warning=QLabel('Uruchomienie Minecraft nie gwarantuje wejścia do wybranej minigry. Automatyczne kierowanie do kolejki wymaga osobnej integracji z siecią serwerów.')
  warning.setWordWrap(True);warning.setStyleSheet('color:#9eb0ce');main.addWidget(warning)
  launch=QPushButton('▶  URUCHOM MINECRAFT');launch.setObjectName('primary');launch.clicked.connect(self.play);main.addWidget(launch)
  main.addStretch()
 def choose(self,name):
  self.selected=name;cmd=next((m[3] for m in MODES if m[1]==name),'/minigames');self.status.setText('Wybrany tryb: '+name+'. Po dołączeniu do serwera wpisz '+cmd+'.')
  for n,c,b in self.cards:
   b.setText('✓ Wybrano' if n==name else 'Wybierz tryb')
