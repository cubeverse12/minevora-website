"""MINEVORA Backup & Restore — native Tk GUI; no third-party libraries."""
from __future__ import annotations

import datetime as dt
import os
import queue
import subprocess
import threading
import zipfile
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from minevora_backup_core import create_backup, restore_backup, roots, validate_backup

BG = '#0b1021'
PANEL = '#141d35'
CARD = '#1c2946'
TEXT = '#eef2ff'
MUTED = '#a6b5d1'
PURPLE = '#8e75ec'
CYAN = '#43c5e7'
SUCCESS = '#56d6ae'
RED = '#ff9b9e'


def open_folder(path: Path):
    if os.name == 'nt':
        os.startfile(str(path))
    elif os.name == 'posix':
        subprocess.Popen(['xdg-open', str(path)])


class MinevoraBackup(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('MINEVORA • Backup & Restore 10.1')
        self.geometry('920x770')
        self.minsize(760, 680)
        self.configure(bg=BG)
        self.events = queue.Queue()
        self.worker = None
        self.cancel = threading.Event()
        self.extra_projects = []
        self.zip_path = tk.StringVar(value='')
        self.restore_mode = tk.StringVar(value='skip')
        self.opt_launcher = tk.BooleanVar(value=True)
        self.opt_minevora = tk.BooleanVar(value=True)
        self.opt_minecraft = tk.BooleanVar(value=True)
        self.opt_mc_full = tk.BooleanVar(value=False)
        self.opt_config = tk.BooleanVar(value=True)
        self.status = tk.StringVar(value='Gotowe do utworzenia kopii zapasowej.')
        self.build()
        self.after(100, self.poll)

    def card(self, parent):
        return tk.Frame(parent, bg=PANEL, highlightbackground='#34415f', highlightthickness=1, padx=16, pady=13)

    def label(self, parent, text, size=11, color=TEXT, bold=False, **kwargs):
        return tk.Label(parent, text=text, fg=color, bg=parent['bg'],
                        font=('Segoe UI', size, 'bold' if bold else 'normal'),
                        anchor='w', justify='left', **kwargs)

    def button(self, parent, text, action, primary=False):
        btn = tk.Button(parent, text=text, command=action, cursor='hand2',
                        fg=BG if primary else TEXT, bg=CYAN if primary else CARD,
                        activebackground=PURPLE, activeforeground=TEXT,
                        relief='flat', bd=0, font=('Segoe UI', 10, 'bold'),
                        padx=14, pady=10)
        return btn

    def checkbox(self, parent, text, variable):
        cb = tk.Checkbutton(parent, text=text, variable=variable,
                            fg=TEXT, bg=parent['bg'], activeforeground=TEXT,
                            activebackground=parent['bg'], selectcolor=CARD,
                            font=('Segoe UI', 10), anchor='w')
        cb.pack(anchor='w', pady=3)
        return cb

    def build(self):
        head = tk.Frame(self, bg=BG, padx=22, pady=15)
        head.pack(fill='x')
        self.label(head, '✦  MINEVORA • BACKUP & RESTORE', 23, CYAN, True).pack(anchor='w')
        self.label(head, 'Przenieś launcher, światy Minecraft, rangi, MVC i projekty na nowy komputer.', 10, MUTED).pack(anchor='w', pady=(5, 0))

        tabs = ttk.Notebook(self)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('TNotebook', background=BG, borderwidth=0)
        style.configure('TNotebook.Tab', padding=(22, 9), font=('Segoe UI', 11, 'bold'), foreground=TEXT, background=CARD)
        style.map('TNotebook.Tab', background=[('selected', PURPLE)])
        style.configure('Minevora.Horizontal.TProgressbar', background=CYAN, troughcolor=CARD, thickness=12)
        tabs.pack(fill='both', expand=True, padx=20, pady=(0, 8))
        backup = tk.Frame(tabs, bg=BG, padx=7, pady=10)
        restore = tk.Frame(tabs, bg=BG, padx=7, pady=10)
        tabs.add(backup, text='  Utwórz kopię  ')
        tabs.add(restore, text='  Przywróć kopię  ')
        self.build_backup(backup)
        self.build_restore(restore)

        bottom = tk.Frame(self, bg=BG, padx=24, pady=10)
        bottom.pack(fill='x')
        self.label(bottom, 'Postęp operacji', 10, TEXT, True).pack(anchor='w')
        self.progress = ttk.Progressbar(bottom, style='Minevora.Horizontal.TProgressbar', mode='determinate', maximum=100)
        self.progress.pack(fill='x', pady=(5, 9))
        self.label(bottom, '', 10).pack()
        self.status_label = self.label(bottom, '', 10, MUTED)
        self.status_label.pack(anchor='w')
        self.status_label.configure(textvariable=self.status)
        row = tk.Frame(bottom, bg=BG)
        row.pack(fill='x', pady=(6, 3))
        self.log = tk.Text(row, height=4, bg=PANEL, fg=MUTED, insertbackground=CYAN,
                           wrap='word', font=('Consolas', 9), relief='flat', padx=10, pady=9)
        self.log.pack(side='left', fill='both', expand=True)
        self.log.configure(state='disabled')
        self.stop_btn = self.button(row, 'Przerwij', self.stop)
        self.stop_btn.pack(side='right', padx=(8, 0), anchor='n')
        self.stop_btn.configure(state='disabled')
        self.log_line('Nie wysyłamy kopii do internetu. Archiwum ZIP nie jest szyfrowane.')

    def build_backup(self, parent):
        c = self.card(parent)
        c.pack(fill='x', pady=(0, 12))
        self.label(c, 'CO CHCESZ ZACHOWAĆ?', 13, CYAN, True).pack(anchor='w', pady=(0, 8))
        self.checkbox(c, 'Pliki programu MINEVORA (kod, grafiki, moduły i start .bat)', self.opt_launcher)
        self.checkbox(c, 'Dane MINEVORA (Marketplace, rangi, XP, MVC, profile, reklamy)', self.opt_minevora)
        self.checkbox(c, 'Minecraft Java (światy, mody, tekstury, shadery, konfiguracja)', self.opt_minecraft)
        self.checkbox(c, 'Pełny folder .minecraft (może zajmować wiele GB)', self.opt_mc_full)
        self.checkbox(c, 'Publiczny Microsoft Client ID (bez haseł i tokenów)', self.opt_config)
        self.label(c, 'Uwaga: kopia nie zawiera tokenów konta Microsoft ani Discorda.', 9, MUTED).pack(anchor='w', pady=(6, 0))

        p = self.card(parent)
        p.pack(fill='x', pady=(0, 12))
        self.label(p, 'DODATKOWE FOLDERY Z PROJEKTAMI', 12, CYAN, True).pack(anchor='w')
        self.label(p, 'Dodaj np. osobne projekty Blender, Blockbench, własną stronę HTML lub serwery Paper.', 9, MUTED).pack(anchor='w', pady=(4, 7))
        r = tk.Frame(p, bg=PANEL)
        r.pack(fill='x')
        self.project_list = tk.Listbox(r, height=3, bg=CARD, fg=TEXT, selectbackground=PURPLE,
                                        relief='flat', font=('Segoe UI', 9), selectmode='single')
        self.project_list.pack(side='left', fill='x', expand=True)
        controls = tk.Frame(r, bg=PANEL)
        controls.pack(side='right', padx=(8, 0))
        self.button(controls, '+ Dodaj folder', self.add_project).pack(fill='x', pady=(0, 5))
        self.button(controls, 'Usuń z listy', self.remove_project).pack(fill='x')

        row = tk.Frame(parent, bg=BG)
        row.pack(fill='x', pady=6)
        self.backup_btn = self.button(row, '💾  UTWÓRZ KOPIĘ ZIP', self.backup_click, True)
        self.backup_btn.pack(side='left')
        self.label(row, 'Wybierzesz miejsce zapisu: pendrive lub dysk zewnętrzny.', 9, MUTED).pack(side='left', padx=12)

    def build_restore(self, parent):
        c = self.card(parent)
        c.pack(fill='x', pady=(0, 12))
        self.label(c, 'WYBIERZ WCZEŚNIEJ UTWORZONĄ KOPIĘ', 13, CYAN, True).pack(anchor='w', pady=(0, 8))
        row = tk.Frame(c, bg=PANEL)
        row.pack(fill='x')
        entry = tk.Entry(row, textvariable=self.zip_path, bg=CARD, fg=TEXT, insertbackground=CYAN,
                         font=('Segoe UI', 10), relief='flat', bd=0)
        entry.pack(side='left', expand=True, fill='x', ipady=9)
        self.button(row, 'Wybierz ZIP', self.select_backup).pack(side='right', padx=(8, 0))
        self.button(c, 'Sprawdź zawartość kopii', self.inspect).pack(anchor='w', pady=(10, 0))

        c2 = self.card(parent)
        c2.pack(fill='x', pady=(0, 12))
        self.label(c2, 'GDZIE TRAFIĄ PLIKI?', 12, CYAN, True).pack(anchor='w')
        self.label(c2, 'MINEVORA → Pobrane/MINEVORA_ODZYSKANA\nDane launchera → %USERPROFILE%\\.minevora\nMinecraft → %APPDATA%\\.minecraft\nProjekty → Dokumenty/MINEVORA_Projekty_Odzyskane', 10, TEXT).pack(anchor='w', pady=(7, 10))
        self.label(c2, 'JEŚLI NA KOMPUTERZE JUŻ SĄ PLIKI:', 11, CYAN, True).pack(anchor='w')
        for value, title in [('skip', 'Pomiń istniejące pliki (najbezpieczniejsze)'),
                             ('replace', 'Zastąp, zachowując poprzednie pliki w folderze bezpieczeństwa')]:
            tk.Radiobutton(c2, text=title, value=value, variable=self.restore_mode,
                           fg=TEXT, bg=PANEL, selectcolor=CARD,
                           activeforeground=TEXT, activebackground=PANEL,
                           font=('Segoe UI', 10)).pack(anchor='w', pady=4)

        row = tk.Frame(parent, bg=BG)
        row.pack(fill='x', pady=5)
        self.restore_btn = self.button(row, '↩  PRZYWRÓĆ PLIKI', self.restore_click, True)
        self.restore_btn.pack(side='left')
        self.label(row, 'Przed przywracaniem zamknij Minecraft i MINEVORA.', 9, MUTED).pack(side='left', padx=12)

    def add_project(self):
        location = filedialog.askdirectory(title='Wybierz folder z projektami (Blender, Blockbench, mapa, serwer)')
        if location:
            location = str(Path(location).resolve())
            if location not in self.extra_projects:
                self.extra_projects.append(location)
                self.project_list.insert('end', location)

    def remove_project(self):
        idx = self.project_list.curselection()
        if idx:
            self.extra_projects.pop(idx[0])
            self.project_list.delete(idx[0])

    def select_backup(self):
        selected = filedialog.askopenfilename(title='Wybierz kopię MINEVORA', filetypes=[('Kopia MINEVORA ZIP', '*.zip')])
        if selected:
            self.zip_path.set(selected)
            self.inspect()

    def inspect(self):
        try:
            path = Path(self.zip_path.get())
            if not path.is_file():
                raise ValueError('Najpierw wskaż plik kopii ZIP.')
            data = validate_backup(path)
            size = data['total_bytes'] / (1024**2)
            messagebox.showinfo('Zawartość kopii',
                                f'Data: {data.get("created_at", "brak")}\n'
                                f'Pliki: {len(data["files"])}\n'
                                f'Dane: {size:,.1f} MB\n'
                                f'Kategorie: {", ".join(k for k,v in data.get("contents", {}).items() if v)}\n\n'
                                'Przed przywróceniem zostaną sprawdzone sumy kontrolne poszczególnych plików.')
        except (OSError, ValueError, KeyError, zipfile.BadZipFile) as err:
            messagebox.showerror('Nie można odczytać kopii', str(err))

    def backup_click(self):
        if self.worker and self.worker.is_alive(): return
        folder = str(Path.home() / 'Documents')
        timestamp = dt.datetime.now().strftime('%Y-%m-%d_%H-%M')
        dest = filedialog.asksaveasfilename(title='Zapisz kopię MINEVORA na pendrivie lub dysku',
                                            initialdir=folder, initialfile=f'MINEVORA_KOPIA_{timestamp}.minevora-backup.zip',
                                            defaultextension='.zip', filetypes=[('Archiwum ZIP', '*.zip')])
        if not dest: return
        if Path(dest).exists():
            messagebox.showerror('Kopia już istnieje', 'Wybierz nową nazwę pliku. Istniejąca kopia nie zostanie nadpisana.')
            return
        selections = {'launcher': self.opt_launcher.get(), 'minevora': self.opt_minevora.get(),
                      'minecraft': self.opt_minecraft.get(), 'minecraft_full': self.opt_mc_full.get(),
                      'config': self.opt_config.get(), 'projects': self.extra_projects[:]}
        self.start_operation('Tworzenie kopii', lambda: create_backup(Path(dest), selections, roots(), self.notify, self.notify_progress, self.cancel), Path(dest))

    def restore_click(self):
        if self.worker and self.worker.is_alive(): return
        archive = Path(self.zip_path.get())
        if not archive.is_file():
            messagebox.showerror('Brak kopii', 'Wybierz kopię ZIP.')
            return
        try:
            info = validate_backup(archive)
        except Exception as err:
            messagebox.showerror('Błędna kopia', str(err))
            return
        overwrite = self.restore_mode.get() == 'replace'
        if not messagebox.askyesno('Potwierdź przywracanie',
                                    f'Przywrócić {len(info["files"])} plików z kopii?\n\n'
                                    'Zamknij Minecraft i MINEVORA.\n'
                                    + ('Istniejące pliki będą kopiowane do folderu bezpieczeństwa przed nadpisaniem.'
                                       if overwrite else 'Istniejące pliki zostaną pominięte.')):
            return
        # A clean destination for the program, user data always mapped to Windows profile.
        destinations = roots(base=Path.home() / 'Downloads' / 'MINEVORA_ODZYSKANA')
        self.start_operation('Przywracanie', lambda: restore_backup(archive, destinations, overwrite, self.notify, self.notify_progress, self.cancel), destinations['launcher'])

    def start_operation(self, task, fn, path):
        self.cancel.clear()
        self.progress.configure(value=0)
        self.status.set(task + '…')
        self.backup_btn.configure(state='disabled')
        self.restore_btn.configure(state='disabled')
        self.stop_btn.configure(state='normal')
        def run():
            try:
                result = fn()
                self.events.put(('done', (task, result, str(path))))
            except InterruptedError as err:
                self.events.put(('stopped', str(err)))
            except Exception as err:
                self.events.put(('error', f'{type(err).__name__}: {err}'))
        self.worker = threading.Thread(target=run, daemon=True)
        self.worker.start()

    def notify(self, message):
        self.events.put(('log', message))

    def notify_progress(self, completed, total):
        self.events.put(('progress', min(100, (completed * 100 / total) if total else 100)))

    def poll(self):
        try:
            while True:
                kind, info = self.events.get_nowait()
                if kind == 'log':
                    self.log_line(info)
                    self.status.set(info[:140])
                elif kind == 'progress':
                    self.progress.configure(value=info)
                elif kind == 'done':
                    task, result, path = info
                    self.finish()
                    self.progress.configure(value=100)
                    self.status.set(task + ' zakończone pomyślnie.')
                    if task == 'Tworzenie kopii':
                        messagebox.showinfo('Kopia gotowa', f'Zapisano {len(result["files"])} plików.\n\n{path}\n\nSkopiuj ZIP na pendrive lub dysk zewnętrzny.')
                    else:
                        messagebox.showinfo('Przywracanie zakończone', f'Przywrócono: {result["restored"]}\nPominięto: {result["skipped"]}\n\nLauncher znajdziesz w Pobrane/MINEVORA_ODZYSKANA.\nUruchom instalację zależności i zaloguj się ponownie.')
                elif kind == 'stopped':
                    self.finish()
                    self.status.set(info)
                    self.log_line('Operacja przerwana. Już przywrócone pliki nie są automatycznie wycofywane.')
                elif kind == 'error':
                    self.finish()
                    self.status.set('Wystąpił błąd — sprawdź dziennik.')
                    self.log_line(info)
                    messagebox.showerror('Błąd operacji', info)
        except queue.Empty:
            pass
        self.after(120, self.poll)

    def finish(self):
        self.backup_btn.configure(state='normal')
        self.restore_btn.configure(state='normal')
        self.stop_btn.configure(state='disabled')

    def stop(self):
        if self.worker and self.worker.is_alive():
            if messagebox.askyesno('Przerwać?', 'Czy na pewno chcesz przerwać bieżącą operację?'):
                self.cancel.set()
                self.status.set('Przerywanie operacji…')

    def log_line(self, line):
        self.log.configure(state='normal')
        self.log.insert('end', str(line) + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')


if __name__ == '__main__':
    # Avoid a tkinter dependency on the core module: stdlib only.
    MinevoraBackup().mainloop()
