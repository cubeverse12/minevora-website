MINEVORA 13.0 — THE ENCHANTED LAUNCHER
===================================== 

Cel:
  Ten sam fioletowo-granatowy motyw co na ekranie Start w całej aplikacji.
  Zachowano istniejące funkcje, dane, profile i nawigację.

ZMIANY W WYGLĄDZIE
- Start: dotychczasowy obraz i aktywne obszary; poprawione etykiety wydania.
- Graj / Wersje: ciemne granatowe karty, fioletowe przyciski i nagłówek portalowy.
- Minigry: 9 trybów z prawdziwymi kartami oraz zachowaną możliwością wyboru.
- PvP: ten sam banner, jednolite obramowania i kontrolki.
- Marketplace: przyciski, filtry i karty w tym samym stylu.
- Ranking: spójne kolory oraz panel nagłówka.
- Discord: portalowy banner, wspólne style Rich Presence i czatu.
- Together: spójne kolory, kontynuacja istniejących połączeń.
- Mody i dodatki: osobne okno z nagłówkiem i zmienioną paletą.
- Skin Creator: nowy nagłówek oraz ujednolicone kolory.
- Ustawienia: okno dialogowe z takim samym nagłówkiem.
- Inne funkcje: wspólny styl przycisków, list, checkboxów, kart i dialogów.

JAK URUCHOMIĆ NA WINDOWS 11
1. Wypakuj cały folder, nie uruchamiaj ze środka pliku ZIP.
2. Zainstaluj Python i dodaj go do PATH.
3. Uruchom INSTALUJ_ZALEZNOSCI.bat (wymaga połączenia z internetem).
4. Uruchom URUCHOM_MINEVORA.bat.
5. Jeśli aplikacja nie startuje, uruchom SPRAWDZ_LAUNCHER.bat.
6. Weryfikacja bez GUI: TESTUJ_MOTYW.bat.

UWAGA DOTYCZĄCA URUCHAMIANIA
- Ta paczka jest projektem Python/PySide6, NIE skompilowanym EXE.
- Kontrola składni i struktury nie potwierdza prawidłowego działania
  wszystkich funkcji. Sprawdź działanie GUI na swoim komputerze.
- Sieć minigier, logowanie, serwery czatu i aktualizacje modów wymagają
  odpowiednich usług lub konfiguracji konta; samo odświeżenie wyglądu
  nie uruchamia hostingu Minecraft.
- Nie wpisuj kluczy API ani tokenów do kodu lub publicznego ZIP.
- Portale i efekty graficzne nie są renderowane w grze Minecraft;
  to motyw interfejsu launchera.
- Ekran Start bazuje na dostarczonej grafice, pozostałe ekrany są
  prawdziwymi kontrolkami Qt o spójnym wyglądzie, a nie kopiami
  rasteryzowanych ekranów 1:1.

MODYFIKACJE TECHNICZNE
- minevora_enchanted_theme.py  : motyw globalny i wspólny banner.
- assets/minevora_section_portal.jpg : obraz bannera.
- minevora_qt.py             : globalny QSS, banner na stronach, dialogi.
- minevora_visual_skin.py    : numer wydania Start.
- inne moduły UI             : ujednolicona paleta kolorystyczna.

Dane użytkownika są przechowywane tak jak wcześniej. Przed zmianą
instalacji zalecamy wykonanie kopii folderu %%USERPROFILE%%\.minevora.
