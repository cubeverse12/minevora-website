"""Regression tests for official Minecraft Java 64x64 skin texture mapping."""
from minevora_skin_geometry import model_parts, face_uvs, validate_skin_uv


def test_vanilla_complete_36_faces():
    for slim in (False,True):
        validate_skin_uv(slim)
        parts=model_parts(slim)
        assert len(parts)==6
        assert sum(len(part.base_uv) for part in parts)==36
        assert sum(len(part.overlay_uv) for part in parts)==36
        assert all(all(x+w<=64 and y+h<=64 for x,y,w,h in (part.base_uv+part.overlay_uv)) for part in parts)


def test_head_is_true_8_cube_and_overlay():
    head=model_parts()[0]
    assert (head.width,head.height,head.depth)==(8,8,8)
    assert (head.x,head.z)==(-4,-4)
    assert head.base_uv==((8,8,8,8),(0,8,8,8),(16,8,8,8),(24,8,8,8),(8,0,8,8),(16,0,8,8))
    assert head.overlay_uv[0]==(40,8,8,8)


def test_each_part_correct_standard_java_uv():
    p={part.name:part for part in model_parts()}
    assert p['body'].base_uv[0]==(20,20,8,12)
    assert p['body'].overlay_uv[0]==(20,36,8,12)
    assert p['right_arm'].base_uv[0]==(44,20,4,12)
    assert p['left_arm'].base_uv[0]==(36,52,4,12)
    assert p['right_leg'].base_uv[0]==(4,20,4,12)
    assert p['left_leg'].base_uv[0]==(20,52,4,12)
    # Side faces must use distinct right and left atlas slots.
    for part in p.values():
        assert part.base_uv[1]!=part.base_uv[2]
        assert part.overlay_uv[1]!=part.overlay_uv[2]


def test_steve_alex_arm_dimensions_and_skin_uv():
    classic=model_parts(False)
    slim=model_parts(True)
    for index in (2,3):
        assert classic[index].width==4
        assert slim[index].width==3
        assert slim[index].base_uv[0][2]==3
        assert slim[index].overlay_uv[0][2]==3
        assert slim[index].base_uv[1][2]==4
    # Different arm type does not flatten head or torso.
    assert slim[0]==classic[0] and slim[1]==classic[1]


def test_all_base_cubes_have_real_depth():
    p=model_parts()
    assert p[0].depth==8
    assert all(part.depth==4 for part in p[1:])
    assert sum(part.depth for part in p)==28


def test_overlay_alpha_and_import_export_paths_remain_integration_code():
    from pathlib import Path
    source=(Path(__file__).resolve().parents[1] / 'minevora_skin3d_qt.py').read_text('utf-8')
    assert 'image.pixelColor' in source
    assert 'if color.alpha()==0:continue' in source
    assert 'self.canvas.skin.save(target' in source
    assert 'self.canvas.replace_skin(image)' in source
    assert 'model_parts(self.slim)' in source
    assert '_surfaces(x-e,y-e,z-e,w+2*e' in source
