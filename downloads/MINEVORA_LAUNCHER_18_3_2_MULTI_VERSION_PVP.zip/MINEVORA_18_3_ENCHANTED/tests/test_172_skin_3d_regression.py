"""Static regression guards for MINEVORA 17.2 skin renderer and skin texture assets."""
from pathlib import Path
import unittest
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]

class Skin3DRegression(unittest.TestCase):
    def test_alpha_safe_renderer(self):
        source=(ROOT/'minevora_skin3d_qt.py').read_text(encoding='utf8')
        self.assertIn('color=image.pixelColor(ux+pixel_x,uy+pixel_y)',source)
        self.assertIn('if color.alpha()==0:continue',source)
        self.assertNotIn('QColor(image.pixel(',source)
    def test_default_png_is_valid_and_has_transparency(self):
        image=Image.open(ROOT/'assets'/'steve_minevora.png').convert('RGBA')
        self.assertEqual(image.size,(64,64))
        self.assertEqual(image.getpixel((8,8))[3],255)
        self.assertEqual(image.getpixel((40,8))[3],0)
    def test_3d_controls_available(self):
        source=(ROOT/'minevora_skin3d_qt.py').read_text(encoding='utf8')
        self.assertIn('set_slim(',source)
        self.assertIn('reset_view(',source)
        self.assertIn('update_3d_model(',source)

if __name__=='__main__':unittest.main()
