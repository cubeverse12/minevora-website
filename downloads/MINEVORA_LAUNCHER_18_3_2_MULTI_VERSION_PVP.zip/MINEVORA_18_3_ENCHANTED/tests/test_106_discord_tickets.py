import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'DISCORD_SETUP'))
from minevora_tickets_core import ticket_topic,is_own_open_ticket,ticket_slug,RULES,TICKET_CATEGORY

def test_id_and_topic():
    assert ticket_topic(123).endswith(';open')
    assert is_own_open_ticket(ticket_topic(123),123)
    assert not is_own_open_ticket(ticket_topic(123),124)
    assert not is_own_open_ticket(ticket_topic(123,True),123)

def test_ticket_slug():
    assert ticket_slug('Miły Gracz!',123)=='ticket-mi-y-gracz-123'
    assert len(ticket_slug('a'*200,123)) <= 95

def test_rules_languages():
    for lang in ('pl','en'):
        assert len(RULES[lang])<2000
        assert 'privacy' in RULES[lang].lower() or 'prywatność' in RULES[lang].lower()
        assert lang in TICKET_CATEGORY
