import unittest
from minevora_loader_core import filter_loader_versions

class LoaderVersionTests(unittest.TestCase):
    def setUp(self):
        self.all = ['1.21.1', '24w14a', '1.20.1', '1.19.4', '1.20.1']
        self.stable = ['1.21.1','1.20.1','1.19.4']
    def test_stable_filter(self):
        self.assertEqual(filter_loader_versions(self.all,self.stable),['1.21.1','1.20.1','1.19.4'])
    def test_snapshot_filter(self):
        self.assertEqual(filter_loader_versions(self.all,self.stable,show_snapshots=True),['1.21.1','24w14a','1.20.1','1.19.4'])
    def test_query(self):
        self.assertEqual(filter_loader_versions(self.all,self.stable,'1.20'),['1.20.1'])
    def test_casefold(self):
        self.assertEqual(filter_loader_versions(self.all,self.stable,'24W',True),['24w14a'])
    def test_no_result(self):
        self.assertEqual(filter_loader_versions(self.all,self.stable,'9.99'),[])
    def test_empty_catalog(self):
        self.assertEqual(filter_loader_versions([],[]),[])
if __name__=='__main__':unittest.main()
