import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from minevora_ads_core import (
    default_data, create_campaign, change_status, validate_campaign, validate_url,
    save_data, load_data, ads_for_slot, record_event, store_image, is_active,
)

FIELDS = dict(title='Wieża PvP', advertiser='MINEVORA', description='Promocja nowej areny Minecraft',
              url='https://example.com/pvp', slot='home', kind='own', start='', end='')


class AdsTests(unittest.TestCase):
    def test_validation_and_local_url_restrictions(self):
        self.assertEqual(validate_url('https://example.com'), 'https://example.com')
        self.assertEqual(validate_url(''), '')
        for bad in ('http://example.com', 'javascript:alert(1)', 'file:///etc/passwd',
                    'https://localhost/admin', 'https://127.0.0.1/', 'https://192.168.1.4/',
                    'https://example.com:80/', 'https://u:p@example.com', 'https://example.com/a b'):
            with self.subTest(url=bad), self.assertRaises(ValueError):
                validate_url(bad)

    def test_own_ad_is_immediately_active(self):
        state = default_data()
        ad = create_campaign(state, FIELDS)
        self.assertEqual(ad['status'], 'active')
        self.assertEqual(ads_for_slot(state, 'home')[0]['id'], ad['id'])
        self.assertEqual(ads_for_slot(state, 'market'), [])

    def test_sponsored_requires_moderation(self):
        state = default_data()
        ad = create_campaign(state, {**FIELDS, 'kind': 'sponsored'})
        self.assertEqual(ads_for_slot(state, 'home'), [])
        change_status(state, ad['id'], 'active')
        self.assertEqual(ads_for_slot(state, 'home')[0]['id'], ad['id'])
        change_status(state, ad['id'], 'paused')
        self.assertFalse(is_active(ad))
        change_status(state, ad['id'], 'rejected')
        self.assertFalse(is_active(ad))

    def test_campaign_schedule(self):
        now = date.today()
        future = (now + timedelta(days=2)).isoformat()
        after = (now + timedelta(days=3)).isoformat()
        state = default_data()
        ad = create_campaign(state, {**FIELDS, 'start': future, 'end': after})
        self.assertFalse(is_active(ad, now.isoformat()))
        self.assertTrue(is_active(ad, future))
        self.assertTrue(is_active(ad, after))
        self.assertFalse(is_active(ad, (now + timedelta(days=4)).isoformat()))
        with self.assertRaises(ValueError):
            validate_campaign(**{**FIELDS, 'start': after, 'end': future})

    def test_persistence_events(self):
        state = default_data()
        ad = create_campaign(state, FIELDS)
        record_event(state, ad['id'], 'impression')
        record_event(state, ad['id'], 'click')
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'ads.json'
            save_data(state, path)
            loaded = load_data(path)
            self.assertEqual(loaded['ads'][0]['impressions'], 1)
            self.assertEqual(loaded['ads'][0]['clicks'], 1)
            self.assertEqual(loaded['events'][0]['action'], 'created')

    def test_invalid_campaigns(self):
        for fields in ({**FIELDS, 'title': ''}, {**FIELDS, 'slot': 'unknown'},
                       {**FIELDS, 'kind': 'other'}, {**FIELDS, 'start': '2026/10/19'}):
            with self.assertRaises(ValueError):
                validate_campaign(**fields)

    def test_copy_verified_images(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            img = root / 'image.png'
            Image.new('RGB', (600, 300), 'purple').save(img)
            saved = store_image(img, root / 'media')
            self.assertTrue(Path(saved).exists())
            self.assertNotEqual(str(img), saved)
            bad = root / 'notimage.png'
            bad.write_text('not a png', encoding='utf-8')
            with self.assertRaises(ValueError):
                store_image(bad, root / 'media')


if __name__ == '__main__':
    unittest.main()
