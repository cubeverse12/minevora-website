"""Offline test of generated Discord permissions: no network and no bot token."""
import ast
from pathlib import Path
from types import SimpleNamespace


def test_installer_bot_can_read_private_channels():
    source = Path(__file__).resolve().parents[1] / 'DISCORD_SETUP' / 'setup_discord.py'
    tree = ast.parse(source.read_text(encoding='utf-8'))
    func = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'category_overwrites')
    # Extract only pure overwrite-building function; never run bot or contact Discord.
    module = ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0), func],type_ignores=[])
    module = ast.fix_missing_locations(module)
    scope = {'discord': SimpleNamespace(PermissionOverwrite=lambda **kwargs: SimpleNamespace(**kwargs))}
    exec(compile(module,str(source),'exec'), scope)
    bot = object(); everyone = object(); team = object(); mod = object()
    guild = SimpleNamespace(default_role=everyone, me=bot)
    roles={'🔧 Zespół MINEVORA':team, '🛡 Moderator MINEVORA':mod}
    for category in ('staff','readonly','public','voice'):
        ow = scope['category_overwrites'](guild,roles,category)
        assert bot in ow, f'Bot missing explicit overwrites for {category}'
        assert ow[bot].view_channel is True
        if category in ('staff','readonly','public'):
            assert ow[bot].send_messages is True
            assert ow[bot].read_message_history is True
        if category=='staff':
            assert ow[everyone].view_channel is False
