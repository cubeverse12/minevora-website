import unittest
from minevora_easy_core import FEATURES,CATEGORY_NAMES,filter_features,fold_text,navigation_group,version_sort_key,sanitize_preferences

class EasyMenuTests(unittest.TestCase):
 def test_search_finds_accents_without_accents(self):
  self.assertEqual(filter_features('nakladka')[0]['title'], 'Nakładka HUD')
 def test_search_multiple_terms(self):
  self.assertTrue(any('Microsoft' in x['title'] for x in filter_features('konto microsoft')))
 def test_categories(self):
  for category in CATEGORY_NAMES[1:]:
   self.assertTrue(filter_features('',category))
   self.assertTrue(all(item['category']==category for item in filter_features('',category)))
 def test_every_feature_has_unique_title(self):
  self.assertEqual(len(set(x['title'] for x in FEATURES)),len(FEATURES))
 def test_all_methods_present_in_main_window_source(self):
  import ast,pathlib
  code=ast.parse((pathlib.Path(__file__).resolve().parents[1]/'minevora_qt.py').read_text(encoding='utf-8'))
  window=next(x for x in code.body if isinstance(x,ast.ClassDef) and x.name=='Window')
  methods={x.name for x in window.body if isinstance(x,ast.FunctionDef)}
  self.assertEqual(set(x['method'] for x in FEATURES)-methods,set())
 def test_main_nav_range(self):
  for i in list(range(19))+[99]:
   self.assertIn(navigation_group(i),range(10))
 def test_minecraft_release_versions_sort_numerically(self):
  versions=['1.9.4','1.19.4','1.21.1','1.20.6','1.8.9']
  self.assertEqual(sorted(versions,key=version_sort_key,reverse=True)[0],'1.21.1')
 def test_corrupt_preferences_are_safe(self):
  result=sanitize_preferences({'font_size':'????','chat_interval':'bad','language':'XX','hud_opacity':2000})
  self.assertEqual(result['font_size'],13)
  self.assertEqual(result['chat_interval'],4)
  self.assertEqual(result['language'],'pl')
  self.assertEqual(result['hud_opacity'],100)
 def test_no_empty_search_matches_all(self):
  self.assertEqual(len(filter_features('')),len(FEATURES))
 def test_pl_english_words(self):
  self.assertIn('rangi',fold_text('RĄNGI'))
if __name__=='__main__': unittest.main()
