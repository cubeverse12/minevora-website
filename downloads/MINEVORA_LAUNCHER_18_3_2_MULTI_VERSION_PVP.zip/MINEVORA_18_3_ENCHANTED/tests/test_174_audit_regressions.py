"""Offline regression tests for modpack integrity, loader selection, and Windows paths."""
import hashlib
import sys
import types
from pathlib import Path
from unittest.mock import Mock
import pytest
import minevora_mrpack as mr

@pytest.mark.parametrize('invalid',[
    '../bad','mods/../evil.jar','mods/CON.txt','AUX','mods/LPT1.cfg',
    'mods/texture.jar.','mods/file.txt ','mods//a.jar','mods/./file.jar',
    'mods\\file.jar','C:/bad.jar','mods/a:b.jar','mods/file?.jar',
    'mods/a/','/absolute/path'])
def test_reject_windows_unsafe_path(invalid):
    with pytest.raises(ValueError):mr.safe_path(invalid)

def test_accept_normal_mod_path():
    assert str(mr.safe_path('mods/sodium.jar'))=='mods/sodium.jar'

def test_download_must_have_hash_before_network(tmp_path):
    with pytest.raises(ValueError,match='sumy'):
        mr.download_verified('https://cdn.modrinth.com/data/test',tmp_path/'a.jar',{},100)
    assert not list(tmp_path.iterdir())

def test_manifest_reject_multiple_loaders(tmp_path,monkeypatch):
    fake_lib=types.ModuleType('minecraft_launcher_lib')
    fake_engine=types.ModuleType('minevora_engine')
    fake_engine.MC_DIR=tmp_path
    monkeypatch.setitem(sys.modules,'minecraft_launcher_lib',fake_lib)
    monkeypatch.setitem(sys.modules,'minevora_engine',fake_engine)
    with pytest.raises(ValueError,match='kilka'):
        mr.install_loader({'minecraft':'1.21.1','fabric-loader':'0.16.1','forge':'52.1.0'})

def test_exact_loader_version_is_forwarded(tmp_path,monkeypatch):
    calls=[]
    class Loader:
        def install(self,mc,directory,*,loader_version):
            calls.append((mc,directory,loader_version))
            installed=f'fabric-loader-{loader_version}-{mc}'
            folder=tmp_path/'versions'/installed
            folder.mkdir(parents=True)
            (folder/(installed+'.json')).write_text('{}')
            return installed
    lib=types.ModuleType('minecraft_launcher_lib')
    lib.mod_loader=types.SimpleNamespace(get_mod_loader=lambda kind:Loader())
    engine=types.ModuleType('minevora_engine')
    engine.MC_DIR=tmp_path
    monkeypatch.setitem(sys.modules,'minecraft_launcher_lib',lib)
    monkeypatch.setitem(sys.modules,'minevora_engine',engine)
    chosen=mr.install_loader({'minecraft':'1.21.1','fabric-loader':'0.16.14'})
    assert chosen=='fabric-loader-0.16.14-1.21.1'
    assert calls==[('1.21.1',str(tmp_path),'0.16.14')]

def test_loader_missing_version_directory_is_failure(tmp_path,monkeypatch):
    lib=types.ModuleType('minecraft_launcher_lib')
    lib.mod_loader=types.SimpleNamespace(get_mod_loader=lambda kind:types.SimpleNamespace(install=lambda *a,**k:'missing'))
    engine=types.ModuleType('minevora_engine')
    engine.MC_DIR=tmp_path
    monkeypatch.setitem(sys.modules,'minecraft_launcher_lib',lib)
    monkeypatch.setitem(sys.modules,'minevora_engine',engine)
    with pytest.raises(RuntimeError,match='kompletnej'):
        mr.install_loader({'minecraft':'1.21.1','fabric-loader':'0.16.14'})

def test_launcher_blocks_close_while_modpack_worker_active():
    source=(Path(__file__).resolve().parents[1]/'minevora_qt.py').read_text(encoding='utf-8')
    assert "('worker','deps_worker','install_worker','modpack_worker')" in source
