import unittest
from minevora_fairplay_core import empty_data, new_player, add_record
from minevora_player_profile_core import profile_snapshot

class TestPlayerProfile(unittest.TestCase):
    def setUp(self):
        self.data=empty_data()
        self.p = new_player(self.data, 'SamplePlayer')

    def test_empty_is_not_automatic_clearance(self):
        view=profile_snapshot(self.p)
        self.assertEqual(view['stats']['bans_total'], 0)
        self.assertEqual(view['ban_servers'],[])

    def test_local_report_counts(self):
        add_record(self.p,kind='ban',server='ArenaPvP',status='aktywny')
        add_record(self.p,kind='ban',server='ArenaPvP',status='cofnięty')
        view=profile_snapshot(self.p)
        self.assertEqual(view['stats']['bans_total'],2)
        self.assertEqual(view['stats']['bans_active'],1)
        self.assertEqual(view['stats']['servers_reported'],1)
        self.assertEqual(view['ban_servers'],['ArenaPvP'])

    def test_approved_vs_reported_related_accounts(self):
        add_record(self.p,kind='linked',server='ArenaPvP',account='SecondUser',status='zgłoszone')
        add_record(self.p,kind='linked',server='ArenaPvP',account='ThirdUser',status='sprawdzone lokalnie')
        add_record(self.p,kind='linked',server='ArenaPvP',account='NotAlt',status='odrzucone')
        view=profile_snapshot(self.p)
        self.assertEqual(view['links_reported'],1)
        self.assertEqual(view['links_checked_locally'],1)
        self.assertEqual(view['stats']['linked_reports'],2)
        self.assertEqual(len(view['groups']['linked']),3)

    def test_alert_not_auto_ban(self):
        add_record(self.p,kind='alert',server='Practice',status='do sprawdzenia')
        view=profile_snapshot(self.p)
        self.assertEqual(view['stats']['bans_total'],0)
        self.assertEqual(view['stats']['alerts_open'],1)

if __name__ == '__main__': unittest.main()
