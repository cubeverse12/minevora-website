"""Regression checks for launcher-owned HUD that appears above Minecraft."""
import ast
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / 'minevora_overlay_core.py'
MAIN = ROOT / 'minevora_qt.py'


def load_overlay():
    spec = importlib.util.spec_from_file_location('minevora_overlay_core', MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_real_fields_only():
    rows = dict(load_overlay().display_rows(186, 'fabric-loader-0.16.10-1.21.1'))
    assert rows == {'version': 'Minecraft: fabric-loader-0.16.10-1.21.1', 'time': 'Czas gry: 00:03:06'}
    assert all(key not in rows for key in ('fps', 'ping', 'world', 'friends'))


def test_missing_version_not_faked():
    assert load_overlay().display_rows(60, None) == [('time', 'Czas gry: 00:01:00')]


def test_disable_both_fields():
    assert load_overlay().display_rows(30, '1.21.1', show_time=False, show_version=False) == []


def test_elapsed_clamped():
    assert dict(load_overlay().display_rows(-8, '1.21.1'))['time'] == 'Czas gry: 00:00:00'


def test_no_placeholder_values_in_launcher():
    code = MAIN.read_text(encoding='utf-8')
    ast.parse(code)
    for bogus in ('FPS: wymaga moda', 'Ping: wymaga moda', 'Serwer: brak odczytu', 'Znajomi: brak integracji'):
        assert bogus not in code
    assert 'self._overlay_version=version' in code
    assert "('version','Wersja Minecraft')" in code
    assert "('time','Czas gry')" in code
