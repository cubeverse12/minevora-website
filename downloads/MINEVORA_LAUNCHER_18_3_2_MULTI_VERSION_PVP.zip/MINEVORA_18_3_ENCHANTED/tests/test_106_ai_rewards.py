from datetime import datetime, timezone, timedelta
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from minevora_rewards import (new_progress, ensure, claim_weekly, can_claim_weekly,boost_remaining,
    activate_boost,award_project,level_of,level_floor,migrate_projects,week_utc)
from minevora_ai_core import offline_reply,backend_url,ask_backend

T=datetime(2026,10,19,11,0,tzinfo=timezone.utc)

def state():return {'balance':0,'listings':[],'creator_progress':new_progress()}

def listing(title='castle',category='Mapy'):
    return {'local_owner':True,'title':title,'category':category,'author':'Tester'}

def test_week_once(monkeypatch):
    s=state()
    assert can_claim_weekly(s,T)
    assert claim_weekly(s,T)==100
    assert s['balance']==100
    assert ensure(s)['boost_inventory']==1
    assert claim_weekly(s,T)==0
    assert s['balance']==100
    assert not can_claim_weekly(s,T)
    assert can_claim_weekly(s,T+timedelta(days=7))

def test_boost_unique_and_expiry():
    s=state();claim_weekly(s,T)
    assert activate_boost(s,T)
    assert not activate_boost(s,T)
    assert boost_remaining(s,T)==1800
    assert award_project(s,listing('unique1'),T+timedelta(minutes=3))==240
    assert award_project(s,listing('unique1'),T+timedelta(minutes=5))==0
    assert award_project(s,listing('unique2'),T+timedelta(minutes=31))==120
    assert boost_remaining(s,T+timedelta(minutes=31))==0
    assert ensure(s)['xp']==360

def test_boost_does_not_backfill_old_projects():
    s=state();s['listings']=[listing('legacy')]
    claim_weekly(s,T);activate_boost(s,T)
    assert migrate_projects(s)==120
    assert migrate_projects(s)==0

def test_bonus_not_a_server_currency():
    s=state();claim_weekly(s,T)
    assert 'xp_boost_until' not in s
    assert s['balance']==100


def test_boundary_new_year():
    # 2026-12-31 and 2027-01-01 may share ISO week
    assert week_utc(datetime(2026,12,31,tzinfo=timezone.utc))==week_utc(datetime(2027,1,1,tzinfo=timezone.utc))


def test_ai_offline_and_endpoint(monkeypatch):
    monkeypatch.delenv('MINEVORA_AI_ENDPOINT',raising=False)
    assert backend_url()==''
    assert 'XP' in offline_reply('Jak działa podwójne XP?')
    assert 'mod' in offline_reply('how to update mods?', 'en').lower()
    monkeypatch.setenv('MINEVORA_AI_ENDPOINT','http://example.com/ask')
    assert backend_url()==''
    monkeypatch.setenv('MINEVORA_AI_ENDPOINT','http://127.0.0.1:8767/ask')
    assert backend_url().startswith('http://127.0.0.1')
    monkeypatch.setenv('MINEVORA_AI_ENDPOINT','https://ai.example.com/ask')
    assert backend_url().startswith('https://')
