"""MINEVORA Fair Play — local, source-labelled moderation notes.

No player tracking, IP correlations, public ban database, or automated cheat
probability. Manual records are not independently verified by the launcher.
"""
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

DATA_PATH = Path.home() / '.minevora' / 'fairplay_notes.json'
MAX_PLAYERS = 250
MAX_RECORDS = 400
NAME_RE = re.compile(r'^[A-Za-z0-9_]{3,16}$')
UUID_RE = re.compile(r'^[0-9a-fA-F]{32}$')
KINDS = ('ban', 'alert', 'linked')
STATUSES = {
    'ban': ('aktywny', 'wygasły', 'cofnięty'),
    'alert': ('do sprawdzenia', 'wyjaśniony', 'zamknięty'),
    'linked': ('zgłoszone', 'sprawdzone lokalnie', 'odrzucone'),
}


def empty_data():
    return {'version': 1, 'players': []}


def clean_uuid(value):
    cleaned = str(value or '').strip().replace('-', '')
    if cleaned and not UUID_RE.fullmatch(cleaned):
        raise ValueError('UUID musi zawierać 32 znaki szesnastkowe (może mieć myślniki).')
    return cleaned.lower()


def clean_name(value):
    name = str(value or '').strip()
    if not NAME_RE.fullmatch(name):
        raise ValueError('Nick Minecraft Java: 3–16 znaków (litery, cyfry, _).')
    return name


def new_player(data, name, uuid=''):
    name = clean_name(name)
    uuid = clean_uuid(uuid)
    if len(data['players']) >= MAX_PLAYERS:
        raise ValueError('Limit 250 lokalnych profili.')
    for player in data['players']:
        if player['name'].casefold() == name.casefold():
            raise ValueError('Ten nick jest już na liście.')
        if uuid and player['uuid'] == uuid:
            raise ValueError('Ten UUID jest już na liście.')
    obj = {'id': uuid4().hex, 'name': name, 'uuid': uuid, 'records': []}
    data['players'].append(obj)
    return obj


def add_record(player, kind, server, detail='', status=None, account='', reference=''):
    if kind not in KINDS:
        raise ValueError('Nieznany typ raportu.')
    server = str(server or '').strip()
    if not server or len(server) > 100:
        raise ValueError('Podaj nazwę serwera lub sieci (maks. 100 znaków).')
    records = player['records']
    if len(records) >= MAX_RECORDS:
        raise ValueError('Limit raportów dla gracza.')
    status = status or STATUSES[kind][0]
    if status not in STATUSES[kind]:
        raise ValueError('Niepoprawny status raportu.')
    detail = str(detail or '').strip()[:500]
    account = str(account or '').strip()
    if kind == 'linked':
        account = clean_name(account)
        if account.casefold() == player['name'].casefold():
            raise ValueError('Powiązane konto musi mieć inny nick.')
    else:
        account = ''
    reference = str(reference or '').strip()[:80]
    item = {'id': uuid4().hex, 'kind': kind, 'server': server, 'detail': detail,
            'status': status, 'account': account, 'reference': reference,
            'source': 'RĘCZNY WPIS — brak niezależnej weryfikacji',
            'created_at': datetime.now(timezone.utc).isoformat(timespec='seconds'), 'review_history': []}
    records.append(item)
    return item


def summary(player):
    records = player.get('records', [])
    bans = [x for x in records if x['kind'] == 'ban']
    active = [x for x in bans if x['status'] == 'aktywny']
    linked = [x for x in records if x['kind'] == 'linked' and x['status'] != 'odrzucone']
    alerts = [x for x in records if x['kind'] == 'alert' and x['status'] == 'do sprawdzenia']
    return {'bans_total': len(bans), 'bans_active': len(active),
            'servers_reported': len({x['server'].casefold() for x in bans}),
            'linked_reports': len(linked), 'alerts_open': len(alerts),
            'review_state': 'Zdarzenia do weryfikacji' if alerts else 'Brak otwartych sygnałów w lokalnej bazie'}


def load_data(path=DATA_PATH):
    try:
        obj = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return empty_data()
    if not isinstance(obj, dict) or not isinstance(obj.get('players'), list):
        return empty_data()
    result = empty_data()
    for raw in obj['players'][:MAX_PLAYERS]:
        if not isinstance(raw, dict):
            continue
        try:
            name = clean_name(raw.get('name', ''))
            uuid = clean_uuid(raw.get('uuid', ''))
        except ValueError:
            continue
        player = {'id': str(raw.get('id') or uuid4().hex)[:80], 'name': name,
                  'uuid': uuid, 'records': []}
        records = raw.get('records', [])
        if isinstance(records, list):
            for item in records[:MAX_RECORDS]:
                if not isinstance(item, dict):
                    continue
                kind = item.get('kind')
                if kind not in KINDS or item.get('status') not in STATUSES[kind]:
                    continue
                server = str(item.get('server') or '').strip()
                if not server:
                    continue
                player['records'].append({
                    'id': str(item.get('id') or uuid4().hex)[:80],
                    'kind': kind, 'server': server[:100],
                    'detail': str(item.get('detail') or '')[:500],
                    'status': item['status'],
                    'account': str(item.get('account') or '')[:16],
                    'reference': str(item.get('reference') or '')[:80],
                    'source': (
                        'IMPORT JSONL — deklarowane przez serwer; brak niezależnego potwierdzenia'
                        if item.get('source') == 'IMPORT JSONL — deklarowane przez serwer; brak niezależnego potwierdzenia'
                        else 'RĘCZNY WPIS — brak niezależnej weryfikacji'),
                    'created_at': str(item.get('created_at') or '')[:40],
                    'updated_at': str(item.get('updated_at') or '')[:40],
                    'review_history': [
                      {'from': str(log.get('from') or '')[:45], 'to': str(log.get('to') or '')[:45],
                       'note': str(log.get('note') or '')[:180], 'at': str(log.get('at') or '')[:40]}
                      for log in (item.get('review_history') if isinstance(item.get('review_history'), list) else [])[-25:]
                      if isinstance(log,dict)],
                })
        result['players'].append(player)
    return result


def save_data(data, path=DATA_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    temporary.replace(path)


def update_record_status(player, record_id, status, note=''):
    """Record a LOCAL review decision, preserving provenance and past status changes.

    Never infer a violation or sanction from an anticheat signal.
    """
    item = next((r for r in player.get('records', []) if r.get('id') == record_id), None)
    if item is None:
        raise ValueError('Nie znaleziono raportu do rozpatrzenia.')
    kind = item.get('kind')
    if kind not in STATUSES or status not in STATUSES[kind]:
        raise ValueError('Nieprawidłowy status raportu.')
    old = item.get('status')
    if old == status:
        return False
    note = str(note or '').strip()
    if len(note) > 180:
        raise ValueError('Notatka może mieć maksymalnie 180 znaków.')
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    history = item.get('review_history')
    if not isinstance(history,list):
        history = []
    history.append({'from':str(old or '')[:45], 'to':status,
                    'note':note, 'at':now})
    item['review_history'] = history[-25:]
    item['status'] = status
    item['updated_at'] = now
    return True


def review_queue(data, include_all=False):
    """List local unresolved entries only, without producing a cheater probability."""
    result = []
    for player in data.get('players', []):
        for report in player.get('records', []):
            kind,status = report.get('kind'),report.get('status')
            unresolved = ((kind == 'alert' and status == 'do sprawdzenia') or
                          (kind == 'linked' and status == 'zgłoszone'))
            if include_all or unresolved:
                result.append({'player_id':player.get('id'), 'player_name':player.get('name'),
                               'record_id':report.get('id'), 'kind':kind,
                               'server':report.get('server'), 'status':status,
                               'created_at':report.get('created_at',''), 'unresolved':unresolved})
    return sorted(result,key=lambda r:(not r['unresolved'],r['created_at']),reverse=False)
