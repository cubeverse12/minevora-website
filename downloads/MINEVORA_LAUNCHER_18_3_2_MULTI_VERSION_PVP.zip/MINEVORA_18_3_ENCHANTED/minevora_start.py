"""Safe startup wrapper, reports missing dependencies and keeps local crash details."""
import runpy
import sys
import traceback
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:sys.path.insert(0,str(BASE))

def install_runtime_reporting():
    """Persist unexpected UI callback failures locally (no network reporting)."""
    old=sys.excepthook
    last=[0.0]
    def handler(exc_type,exc_value,exc_traceback):
        old(exc_type,exc_value,exc_traceback)
        try:
            folder=Path.home()/'.minevora';folder.mkdir(parents=True,exist_ok=True)
            output=folder/'ostatni_blad_runtime.txt'
            output.write_text('MINEVORA 15.0 — błąd interfejsu\n\n'+''.join(traceback.format_exception(exc_type,exc_value,exc_traceback)),encoding='utf-8')
            # Avoid flooding the screen if one callback fails repeatedly.
            if time.monotonic()-last[0]>8:
                print('Błąd funkcji launchera — szczegóły: '+str(output),file=sys.stderr)
                last[0]=time.monotonic()
        except (OSError,ValueError):pass
    sys.excepthook=handler


def main():
    try:
        install_runtime_reporting()
        runpy.run_path(str(BASE/'minevora_qt.py'),run_name='__main__')
        return 0
    except (KeyboardInterrupt,SystemExit) as exc:
        if isinstance(exc,SystemExit):
            try:return int(exc.code or 0)
            except (TypeError,ValueError):return 1
        return 130
    except Exception as exc:
        message=f'{type(exc).__name__}: {exc}'
        print('\nMINEVORA NIE URUCHOMIŁA SIĘ\n'+message,file=sys.stderr)
        if isinstance(exc,ModuleNotFoundError):
            print('Brakuje biblioteki Python. Uruchom INSTALUJ_ZALEZNOSCI.bat.',file=sys.stderr)
        print('Uruchom SPRAWDZ_LAUNCHER.bat, aby sprawdzić wymagania.',file=sys.stderr)
        try:
            output=Path.home()/'.minevora'/'ostatni_blad.txt'
            output.parent.mkdir(parents=True,exist_ok=True)
            output.write_text('MINEVORA — ostatni błąd uruchomienia\n\n'+traceback.format_exc(),encoding='utf-8')
            print('Szczegóły zapisano lokalnie: '+str(output),file=sys.stderr)
        except OSError:pass
        return 1

if __name__=='__main__':sys.exit(main())
