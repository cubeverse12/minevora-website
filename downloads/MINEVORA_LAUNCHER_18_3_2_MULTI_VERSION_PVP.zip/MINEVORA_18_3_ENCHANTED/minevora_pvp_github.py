"""Download only exact-version MINEVORA Fabric releases from the owner's GitHub.

Release assets must contain target Minecraft version in the filename AND in
fabric.mod.json. An older 1.21.1 binary is NEVER used for newer profiles.
"""
from __future__ import annotations
import hashlib
import json
import re
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from minevora_pvp_auto import (
    CACHE_DIR,available_jar,cache_jar,is_hud_jar,jar_minecraft_version,profile_target
)
REPO='cubeverse12/minevora-pvp-hud.'
API='https://api.github.com/repos/'+REPO+'/releases?per_page=100'
MAX_JAR=20_000_000
MAX_API=1_500_000

class NoRelease(RuntimeError):pass

def _version(jar):
    import zipfile
    with zipfile.ZipFile(jar) as z:
        return str(json.loads(z.read('fabric.mod.json')).get('version','0'))

def _vkey(v):
    m=re.match(r'^\d+(?:\.\d+){0,3}',str(v))
    return tuple(int(x) for x in m.group().split('.')) if m else (0,)


def _request(url,limit=MAX_JAR):
    req=urllib.request.Request(url,headers={
        'Accept':'application/vnd.github+json' if url.startswith('https://api.github.com/') else 'application/octet-stream',
        'User-Agent':'MINEVORA-Launcher/18.3-multiversion'})
    with urllib.request.urlopen(req,timeout=25) as response:
        data=response.read(limit+1)
        if len(data)>limit:raise ValueError('Plik jest za duży.')
        return data

def _matching_asset(releases,mc):
    if not isinstance(releases,list):raise ValueError('Nieprawidłowa odpowiedź GitHub Releases.')
    version_regex=re.compile(r'(?<![0-9.])'+re.escape(mc)+r'(?![0-9]|\.[0-9])')
    for release in releases:
        if not isinstance(release,dict) or release.get('draft') or release.get('prerelease'):continue
        assets=release.get('assets',[])
        if not isinstance(assets,list):continue
        for asset in assets:
            name=str(asset.get('name','')).lower()
            if not name.endswith('.jar') or name.endswith(('-sources.jar','-dev.jar','-javadoc.jar')):continue
            if 'minevora' not in name or 'fabric' not in name or not version_regex.search(name):continue
            url=str(asset.get('browser_download_url',''))
            size=asset.get('size',0)
            if not url.startswith('https://github.com/'+REPO+'/releases/download/') or not isinstance(size,int) or not 0<size<=MAX_JAR:continue
            checksum=next((a for a in assets if a.get('name')==asset.get('name')+'.sha256'),None)
            return asset,checksum
    raise NoRelease('Nie ma publicznej wersji PvP HUD dla Fabric '+mc+'.')

def update_from_github(*,version='fabric-1.21.1',progress=None):
    loader,mc=profile_target(version)
    if loader!='fabric' or not mc:raise ValueError('Wybierz profil Fabric z rozpoznawalną wersją gry.')
    if progress:progress('Sprawdzam wydania PvP HUD dla Fabric '+mc+'...')
    try:
        releases=json.loads(_request(API,MAX_API))
        asset,checksum=_matching_asset(releases,mc)
    except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,NoRelease) as exc:
        local=available_jar(mc)
        if local:return 'Nie udało się pobrać wydania dla '+mc+'; zachowano lokalny zgodny mod. Powód: '+str(exc)
        raise NoRelease('Brak zgodnego wydania dla Fabric '+mc+'. Nie zostanie użyty mod z innej wersji. '+str(exc)) from exc
    if progress:progress('Pobieram '+asset['name']+'...')
    data=_request(asset['browser_download_url'],MAX_JAR)
    if checksum is not None:
        url=str(checksum.get('browser_download_url',''))
        if not url.startswith('https://github.com/'+REPO+'/releases/download/'):raise ValueError('Nieprawidłowy adres pliku SHA256.')
        raw=_request(url,1024).decode('ascii')
        m=re.match(r'^[0-9a-fA-F]{64}',raw.strip())
        if not m or hashlib.sha256(data).hexdigest().lower()!=m.group(0).lower():
            raise ValueError('Niezgodna suma SHA256!')
    CACHE_DIR.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=CACHE_DIR,prefix='minevora-',suffix='.jar',delete=False) as f:
        candidate=Path(f.name)
        f.write(data)
    try:
        if not is_hud_jar(candidate,mc):
            raise ValueError('Plik z GitHuba nie jest modem MINEVORA Fabric dla '+mc+'.')
        old=available_jar(mc)
        if old and _vkey(_version(old))>_vkey(_version(candidate)):
            return 'Zachowano nowszą lokalną wersję '+_version(old)+' dla Fabric '+mc+'.'
        cache_jar(candidate)
    finally:
        candidate.unlink(missing_ok=True)
    return 'Pobrano zgodny MINEVORA PvP HUD dla Fabric '+mc+' z GitHub Releases.'
