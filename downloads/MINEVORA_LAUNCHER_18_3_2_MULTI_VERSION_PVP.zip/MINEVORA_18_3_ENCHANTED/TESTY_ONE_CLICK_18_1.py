"""Run: python TESTY_ONE_CLICK_18_1.py (no network needed)."""
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from minevora_oneclick_core import validate_choice,installed_json,find_installed,install_selected

class Loader:
    def __init__(self, base, allowed):self.base=base;self.allowed=allowed;self.count=0
    def is_minecraft_version_supported(self,v):return v in self.allowed
    def install(self,v,root):
        self.count+=1
        out=f'fabric-loader-0.16.0-{v}'
        path=Path(root)/'versions'/out
        path.mkdir(parents=True,exist_ok=True)
        (path/(out+'.json')).write_text('{"id":"test"}')
        return out

class Fake:
    def __init__(self, loader):
        self.loader=loader
        self.mod_loader=SimpleNamespace(get_mod_loader=lambda n:self.loader)
        self.utils=SimpleNamespace(get_version_list=lambda:[{'id':'1.21.1','type':'release'}])
        self.install=SimpleNamespace(install_minecraft_version=self.install_vanilla)
        self.count=0
    def install_vanilla(self,v,root):
        self.count+=1
        p=Path(root)/'versions'/v
        p.mkdir(parents=True,exist_ok=True)
        (p/(v+'.json')).write_text('{"id":"test"}')

class OneClickTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.loader=Loader(self.root,{'1.21.1'})
        self.lib=Fake(self.loader)
    def test_reject_loader(self):
        with self.assertRaises(ValueError):validate_choice('untrusted','1.21.1')
    def test_reject_traversal(self):
        for v in ('../evil','..','evil\\hack'):
            with self.assertRaises(ValueError):validate_choice('fabric',v)
    def test_vanilla_install_and_reuse(self):
        self.assertEqual(install_selected(self.lib,self.root,'vanilla','1.21.1'),('1.21.1',True))
        self.assertEqual(install_selected(self.lib,self.root,'vanilla','1.21.1'),('1.21.1',False))
        self.assertEqual(self.lib.count,1)
    def test_vanilla_missing_version(self):
        with self.assertRaises(ValueError):install_selected(self.lib,self.root,'vanilla','1.18.2')
    def test_fabric_install_and_reuse(self):
        out,_=install_selected(self.lib,self.root,'fabric','1.21.1')
        self.assertEqual(out,'fabric-loader-0.16.0-1.21.1')
        self.assertEqual(find_installed(self.root,'fabric','1.21.1'),out)
        self.assertEqual(install_selected(self.lib,self.root,'fabric','1.21.1')[1],False)
        self.assertEqual(self.loader.count,1)
    def test_reject_unsupported_loader_version(self):
        with self.assertRaises(ValueError):install_selected(self.lib,self.root,'fabric','1.20.4')
        self.assertEqual(self.loader.count,0)
    def test_no_fabric_forge_confusion(self):
        d=self.root/'versions'/'1.21.1-neoforge-21.1.1';d.mkdir(parents=True)
        (d/(d.name+'.json')).write_text('{"id":"test"}')
        self.assertIsNone(find_installed(self.root,'forge','1.21.1'))
    def test_no_version_prefix_collision(self):
        d=self.root/'versions'/'fabric-loader-0.16.0-1.21.10';d.mkdir(parents=True)
        (d/(d.name+'.json')).write_text('{"id":"test"}')
        self.assertIsNone(find_installed(self.root,'fabric','1.21.1'))

if __name__=='__main__':unittest.main(verbosity=2)
