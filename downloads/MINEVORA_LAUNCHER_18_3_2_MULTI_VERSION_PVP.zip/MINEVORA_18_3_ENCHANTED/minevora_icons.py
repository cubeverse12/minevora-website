"""Consistent high-DPI icons used throughout all MINEVORA Qt pages."""
from pathlib import Path
from PySide6.QtCore import QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QPushButton
ROOT=Path(__file__).resolve().parent/'assets'/'icons'
RULES=(
 ('edytor skin','skins'),('skiny 3d','skins'),('skin studio','skins'),('skin','skins'),('graj / wersje','versions'),('wersje','versions'),('wersj','versions'),
 ('minigr','minigames'),('tryb','minigames'),('pvp','pvp'),('duels','pvp'),
 ('market','marketplace'),('sklep','marketplace'),('rang','ranking'),('rank','ranking'),
 ('discord','discord'),('together','together'),('znajom','together'),('ustawieni','settings'),
 ('mody i dodatki','mods'),('mod','mods'),('shad','mods'),('plugin','mods'),('dodatek','mods'),
 ('konta','profile'),('profil','profile'),('logow','profile'),('zalog','profile'),
 ('instal','download'),('pobierz','download'),('eksport','download'),('wyszuk','search'),('szuk','search'),
 ('czat','chat'),('chat','chat'),('pomoc ai','ai'),('asystent','ai'),('guard','shield'),('fair play','shield'),
 ('graj','play'),('uruchom','play'),('start','home'),('główna','home'),('home','home'),
 ('pakiet','package'),('modpack','package'),
)
_cache={}
def icon_for_label(label):
    s=str(label).lower()
    name=next((name for part,name in RULES if part in s),'')
    if not name:return QIcon()
    if name not in _cache:_cache[name]=QIcon(str(ROOT/(name+'.png')))
    return _cache[name]
def apply_clear_icons(root):
    """Always refresh, including buttons rebuilt while changing Modrinth categories."""
    for button in root.findChildren(QPushButton):
        caption=button.text().strip()
        # Sidebar labels already have the new image icon; remove fallback Unicode glyphs.
        if button.objectName()=='nav' and '  ' in caption:
            prefix,clean=caption.split('  ',1)
            if clean.strip():
                button.setText(clean.strip())
                caption=clean.strip()
        ico=icon_for_label(caption)
        if not ico.isNull():
            button.setIcon(ico)
            button.setIconSize(QSize(24 if button.objectName()=='nav' else 20,24 if button.objectName()=='nav' else 20))
            button.setProperty('minevoraCrispIconApplied',True)
