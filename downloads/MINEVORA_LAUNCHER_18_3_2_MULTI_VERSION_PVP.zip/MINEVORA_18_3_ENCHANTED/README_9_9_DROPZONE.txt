MINEVORA 9.9 — MARKETPLACE DRAG & DROP
==================================

NOWE: specjalne pole na plik projektu w oknie "Dodaj projekt".
- Przeciągnij jeden plik z Eksploratora Windows w wyznaczone pole.
- Albo kliknij "Wybierz plik z komputera".
- Osobne pole na miniaturę (PNG/JPG/WebP), również drag & drop.
- Od razu zobaczysz nazwę pliku, jego rozszerzenie, rozmiar i komunikat o błędzie.
- Możesz usunąć wybrany plik i wybrać inny.
- Nazwa projektu uzupełni się sama z nazwy pliku, jeśli wcześniej jest pusta.
- Dla .blend i .bbmodel aplikacja może automatycznie ustawić odpowiednią kategorię.
- Walidacja formatu działa przed zapisaniem; limit projektów: 128 MB, miniaturek: 12 MB.

JAK DODAĆ MODEL
1. Uruchom URUCHOM_MINEVORA.bat.
2. Marketplace -> Dodaj projekt / Dodaj rig / Model Blender / Model Blockbench.
3. PRZECIĄGNIJ plik na duże fioletowe pole; zdjęcie na mniejsze pole Miniatura.
4. Wpisz nick autora, ewentualnie opis i licencję.
5. Kliknij "Dodaj projekt lokalnie".

ZACHOWANIE DANYCH
- Pliki są tylko kopiowane na komputer do %USERPROFILE%\.minevora\market_assets.
- To wciąż demo lokalne! Nie publikuje plików w sieci ani nie wysyła ich do innych graczy.
- Dotychczasowe dane 9.8 pozostają dostępne.
- Nie używaj cudzych modeli bez uprawnień.

INSTALACJA: ZIP -> Wyodrębnij wszystkie -> INSTALUJ_ZALEZNOSCI.bat (jeśli potrzeba)
-> URUCHOM_MINEVORA.bat. W razie ręcznej aktualizacji skopiuj także minevora_dropzone.py.

UWAGA: Logika i składnia zostały sprawdzone w środowisku bez PySide6/Windows.
Interfejs drag & drop wymaga testu na komputerze użytkownika.
