"""Tests for auto PvP deployment without Minecraft installation or network."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import minevora_pvp_auto as a


def make_hud_jar(dest, valid=True):
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, 'w') as z:
        z.writestr('fabric.mod.json', json.dumps({'id': a.MOD_ID if valid else 'other', 'environment':'client','depends':{'minecraft':'1.21.1'}}))
        z.writestr(a.MOD_CLASS, b'\xca\xfe\xba\xbe' + b'X'*200)
    return dest


class AutoPvpTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.cache=self.root/'cache'/'pvp.jar'
        patcher=patch.object(a,'CACHE_JAR',self.cache)
        patcher.start();self.addCleanup(patcher.stop)
        patcher2=patch.object(a,'BUNDLED_JAR',self.root/'empty-bundle.jar')
        patcher2.start();self.addCleanup(patcher2.stop)

    def test_compatibility_is_exact(self):
        for v in ('fabric-loader-0.16.10-1.21.1','fabric-1.21.1','1.21.1-fabric','FABRIC-LOADER-1.21.1'):
            self.assertTrue(a.supports_hud(v),v)
        for v in ('1.21.1','fabric-1.21.2','fabric-1.21','neoforge-1.21.1','quilt-1.21.1','forge-1.21.1','26.3-rc-2','fabric-loader-1.21.11'):
            self.assertFalse(a.supports_hud(v),v)

    def test_cache_only_verified_jar(self):
        valid=make_hud_jar(self.root/'good.jar')
        self.assertTrue(a.is_hud_jar(valid))
        self.assertEqual(a.cache_jar(valid),self.cache)
        self.assertTrue(a.is_hud_jar(self.cache))
        invalid=make_hud_jar(self.root/'bad.jar',False)
        with self.assertRaises(ValueError):a.cache_jar(invalid)
        self.assertTrue(a.is_hud_jar(self.cache))

    def test_one_time_cache_then_auto_install_into_second_profile(self):
        source=make_hud_jar(self.root/'existing'/'mods'/'minevora-pvp-hud-1.jar')
        one=self.root/'first'
        two=self.root/'second'
        state,_=a.provision('fabric-loader-0.16-1.21.1',one,alternate_dirs=[source.parent.parent])
        self.assertEqual(state,'ready')
        self.assertTrue((one/'mods'/self.cache.name).exists())
        state,_=a.provision('fabric-loader-0.16-1.21.1',two)
        self.assertEqual(state,'ready')
        self.assertTrue((two/'mods'/self.cache.name).exists())

    def test_unsupported_version_disables_only_matching_hud(self):
        mods=self.root/'instance'/'mods'
        jar=make_hud_jar(mods/'minevora-pvp-hud-foo.jar')
        keep=mods/'other-fabric-mod.jar';keep.write_bytes(b'OTHER')
        state,_=a.provision('neoforge-1.21.1',self.root/'instance')
        self.assertEqual(state,'unsupported')
        self.assertFalse(jar.exists())
        self.assertTrue((mods/(jar.name+'.disabled')).exists())
        self.assertTrue(keep.exists())

    def test_disabled_foreign_mislabeled_jar_untouched(self):
        mods=self.root/'instance'/'mods'
        fake=make_hud_jar(mods/'minevora-pvp-hud-foreign.jar',False)
        a.provision('quilt-1.21.1',self.root/'instance')
        self.assertTrue(fake.exists())

    def test_missing_jar_does_not_claim_working(self):
        state,msg=a.provision('fabric-loader-1.21.1',self.root/'instance')
        self.assertEqual(state,'missing')
        self.assertIn('Brak',msg)
        self.assertFalse((self.root/'instance'/'mods').exists())

if __name__=='__main__':unittest.main(verbosity=2)
