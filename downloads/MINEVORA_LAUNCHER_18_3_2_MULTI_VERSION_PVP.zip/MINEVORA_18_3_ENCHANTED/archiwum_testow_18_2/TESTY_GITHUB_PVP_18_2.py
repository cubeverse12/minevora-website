"""No-network regression tests for MINEVORA GitHub update and auto-provisioning."""
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import minevora_pvp_auto as auto
import minevora_pvp_github as github


def jar(path, version='2.0.2', mod_id='minevorapvphud'):
    path.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':mod_id,'version':version,'environment':'client','depends':{'minecraft':'1.21.1'}}))
        z.writestr('pl/minevora/pvphud/MinevoraPvpHud.class',b'\xca\xfe\xba\xbe'+b'A'*200)
    return path

class GithubUpdaterTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        self.cache=self.root/'cache'/'hud.jar'
        self.bundle=jar(self.root/'bundled.jar',version='2.0.2')
        self.patchers=[patch.object(auto,'CACHE_JAR',self.cache),
                       patch.object(auto,'BUNDLED_JAR',self.bundle),
                       patch.object(auto,'CACHE_DIR',self.root/'cache'),
                       patch.object(github,'CACHE_JAR',self.cache),
                       patch.object(github,'BUNDLED_JAR',self.bundle),
                       patch.object(github,'CACHE_DIR',self.root/'cache')]
        for p in self.patchers:p.start();self.addCleanup(p.stop)

    def test_jar_id_exact(self):
        self.assertEqual(auto.MOD_ID,'minevorapvphud')
        self.assertTrue(auto.is_hud_jar(self.bundle))
        self.assertFalse(auto.is_hud_jar(jar(self.root/'wrong.jar',mod_id='minevora_pvp_hud')))

    def test_fallback_when_no_release(self):
        with patch.object(github,'_github_release',side_effect=github.NoRelease('none')):
            message=github.update_from_github()
        self.assertIn('lokalna',message)
        self.assertEqual(github._version(self.cache),'2.0.2')
        inst=self.root/'mc'
        state,_=auto.provision('fabric-loader-0.16.10-1.21.1',inst)
        self.assertEqual(state,'ready')
        self.assertEqual(github._version(inst/'mods'/self.cache.name),'2.0.2')

    def test_new_release_replaces_older_installed_mod(self):
        old=jar(self.root/'old.jar','2.0.0')
        auto.cache_jar(old)
        dest=self.root/'mc'/'mods'/self.cache.name
        auto.provision('fabric-loader-0.16.10-1.21.1',self.root/'mc')
        self.assertEqual(github._version(dest),'2.0.0')
        release=jar(self.root/'new.jar','2.0.3').read_bytes()
        with patch.object(github,'_github_release',return_value=('https://github.com/cubeverse12/minevora-pvp-hud./releases/download/pvp-9/test.jar',None,'test.jar')):
            with patch.object(github,'_request',return_value=release):
                status=github.update_from_github()
        self.assertIn('2.0.3',status)
        auto.provision('fabric-loader-0.16.10-1.21.1',self.root/'mc')
        self.assertEqual(github._version(dest),'2.0.3')
        self.assertTrue((self.root/'cache'/'backups').is_dir())

    def test_old_github_release_does_not_downgrade(self):
        auto.cache_jar(self.bundle)
        payload=jar(self.root/'old.jar','2.0.0').read_bytes()
        with patch.object(github,'_github_release',return_value=('https://github.com/cubeverse12/minevora-pvp-hud./releases/download/old/test.jar',None,'test.jar')):
            with patch.object(github,'_request',return_value=payload):
                result=github.update_from_github()
        self.assertIn('nowsza',result)
        self.assertEqual(github._version(self.cache),'2.0.2')

    def test_rejects_mislabeled_foreign_jar(self):
        foreign=jar(self.root/'foreign.jar','9.0.0','notminevora').read_bytes()
        with patch.object(github,'_github_release',return_value=('https://github.com/cubeverse12/minevora-pvp-hud./releases/download/new/test.jar',None,'test.jar')):
            with patch.object(github,'_request',return_value=foreign):
                with self.assertRaisesRegex(ValueError,'poprawnym modem'):
                    github.update_from_github()
        self.assertFalse(self.cache.exists())

if __name__=='__main__':unittest.main(verbosity=2)
