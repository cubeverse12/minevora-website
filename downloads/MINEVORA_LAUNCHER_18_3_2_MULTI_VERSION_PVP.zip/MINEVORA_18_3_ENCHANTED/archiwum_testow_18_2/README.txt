Te testy dotyczyły starego instalatora 18.2 dla wyłącznie Fabric 1.21.1. Zastąpione przez TESTY_MULTI_VERSION_PVP.py.
