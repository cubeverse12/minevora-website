"""MINEVORA Qt backend. Tokens are kept only in process memory."""
import json
import os
import re
import subprocess
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import minecraft_launcher_lib
from PySide6.QtCore import QThread, Signal

MC_DIR = Path(os.environ.get('APPDATA', str(Path.home()))) / '.minecraft'
CONFIG = Path(os.environ.get('APPDATA', str(Path.home()))) / 'MINEVORA' / 'config.json'
REDIRECT = 'http://localhost:8765/callback'


def client_id():
    try:
        return str(json.loads(CONFIG.read_text(encoding='utf-8')).get('client_id', '')).strip()
    except (OSError, ValueError, TypeError):
        return ''


def save_client_id(value):
    if not re.fullmatch(r'[a-fA-F0-9-]{36}', value):
        raise ValueError('Client ID musi mieć format GUID (36 znaków).')
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    try:
        data = json.loads(CONFIG.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        pass
    data['client_id'] = value
    CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


class LoginWorker(QThread):
    done = Signal(object)
    error = Signal(str)
    status = Signal(str)

    def __init__(self, application_id):
        super().__init__()
        self.application_id = application_id

    def run(self):
        try:
            ms = minecraft_launcher_lib.microsoft_account
            data = ms.get_secure_login_data(self.application_id, REDIRECT)
            # Some minecraft-launcher-lib versions return a tuple instead of a dict.
            if isinstance(data, tuple):
                if len(data) >= 3:
                    data = {'login_url': data[0], 'state': data[1], 'code_verifier': data[2]}
                else:
                    raise RuntimeError('Nieobsługiwany format danych OAuth. Zaktualizuj minecraft-launcher-lib.')
            if not isinstance(data, dict):
                raise RuntimeError('Nieobsługiwany format odpowiedzi OAuth.')
            state = data.get('state')
            result = {}
            received = threading.Event()

            class Callback(BaseHTTPRequestHandler):
                def do_GET(self):
                    parsed = urllib.parse.urlparse(self.path)
                    if parsed.path != '/callback':
                        self.send_error(404)
                        return
                    values = urllib.parse.parse_qs(parsed.query)
                    result.update({key: values[key][0] for key in values if values[key]})
                    body = 'Mozesz wrocic do MINEVORA.'.encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/plain; charset=utf-8')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    received.set()

                def log_message(self, *_):
                    pass

            server = HTTPServer(('127.0.0.1', 8765), Callback)
            server.timeout = 1
            try:
                self.status.emit('Zaloguj się na stronie Microsoft w przeglądarce…')
                webbrowser.open(data['login_url'])
                for _ in range(180):
                    if received.is_set():
                        break
                    server.handle_request()
            finally:
                server.server_close()
            if not received.is_set():
                raise RuntimeError('Przekroczono czas logowania (3 minuty).')
            if result.get('error'):
                raise RuntimeError(result.get('error_description', result['error']))
            if state and result.get('state') != state:
                raise RuntimeError('Nieprawidłowy stan logowania OAuth.')
            code = result.get('code')
            if not code:
                raise RuntimeError('Nie otrzymano kodu logowania.')
            session = ms.complete_login(self.application_id, None, REDIRECT, code, data.get('code_verifier'))
            self.done.emit(session)
        except Exception as exc:
            self.error.emit(str(exc))


class PlayWorker(QThread):
    status = Signal(str)
    error = Signal(str)
    finished_game = Signal(int)

    def __init__(self, version, ram_gb, session, game_dir=None):
        super().__init__()
        self.version, self.ram_gb, self.session = version, ram_gb, session
        self.game_dir = str(game_dir) if game_dir else str(MC_DIR)

    def run(self):
        try:
            if not self.session or not self.session.get('access_token'):
                raise RuntimeError('Najpierw zaloguj się na konto Microsoft.')
            options = {
                'username': self.session['name'],
                'uuid': self.session['id'],
                'token': self.session['access_token'],
                'jvmArguments': [f'-Xmx{self.ram_gb}G', '-Xms1G'],
                'gameDirectory': self.game_dir,
            }
            command = minecraft_launcher_lib.command.get_minecraft_command(self.version, str(MC_DIR), options)
            self.status.emit(f'Uruchamianie {self.version} • RAM {self.ram_gb} GB…')
            flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            # Never print or log command arguments: they contain an access token.
            process = subprocess.Popen(command, cwd=self.game_dir, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL, creationflags=flags)
            self.status.emit(f'Minecraft działa • PID {process.pid}')
            code = process.wait()
            self.finished_game.emit(code)
        except Exception as exc:
            self.error.emit(str(exc))
