# MINEVORA 18.3 • Enchanted

Wspólny motyw launchera i strony WWW: kolorystyka, karty, aktywna nawigacja i nagłówki.

## Co nowego
- Odświeżona paleta zgodna z design_tokens.json we wszystkich aplikacjach.
- Nowa zakładka „Co nowego” z działającymi skrótami do PvP HUD, profili i ustawień.
- Nowa zakładka „Pomoc” z FAQ i przyciskiem otwierającym konfigurację PvP HUD.
- Dashboard z wyróżnioną wersją 18.3 i przejściem do PvP HUD.
- Zachowane funkcje wydania 18.2, w tym lokalny mod PvP i jego aktualizator GitHub Releases.

## Ważne
PvP HUD obsługuje Minecraft Java 1.21.1 Fabric. Sam launcher ma obsługę większej liczby wersji i loaderów, lecz nie rozszerza to zgodności samego moda.

Uruchom INSTALUJ_ZALEZNOSCI.bat (gdy biblioteki nie są dostępne), a potem URUCHOM_MINEVORA.bat. Wymagany jest Python z PySide6 i inne zależności wskazane w requirements.txt. Nie jest to plik EXE.

Nowa wersja nie została jeszcze przetestowana graficznie w Windows; wykonano testy statyczne, kontroli ZIP i składni kodu.
