MINEVORA 10.7 — EASY EDITION
============================

DODATKOWO: PROFILE GRACZY
- Wszystkie funkcje → Profile graczy / Fair Play → wybierz nick → Otwórz profil.
- Osobne zakładki w profilu: Podsumowanie, Bany, Powiązane konta, Antycheat.
- Usuwanie pojedynczych lokalnych zgłoszeń i całego profilu po potwierdzeniu.
- Brak zewnętrznego skanowania multikont lub banów. Wpisy są ręczne lub importowane.
- Brak raportu NIE oznacza braku banów na całym świecie.

CO ZMIENIONO
- 8 najważniejszych przycisków w lewym menu zamiast 19.
- Wszystkie pozostałe funkcje w jednym, przeszukiwalnym Centrum Funkcji.
- Ctrl+K otwiera wyszukiwanie funkcji w górnym pasku.
- Czat można schować i pokazać, a jego stan zostaje zapamiętany.
- Strona główna prowadzi przez 3 kroki: Microsoft → instalacja wersji → Graj.
- Ustawienia podzielone na: Podstawowe i Zaawansowane.
- Marketplace: wyszukiwanie i kategoria na górze; pozostałe opcje na żądanie.
- Dodawanie projektu: główne pola na wierzchu, reszta opcjonalna.
- Modrinth ładuje listę projektów po otwarciu (wymaga internetu).
- Poprawki: sortowanie wersji Minecraft, walidacja sesji Microsoft,
  odporność na błędne wartości w preferences.json i config.json.
- Samodzielne narzędzie diagnostyczne oraz informacja o błędach startowych.

JAK URUCHOMIĆ (WINDOWS 11)
1. Zamknij starszą wersję MINEVORA i Minecraft.
2. Rozpakuj ZIP do nowego folderu.
3. Kliknij INSTALUJ_ZALEZNOSCI.bat i poczekaj na instalację.
4. Kliknij URUCHOM_MINEVORA.bat.
5. Jeśli coś nie działa — kliknij SPRAWDZ_LAUNCHER.bat.
6. Otwórz 'Wszystkie funkcje', aby znaleźć starsze moduły.

WAŻNE
- Nie usuwaj folderu %%USERPROFILE%%\.minevora: zawiera dotychczasowy postęp.
- Możesz wcześniej zrobić kopię przyciskiem 'Kopia zapasowa'.
- Marketplace i MVC nadal są lokalnymi funkcjami demonstracyjnymi.
- AI online wymaga prywatnego backendu, a rzeczywiste FPS wymagają moda.
- Publiczna sieć serwerów i płatności nadal wymagają osobnej infrastruktury.
- Żaden z modułów nie został podłączony automatycznie do kont online.
- Nie udostępniaj publicznie tokenów logowania, webhooków i backupów.

TESTY
- Kontrola składni wszystkich modułów Python.
- 62 testy unittest (w tym 12 testów obsługi prostego menu i diagnostyki).
- 10 testów HTTP czatu + 10 testów Guard Bot + 8 testów Backup.
- Nie przetestowano faktycznego wyświetlania PySide6 ani logowania Microsoft
  na Windows, ponieważ środowisko testowe nie zawiera PySide6 ani Minecraft.
