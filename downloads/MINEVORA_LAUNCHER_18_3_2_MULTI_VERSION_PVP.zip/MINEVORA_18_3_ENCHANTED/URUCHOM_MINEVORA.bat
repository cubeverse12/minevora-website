@echo off
cd /d "%~dp0"
setlocal
where py >nul 2>nul
if not errorlevel 1 (
 py -3 minevora_qt.py
) else (
 python minevora_qt.py
)
if errorlevel 1 (
 echo.
 echo MINEVORA 18.3 nie uruchomila sie. Sprawdz zaleznosci i komunikaty powyzej.
 pause
)
