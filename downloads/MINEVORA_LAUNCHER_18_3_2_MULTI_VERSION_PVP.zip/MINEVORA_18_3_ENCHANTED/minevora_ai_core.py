"""Privacy-first MINEVORA offline knowledge base and optional API connector."""
import json
import os
import urllib.parse
import urllib.request
from pathlib import Path

OFFLINE_PL = (
    (('minecraft', 'uruchom', 'start'), 'Uruchamianie: wybierz instancję Minecraft Java, ustaw RAM i kliknij ▶ GRAJ. Jeśli gra nie startuje, otwórz Diagnostykę.'),
    (('nie ma pliku', 'no such file', 'powershell', 'terminal'), 'W PowerShell przejdź najpierw do folderu z minevora_qt.py, np. cd "C:\\Users\\TwojaNazwa\\Downloads\\MINEVORA", a dopiero potem python .\\minevora_qt.py. Najwygodniej użyj URUCHOM_MINEVORA.bat.'),
    (('modrinth', 'modów', 'mody', 'fabric', 'forge'), 'Przejdź do Mody → Modrinth. Sprawdź zgodność moda z wersją Minecraft oraz loaderem. Przed aktualizacją zamknij Minecraft i zachowaj kopię modów.'),
    (('discord', 'ticket', 'zgłosze'), 'W Discord Hub znajdziesz link społeczności. Tickety na Discordzie wymagają osobnego bota z folderu DISCORD_SETUP. W kanale 🎫・otworz-ticket kliknij przycisk otwarcia zgłoszenia.'),
    (('rang', 'xp', 'level', 'bonus', 'podwój'), 'Otwórz Rangi twórcy. Za unikalne mapy i budowle dostajesz XP, a bonus tygodniowy daje 100 MVC (demo) i booster ×2 XP na 30 minut po aktywacji.'),
    (('marketplace', 'modele', 'blender', 'blockbench', 'rig'), 'W Marketplace → Dodaj projekt możesz przeciągnąć plik modelu, rig lub mapę do pola Drag & Drop. Projekty zapisują się na komputerze; publikacja internetowa wymaga serwera.'),
    (('kopia', 'backup', 'przenie', 'komputer'), 'Otwórz Kopia danych. Zapisz archiwum ZIP na prywatnym nośniku, a na nowym komputerze wybierz Przywróć kopię. Zaloguj się ponownie do Microsoft.'),
    (('microsoft', 'client id', 'konto'), 'Do Minecraft Java potrzebujesz oficjalnego logowania Microsoft. Nigdy nie podawaj hasła ani tokenów w czacie. Jeśli pojawi się Client ID, sprawdź konfigurację aplikacji OAuth.'),
    (('pvp', 'arena', 'antycheat', 'guard'), 'PvP Arena: tryby Sword, Crystal, Axe, UHC, BedWars i SkyWars. Guard jest prototypem antycheata dla Paper; wyniki wymagają weryfikacji moderatora.'),
)

OFFLINE_EN = (
    (('start', 'launch', 'play'), 'Choose a Minecraft Java instance and click PLAY. For errors, open Diagnostics.'),
    (('mod', 'modrinth', 'fabric', 'forge'), 'Open Mods → Modrinth, pick the matching Minecraft version and loader, and back up existing mods before updating.'),
    (('discord', 'ticket', 'report'), 'Use the Discord Hub to join MINEVORA. The support-ticket bot is configured separately in DISCORD_SETUP.'),
    (('xp', 'boost', 'bonus', 'rank', 'level'), 'Creator Ranks gives XP for unique projects. Claim a weekly bonus for 100 demo MVC and a 2× XP booster lasting 30 minutes after activation.'),
    (('market', 'blender', 'blockbench', 'rig'), 'Marketplace supports dragging a model or rig into its file drop zone. Online publishing is not available yet.'),
    (('backup', 'new pc', 'restore'), 'Use Backup & Restore and keep your ZIP private; sign in to Microsoft again on the new PC.'),
)

def offline_reply(question, language='pl'):
    q = ' '.join(str(question).casefold().split())
    if not q: return 'Napisz pytanie o MINEVORA.' if language == 'pl' else 'Ask a question about MINEVORA.'
    rules = OFFLINE_EN if language == 'en' else OFFLINE_PL
    matches = sorted(((sum(key in q for key in keys), idx, answer) for idx, (keys, answer) in enumerate(rules)),reverse=True)
    if matches and matches[0][0] > 0: return matches[0][2]
    return ('Jestem lokalnym pomocnikiem MINEVORA. Zapytaj o instalację, mody, Marketplace, XP, konto Microsoft, Discord lub backup. Aby korzystać z pełnego AI, skonfiguruj prywatny backend API.' if language == 'pl' else 'I am the local MINEVORA helper. Ask about Minecraft installation, mods, Marketplace, ranks, Discord or backup. Full AI requires a configured private API backend.')


def backend_url():
    url = os.getenv('MINEVORA_AI_ENDPOINT','').strip()
    if not url: return ''
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme == 'https' and parsed.hostname: return url
    if parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', 'localhost', '::1'): return url
    return ''


def ask_backend(question, language='pl', url=None):
    url = url or backend_url()
    if not url: raise ValueError('Brak skonfigurowanego prywatnego serwera AI.')
    if len(question)>2500: raise ValueError('Wiadomość jest zbyt długa.')
    payload=json.dumps({'question':question,'language':language},ensure_ascii=False).encode('utf-8')
    request=urllib.request.Request(url,data=payload,headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(request,timeout=25) as response:
        obj=json.loads(response.read(15000).decode('utf-8'))
    answer=obj.get('answer','') if isinstance(obj,dict) else ''
    if not isinstance(answer,str) or not answer.strip():raise ValueError('Brak poprawnej odpowiedzi AI.')
    return answer[:10000]
