MINEVORA 11.4.1 — DISCORD LINK
============================

Nowosc:
- Staly przycisk «💬 DOŁĄCZ NA DISCORD» w lewym panelu launchera.
- Kliknięcie otwiera https://discord.gg/8teEpYvzRd w domyślnej przeglądarce.
- Nadal dostepny przycisk zaproszenia w sekcji «Discord».
- Przyjazny wyglad w kolorystyce Discord, zgodny z motywem MINEVORA.
- Przycisk wspiera jezyk polski i angielski.

Uruchomienie:
1. Rozpakuj caly ZIP.
2. Uruchom URUCHOM_MINEVORA.bat.
3. Kliknij «DOŁĄCZ NA DISCORD» w lewym panelu.

Link jest zapisany w minevora_discord_core.py (OFFICIAL_MINEVORA_DISCORD_INVITE).
Status zaproszenia nie jest potwierdzony online; wlasciciel serwera moze go odnowic.
Pozostale funkcje wersji 11.4 Together pozostaja bez zmian.
