"""Pure filtering logic for a version-aware mod loader chooser."""

def filter_loader_versions(all_versions, stable_versions, query='', show_snapshots=False):
    """Return supported Minecraft versions, preserving loader API order."""
    stable = set(stable_versions)
    source = all_versions if show_snapshots else [version for version in all_versions if version in stable]
    needle = str(query).strip().casefold()
    results = []
    seen = set()
    for item in source:
        version = str(item).strip()
        if not version or version in seen or needle not in version.casefold():
            continue
        results.append(version)
        seen.add(version)
    return results
