"""Validate project consistency without starting Minecraft or accessing the network."""
from pathlib import Path
import ast
p=Path(__file__).resolve().parent
for file in p.glob('*.py'):
    ast.parse(file.read_text(encoding='utf-8'),file.name)
for filename in ['minevora_qt.py','minevora_dashboard.py','minevora_enchanted_theme.py','minevora_minigames_qt.py','minevora_engine.py','minevora_start.py']:
    assert (p/filename).is_file(), filename
for img in ['enchanted_hero.jpg','en_minigames.jpg','en_discord.jpg','en_pvp.jpg']:
    assert (p/'assets'/img).is_file(), img
module=ast.parse((p/'minevora_minigames_qt.py').read_text(encoding='utf-8'))
modes=next(ast.literal_eval(node.value) for node in module.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MODES' for t in node.targets))
assert len(modes)==9
source=ast.parse((p/'minevora_qt.py').read_text(encoding='utf-8'))
window=next(x for x in source.body if isinstance(x,ast.ClassDef) and x.name=='Window')
methods={x.name for x in window.body if isinstance(x,ast.FunctionDef)}
for command in ('home','instances','mods','market','minigames','pvp','leaderboard','discord_page','settings','together','play'):
    assert command in methods, command

print('Struktura i składnia projektu: OK. 9 trybów: OK.')
print('Pełne testy graficzne i sieciowe wykonaj na komputerze z Windows 11.')
