"""Non-blocking Discord announcements panel for the MINEVORA launcher."""
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QTextEdit, QComboBox, QPushButton, QMessageBox, QFrame)
from minevora_discord_announcements_core import (
    build_announcement, normalize_webhook, post_webhook, record_sent,
    already_posted, read_history)


class SendThread(QThread):
    sent = Signal(str)
    failed = Signal(str)
    def __init__(self, webhook, payload):
        super().__init__()
        self.webhook = webhook
        self.payload = payload
    def run(self):
        try:
            self.sent.emit(post_webhook(self.webhook, self.payload))
        except Exception as exc:
            # post_webhook returns sanitized errors; never expose secrets.
            self.failed.emit(str(exc) if isinstance(exc, (RuntimeError, ValueError)) else 'Błąd wysyłania ogłoszenia.')
        finally:
            self.webhook = None


class DiscordAnnouncements(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = None
        self._build_ui()
        self.refresh_history()

    def _label(self, text, font=12):
        label = QLabel(text)
        label.setWordWrap(True)
        label.setStyleSheet(f'color:#c7c8e6;background:transparent;font-size:{font}px')
        return label

    def _build_ui(self):
        wrap = QVBoxLayout(self)
        wrap.setContentsMargins(0, 0, 0, 0)
        wrap.setSpacing(9)
        wrap.addWidget(self._label('📣  MINEVORA • BOT OGŁOSZENIOWY', 19))
        wrap.addWidget(self._label('Publikuj informacje o nowych wersjach na oficjalnym Discordzie. Przed wysłaniem zawsze zatwierdź treść.'))
        wrap.addWidget(self._label('Webhook Discord (tajny adres, nie jest zapisywany):'))
        self.webhook = QLineEdit()
        self.webhook.setPlaceholderText('https://discord.com/api/webhooks/...')
        self.webhook.setEchoMode(QLineEdit.Password)
        self.webhook.setToolTip('W Discord: Ustawienia serwera → Integracje → Webhooki → Nowy webhook → Kopiuj URL.')
        wrap.addWidget(self.webhook)
        row = QHBoxLayout()
        self.version = QLineEdit('10.4')
        self.version.setPlaceholderText('Wersja np. 10.4')
        self.category = QComboBox(); self.category.addItems(['Aktualizacja','Poprawka','Wydarzenie'])
        row.addWidget(self.version, 1); row.addWidget(self.category, 1)
        wrap.addLayout(row)
        self.title = QLineEdit('Bot ogłaszający aktualizacje Discord')
        self.title.setPlaceholderText('Tytuł aktualizacji')
        wrap.addWidget(self.title)
        wrap.addWidget(self._label('Lista zmian:'))
        self.changes = QTextEdit()
        self.changes.setMinimumHeight(100)
        self.changes.setPlainText('• Nowy bot do publikowania ogłoszeń na Discordzie.\n• Podgląd i zatwierdzanie przed wysyłką.\n• Historia ogłoszeń oraz ochrona przed duplikatami.')
        wrap.addWidget(self.changes)
        self.download = QLineEdit()
        self.download.setPlaceholderText('Publiczny link HTTPS do pobrania — opcjonalnie')
        wrap.addWidget(self.download)
        self.preview = QTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setMinimumHeight(120)
        self.preview.setStyleSheet('background:#121a31;color:#ede6ff;border:1px solid #715ba2;border-radius:12px;padding:10px')
        wrap.addWidget(self.preview)
        buttons = QHBoxLayout()
        self.preview_button = QPushButton('👁  Podgląd')
        self.send_button = QPushButton('📣  Opublikuj na Discordzie')
        self.send_button.setObjectName('primary')
        self.preview_button.clicked.connect(self.show_preview)
        self.send_button.clicked.connect(self.send)
        buttons.addWidget(self.preview_button)
        buttons.addWidget(self.send_button)
        wrap.addLayout(buttons)
        self.history_label = self._label('Historia: brak wysłanych ogłoszeń.', 11)
        wrap.addWidget(self.history_label)
        wrap.addWidget(self._label('Wysyła do kanału przypisanego do webhooka. Nie czyta wiadomości Discorda i nie korzysta z hasła konta. Brak automatycznych publikacji z samego uruchomienia launchera.', 11))
        self.show_preview()

    def _payload(self):
        return build_announcement(self.version.text(), self.title.text(), self.changes.toPlainText(),
                                  self.download.text(), self.category.currentText())

    def show_preview(self):
        try:
            embed = self._payload()['embeds'][0]
        except ValueError as exc:
            self.preview.setPlainText('Uzupełnij formularz: ' + str(exc))
            return
        self.preview.setPlainText(embed['title'] + '\n\n' + embed['description'] +
                                  ('\n\n' + embed['url'] if embed.get('url') else ''))

    def send(self):
        if self.worker is not None and self.worker.isRunning():
            return
        try:
            payload = self._payload()
            url = normalize_webhook(self.webhook.text())
        except ValueError as exc:
            QMessageBox.warning(self, 'Ogłoszenia Discord', str(exc))
            return
        if already_posted(payload):
            QMessageBox.warning(self, 'Duplikat', 'Takie ogłoszenie zostało już wysłane z tego komputera. Zmień treść lub wersję, jeśli publikujesz nową aktualizację.')
            return
        self.show_preview()
        answer = QMessageBox.question(self, 'Potwierdź publikację',
            'Wysłać publiczne ogłoszenie „%s” na kanał ustawiony w webhooku?\n\nPo publikacji wiadomość będą widzieć osoby na serwerze Discord.' % self.title.text()[:100],
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        self.send_button.setEnabled(False)
        self.send_button.setText('Wysyłanie…')
        self.worker = SendThread(url, payload)
        self.worker.sent.connect(lambda message_id, p=payload:self._done(p, message_id))
        self.worker.failed.connect(self._failed)
        self.worker.finished.connect(self._finish)
        self.worker.start()

    def _done(self, payload, message_id):
        record_sent(payload, message_id)
        self.refresh_history()
        QMessageBox.information(self, 'MINEVORA', 'Ogłoszenie zostało opublikowane na Discordzie.')

    def _failed(self, message):
        QMessageBox.warning(self, 'Discord — błąd publikacji', message)

    def _finish(self):
        self.send_button.setEnabled(True)
        self.send_button.setText('📣  Opublikuj na Discordzie')
        self.worker = None

    def refresh_history(self):
        history = read_history()
        if history:
            self.history_label.setText('Ostatnio opublikowano: ' + history[0].get('title','') +
                                       '  (' + history[0].get('time_utc','')[:10] + ')')
        else:
            self.history_label.setText('Historia: brak wysłanych ogłoszeń na tym komputerze.')
