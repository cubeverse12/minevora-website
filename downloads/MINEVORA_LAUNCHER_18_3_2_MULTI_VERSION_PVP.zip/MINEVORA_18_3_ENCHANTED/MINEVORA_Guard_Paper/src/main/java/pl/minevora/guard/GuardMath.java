package pl.minevora.guard;

/** Small deterministic maths used by checks; unit-testable without a server. */
public final class GuardMath {
    private GuardMath() {}

    public static double horizontalSpeed(double x1, double z1, double x2, double z2, double elapsedMs) {
        if (elapsedMs <= 0) return 0;
        return Math.hypot(x2 - x1, z2 - z1) / (elapsedMs / 50.0);
    }

    public static double pointToBox(double x, double y, double z, double minX, double minY, double minZ,
                                    double maxX, double maxY, double maxZ) {
        final double cx = Math.max(minX, Math.min(maxX, x));
        final double cy = Math.max(minY, Math.min(maxY, y));
        final double cz = Math.max(minZ, Math.min(maxZ, z));
        return Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy) + (z - cz) * (z - cz));
    }

    public static String json(String s) {
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> { if (c < 32) out.append(String.format("\\u%04x", (int) c)); else out.append(c); }
            }
        }
        return out.append('"').toString();
    }
}
