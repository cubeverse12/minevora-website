MINEVORA 9.5 — GUARD / FAIR PLAY
================================

CO ZOSTAŁO DODANE
-----------------
1. MINEVORAGuard.jar — serwerowy antycheat dla Paper 1.21.4 (Java 21).
2. Pięć kontroli: SPEED, HOVER, REACH, FAST_SWING, FAST_PLACE.
3. Alerty dla OP / osób z uprawnieniem minevora.guard.alerts.
4. Zapisywanie sygnałów w JSONL i import do panelu MINEVORA Fair Play.
5. Ochrona przed fałszywymi alertami: okres po wejściu na serwer,
   teleportacji, zmianie świata, otrzymaniu obrażeń i odrzuceniu,
   wyłączenia dla elytry, kreatywnego latania, pojazdów, wody, efektów,
   wysokiego pingu przy Reach; progi i powtarzanie sygnałów.
6. Wersja launchera 9.5 z przyciskiem „Import Guard JSONL”.

INSTALACJA PLUGINU NA SERWERZE
-----------------------------
1. Serwer: Paper 1.21.4, Java 21. Zrób kopię zapasową serwera.
2. Wypakuj tę paczkę ZIP i znajdź plik:
   MINEVORA_Guard_Paper/MINEVORAGuard.jar
3. Skopiuj ten JAR do folderu plugins/ TWOJEGO SERWERA Paper.
4. Uruchom / zrestartuj serwer.
5. Sprawdź w konsoli czy pojawił się napis „MINEVORA Guard aktywny”.
6. Edytuj plugins/MINEVORAGuard/config.yml (progi, alerty, nazwa serwera).
   Zapisz zmiany, a w konsoli wykonaj: mg reload

KOMENDY (OP / PERMISSION minevora.guard.admin)
-----------------------------------------------
/mg status          — stan pluginu
/mg inspect <nick>  — liczniki zgłoszeń online
/mg alerts          — wycisz / włącz alerty dla siebie
/mg evidence        — ścieżka pliku dziennika
/mg reload          — przeładuj ustawienia

INSTALACJA LAUNCHERA
--------------------
1. Zamknij poprzednią MINEVORA.
2. Rozpakuj ZIP do NOWEGO katalogu (bez nadpisywania starej kopii).
3. Uruchom INSTALUJ_ZALEZNOSCI.bat (jeżeli potrzebujesz zależności).
4. Uruchom URUCHOM_MINEVORA.bat.
5. W menu wejdź w Fair Play -> „Import Guard JSONL”.
6. Wskaż plik z serwera: plugins/MINEVORAGuard/evidence.jsonl
   (w razie potrzeby skopiuj go z hostingu na komputer).
7. Sprawdź alerty graczy, opisy i źródło każdego raportu.
   Ponowny import tych samych zdarzeń nie tworzy duplikatów.

WAŻNE OGRANICZENIA
------------------
- Ten plugin NIE jest uniwersalną ochroną przed wszystkimi cheatami.
  Jest to pierwsza działająca implementacja heurystyczna do testów.
- Automatyczne bany i „procent cheatowania” są WYŁĄCZONE / nieistniejące.
  Alert to sygnał do ręcznej oceny; ping, lagi i pluginy PvP wpływają na pomiar.
- Żadnego wykrywania multikont po IP ani zbierania adresów IP / fingerprintów.
- JSONL można edytować ręcznie. Launcher NIE weryfikuje kryptograficznie pochodzenia pliku.
  Importowany wpis ma status „do sprawdzenia”.
- Plugin nie łączy się z publicznymi bazami banów; nie raportuje banów globalnie.
- Używaj kont Minecraft online-mode=true; offline UUID może być różny między serwerami.
- Przed użyciem na publicznym serwerze trzeba przetestować na Paper.
- Kompilacja JAR: sprawdzono bytecode za pomocą testowych sygnatur Bukkit API,
  ale bez prawdziwej biblioteki Paper (niedostępna w środowisku budowy).
  NIE wykonano testu runtime na uruchomionym Paper. Do wersji produkcyjnej
  zalecana jest ponowna kompilacja projektu Maven z prawdziwą Paper API.
- Jeśli nie uruchamia się na serwerze, wyślij błąd z logs/latest.log.

SOURCE / PONOWNA KOMPILACJA
---------------------------
Kod i pom.xml znajdują się w MINEVORA_Guard_Paper/.
Maven z Java 21: mvn clean package
Plik docelowy: target/MINEVORAGuard.jar.
To wymaga dostępu do repozytorium PaperMC i zależności Maven.

PRYWATNOŚĆ
----------
Dziennik zawiera nick, UUID, nazwę serwera, czas i opis sygnału.
Bez IP, bez danych urządzenia. Archiwa starsze niż 30 dni są usuwane
przy starcie pluginu (konfigurowalne). Regularnie usuwaj stare raporty
z launchera zgodnie z zasadami Twojej społeczności.
