# MINEVORA 17.4 — audyt launchera i naprawy

**Punkt wyjścia:** pełne archiwum `MINEVORA_17_3_PELNE_3D_MODPACKI_GOTOWE.zip`.
**Wersja audytowana:** 17.3; poprawione źródła: 17.4.
**Charakter testów:** offline i statyczne. Nie przeprowadzono testu pełnej aplikacji GUI na komputerze użytkownika.

## Wynik

| Kontrola | Wynik |
|---|---|
| Integralność oryginalnego ZIP | OK (`ZipFile.testzip()` bez błędów) |
| Składnia całego projektu Python | OK (`compileall`) |
| Zestaw testów `pytest` po poprawkach | **148 passed, 24 subtests passed** |
| Dodatkowe samodzielne testy czatu, Guard, rankingu, Together, backupu | OK |
| Wszystkie lokalne importy `minevora_*` | 49 nazw modułów; brak brakujących plików |
| Obrazy w `assets` | 45 plików PNG/JPG bez błędów integralności |
| Domyślny atlas skina | PNG 64×64, poprawny |
| Uruchomienie całego okna na Windows 11 | **NIE TESTOWANO** |
| Logowanie Microsoft na prawdziwym koncie | **NIE TESTOWANO** |
| Instalacja Minecraft / Fabric / Forge / NeoForge / Quilt z internetu | **NIE TESTOWANO** |
| Skuteczne uruchomienie pobranego modpacka w Minecraft | **NIE TESTOWANO** |
| Rzeczywiste renderowanie postaci Qt na komputerze użytkownika | **NIE TESTOWANO** |
| Publiczny hosting strony WWW 24/7 | **NIE TESTOWANO / STRONY NIE HOSTOWANO** |

## Wykryte i naprawione błędy

1. **Niepoprawna wersja loadera modpacka.** Kod `minevora_mrpack.py` wywoływał `engine.install()` bez parametru `loader_version`, pomijając wymaganie manifestu. Teraz przekazuje dokładnie zadeklarowaną wersję i sprawdza, czy instalator utworzył kompletny identyfikator wersji Minecraft. Test z podstawionym loaderem weryfikuje argumenty wywołania.
2. **Pobieranie bez wiarygodnej sumy kontrolnej.** Poprzedni kod pozwalał zapisać plik bez SHA-1/SHA-512, mimo deklarowanej weryfikacji. Teraz pobranie jest odrzucane, jeżeli brak prawidłowej sumy.
3. **Niebezpieczne ścieżki Windows w paczkach.** Poprzednia walidacja częściowo akceptowała nazwy z końcową kropką/spacją i normalizowane segmenty. Teraz takie ścieżki, niedozwolone znaki i nazwy urządzeń systemowych są odrzucane.
4. **Zamykanie programu w trakcie instalacji modpacka.** `Window.closeEvent()` nie sprawdzał `modpack_worker`. Teraz wyłączenie programu jest wstrzymywane, aby trwająca operacja nie została zerwana podczas pracy wątku.
5. **Niejednoznaczny wybór starej wersji loadera.** Zamiast wybierać losowy zgodny katalog, nowy kod preferuje identyfikator zwrócony przez instalator. Gdy starsza biblioteka go nie zwraca, nie zgaduje w sytuacji wielu kandydatów.
6. **Wycieki referencji w wyszukiwaniu Modrinth.** Ukończone wątki pobierające ikony zostają usunięte z listy i skierowane do `deleteLater()`.
7. **Brak minimalnej wersji biblioteki loaderów.** `requirements.txt` wymaga `minecraft-launcher-lib>=8.0` dla ujednoliconego API loaderów.

## Co jest nadal do weryfikacji

- **GUI:** kliknięcia, skalowanie, rzeczywista wydajność i grafika 3D w Windows 11.
- **Konta:** Microsoft OAuth (wymaga rzeczywistej autoryzacji i skonfigurowanego Client ID).
- **Instalowanie Minecraft:** połączenie do dostawców, obecność Java i poprawność bibliotek gry.
- **Modpacki:** instalator wykorzystuje API biblioteki minecraft-launcher-lib; nie wykonano pełnej, internetowej instalacji prawdziwego modpacka.
- **Skiny:** sprawdzono lokalne tekstury i składnię renderera; nie potwierdzono poprawnego wizualnie renderowania wszystkich własnych skinów na Windows.
- **Serwery i Discord:** działanie usług zewnętrznych zależy od konfiguracji i dostępu do internetu.
- **Strona WWW:** repozytorium projektu 17.3 nie zawiera gotowej witryny HTML; jej dostępność 24/7 wymaga osobnego wdrożenia.

## Instalacja i diagnostyka

1. Zachowaj kopię starszej wersji MINEVORA i danych z `%USERPROFILE%\\.minevora`.
2. Rozpakuj paczkę do nowego folderu, bez podmieniania działającej instalacji w ciemno.
3. Uruchom `SPRAWDZ_LAUNCHER.bat`, a potem `URUCHOM_MINEVORA.bat`.
4. W razie błędu zachowaj pełny komunikat konsoli i pliki w `%USERPROFILE%\\.minevora\\ostatni_blad.txt` / `ostatni_blad_runtime.txt` (mogą zawierać lokalne ścieżki — usuń wrażliwe dane przed przesłaniem).
5. Przed instalacją modpacka sprawdź, czy Minecraft nie jest uruchomiony, oraz czy masz wystarczająco miejsca na dysku.

## Podsumowanie

Kod i testy offline nie wykazują nowych regresji w sprawdzonych obszarach. Nie można jednak rzetelnie zapewnić, że „wszystko działa”, bez pełnego testu integracyjnego na Windows oraz połączeń z Microsoft i Modrinth.
