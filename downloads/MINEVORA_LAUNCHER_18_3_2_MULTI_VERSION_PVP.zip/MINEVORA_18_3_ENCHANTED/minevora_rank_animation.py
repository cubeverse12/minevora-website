"""Animated rank/level-up announcement for the local MINEVORA creator page.

All effects are native Qt painter animations (no network, external video or game mod).
Rewards are deliberately handled by the existing verified market_demo.json workflow.
"""
import math
import random

from PySide6.QtCore import Qt, QTimer, QElapsedTimer, QRectF, QPointF, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QPixmap, QRadialGradient, QLinearGradient, QFont
from PySide6.QtWidgets import QDialog, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget, QFrame


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def smoothstep(x):
    x = clamp(x)
    return x*x*(3-2*x)


class AscensionCanvas(QWidget):
    """Painted badge, XP ring, magical light beams and orbiting particles."""
    def __init__(self, rank, icon, parent=None):
        super().__init__(parent)
        self.rank = rank
        self.badge = QPixmap(str(icon))
        self.accent = QColor(rank['color'])
        self.elapsed_ms = 0
        self.setMinimumHeight(355)
        self.setAttribute(Qt.WA_TranslucentBackground)
        randomizer = random.Random(1907)
        self.particles = [
            (randomizer.random(), randomizer.random(),
             randomizer.uniform(1.2, 3.7), randomizer.uniform(.3, 1.25),
             randomizer.random()*math.tau)
            for _ in range(74)
        ]

    def set_time(self, millis):
        self.elapsed_ms = millis
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        w = float(self.width())
        h = float(self.height())
        cx, cy = w*.5, h*.52
        t = self.elapsed_ms / 1000.0
        charge = smoothstep(t/1.15)
        reveal = smoothstep((t-1.05)/.95)
        fade = smoothstep((t-3.65)/.8)
        pulse = (math.sin(t*4.7)+1)*.5
        ring_radius = min(w*.29, h*.385)

        bg = QRadialGradient(QPointF(cx, cy), max(w*.55, 250))
        bg.setColorAt(0, QColor(32, 36, 82))
        bg.setColorAt(.45, QColor(20, 24, 53))
        bg.setColorAt(1, QColor(10, 16, 36))
        p.fillRect(self.rect(), bg)
        p.setPen(Qt.NoPen)

        # Moving constellations, confined to the dedicated animation panel.
        for x, y, radius, speed, phase in self.particles:
            py = (y*h - t*23*speed) % h
            px = x*w + math.sin(t*1.4+phase)*9
            sparkle = .6 + .4*math.sin(t*3.0+phase)
            star = QColor(self.accent)
            star.setAlpha(int(28+120*reveal*max(.3, sparkle)*(1-fade*.8)))
            p.setBrush(star)
            p.drawEllipse(QPointF(px,py),radius,radius)

        # Expanding rank-up rays; drawn behind the badge.
        if reveal > 0:
            for idx in range(16):
                a = idx*math.tau/16+t*.025
                inner = ring_radius*(.95+reveal*.1)
                outer = ring_radius*(1.35+reveal*.6)
                grad = QLinearGradient(QPointF(cx+math.cos(a)*inner,cy+math.sin(a)*inner),
                                       QPointF(cx+math.cos(a)*outer,cy+math.sin(a)*outer))
                first = QColor(self.accent)
                first.setAlpha(int((28+24*pulse)*reveal*(1-fade*.6)))
                grad.setColorAt(0,first)
                outercol = QColor(self.accent)
                outercol.setAlpha(0)
                grad.setColorAt(1,outercol)
                p.setPen(QPen(QBrush(grad),3.7,Qt.SolidLine,Qt.RoundCap))
                p.drawLine(QPointF(cx+math.cos(a)*inner,cy+math.sin(a)*inner),
                           QPointF(cx+math.cos(a)*outer,cy+math.sin(a)*outer))

        # Ring glow and animated XP progress.
        for thickness, alpha in ((22,12),(14,19),(8,38)):
            c=QColor(self.accent)
            c.setAlpha(int(alpha*(.65+reveal*.35)))
            p.setPen(QPen(c,thickness,Qt.SolidLine,Qt.RoundCap))
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(cx,cy),ring_radius,ring_radius)
        p.setPen(QPen(QColor(62,80,120),5,Qt.SolidLine,Qt.RoundCap))
        p.drawEllipse(QPointF(cx,cy),ring_radius,ring_radius)
        stroke=QColor(self.accent)
        stroke.setAlpha(245)
        p.setPen(QPen(stroke,5.5,Qt.SolidLine,Qt.RoundCap))
        full_angle = 360*charge
        p.drawArc(QRectF(cx-ring_radius,cy-ring_radius,2*ring_radius,2*ring_radius),
                  90*16,-int(full_angle*16))
        if charge >= 1:
            p.setPen(QPen(QColor(220,241,255,130+int(pulse*80)),2))
            p.drawEllipse(QPointF(cx,cy),ring_radius+8,ring_radius+8)

        # Shield grows with an ease-out animation after the XP ring fills.
        if not self.badge.isNull():
            size = ring_radius*1.55*(.55 + reveal*.45)
            badge_opacity = max(.06, .18+reveal*.82)
            p.setOpacity(badge_opacity)
            source = QRectF(self.badge.rect())
            target = QRectF(cx-size/2,cy-size/2,size,size)
            p.drawPixmap(target,self.badge,source)
            p.setOpacity(1)

        # Small rank diamonds around the shield.
        if reveal > 0:
            for i in range(8):
                a = i*math.tau/8+t*.35
                rr=ring_radius*(1.22+math.sin(t*1.8+i)*.06)
                sx=cx+math.cos(a)*rr;sy=cy+math.sin(a)*rr
                d=2.5+4*reveal
                q=QColor(self.accent)
                q.setAlpha(int(200*reveal))
                p.setBrush(q)
                p.setPen(Qt.NoPen)
                p.drawPolygon([QPointF(sx,sy-d),QPointF(sx+d*.55,sy),
                               QPointF(sx,sy+d),QPointF(sx-d*.55,sy)])
        p.end()


class RankUpDialog(QDialog):
    """Small modal-in-launcher cinematic reveal. Does not modify wallet or XP."""
    claim_requested = Signal()
    DURATION_MS = 4400

    def __init__(self, rank, icon_path, new_level, old_level,
                 new_rank, pending_mvc=0, preview=False, parent=None):
        super().__init__(parent)
        self.rank = rank
        self.preview = preview
        self.new_rank = new_rank
        self.old_level = old_level
        self.new_level = new_level
        self.pending_mvc = pending_mvc
        self.setWindowTitle('MINEVORA • Awans rangi' if new_rank else 'MINEVORA • Awans poziomu')
        self.setModal(True)
        self.setFixedSize(620,590)
        self.setStyleSheet('''
        QDialog { background: #0d1427; color: #f9f7ff; }
        QLabel { background: transparent; color: #f9f7ff; }
        QPushButton { background: #293756; color: white; border: 1px solid #657dad;
                      padding: 12px 18px; border-radius: 12px; font-size: 13px; font-weight: 700; }
        QPushButton:hover { background: #3a4e75; }
        QPushButton#reward { background: #6c4bb8; border: 1px solid #d4b7ff; }
        QPushButton#reward:hover { background: #855ed5; }
        QPushButton:disabled { background: #1f2b41; color: #8c9ab1; }
        ''')
        outer=QVBoxLayout(self)
        outer.setContentsMargins(17,16,17,15)
        outer.setSpacing(6)
        top=QLabel('✧  M I N E V O R A   •   A W A N S')
        top.setAlignment(Qt.AlignCenter)
        top.setStyleSheet('font-size:12px;font-weight:800;color:#b8aaff;letter-spacing:1px')
        outer.addWidget(top)
        self.title=QLabel('ŁADOWANIE ENERGII...')
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet('font-size:27px;font-weight:900')
        outer.addWidget(self.title)
        self.canvas=AscensionCanvas(rank,icon_path,self)
        outer.addWidget(self.canvas,1)
        self.subtitle=QLabel(f'POZIOM {new_level}  •  {rank["name"].upper()}')
        self.subtitle.setAlignment(Qt.AlignCenter)
        self.subtitle.setStyleSheet(f'font-size:21px;font-weight:800;color:{rank["color"]}')
        outer.addWidget(self.subtitle)
        self.message=QLabel('Zbieranie punktów doświadczenia...')
        self.message.setAlignment(Qt.AlignCenter)
        self.message.setStyleSheet('font-size:12px;color:#bdc9e3')
        outer.addWidget(self.message)
        buttons=QHBoxLayout()
        self.skip=QPushButton('Pomiń animację')
        self.skip.clicked.connect(self.skip_animation)
        buttons.addWidget(self.skip)
        buttons.addStretch()
        self.collect=QPushButton('')
        self.collect.setObjectName('reward')
        self.collect.clicked.connect(self.claim)
        self.collect.setVisible(False)
        buttons.addWidget(self.collect)
        close=QPushButton('Zamknij')
        close.clicked.connect(self.accept)
        buttons.addWidget(close)
        outer.addLayout(buttons)
        self.clock=QElapsedTimer()
        self.timer=QTimer(self)
        self.timer.setInterval(30)
        self.timer.timeout.connect(self.advance)
        self.finished.connect(self.stop_animation)

    def showEvent(self,event):
        super().showEvent(event)
        self.clock.start()
        self.timer.start()
        self.advance()

    def stop_animation(self,*args):
        self.timer.stop()

    def skip_animation(self):
        self.timer.stop()
        self.render_at(self.DURATION_MS)

    def advance(self):
        elapsed=min(self.clock.elapsed(),self.DURATION_MS)
        self.render_at(elapsed)
        if elapsed>=self.DURATION_MS:
            self.timer.stop()

    def render_at(self, elapsed):
        self.canvas.set_time(elapsed)
        if elapsed < 1100:
            self.title.setText('ZBIERANIE ENERGII...')
            self.message.setText('Pasek XP wypełnia się magiczną energią')
        elif elapsed < 2400:
            self.title.setText('✦  NOWA RANGA!' if self.new_rank else '✦  AWANS POZIOMU!')
            self.message.setText('Odblokowywanie herbu i efektów...')
        else:
            self.title.setText('✦  NOWA RANGA ODBLOKOWANA!  ✦' if self.new_rank else '✦  NOWY POZIOM ODBLOKOWANY!  ✦')
            self.message.setText('To jest podgląd animacji — bez przyznawania XP lub nagród.' if self.preview else
                                 f'Awans z poziomu {self.old_level} na {self.new_level}. Możesz odebrać nagrodę MVC (demo).')
        finished=elapsed >= 2400
        self.skip.setVisible(not finished)
        if self.preview:
            self.collect.setVisible(False)
        else:
            self.collect.setVisible(finished and self.pending_mvc>0)
            self.collect.setText(f'💎  ODBIERZ {self.pending_mvc} MVC (demo)')

    def claim(self):
        if self.preview or self.pending_mvc <= 0:
            return
        self.accept()
        self.claim_requested.emit()
