"""Modrinth .mrpack installer: verified downloads, safe paths, isolated instance.
Modrinth specification: https://support.modrinth.com/en/articles/8802351-modrinth-modpack-format-mrpack
Pure stdlib core; Qt UI lives in minevora_modrinth.py.
"""
from __future__ import annotations
import hashlib
import json
import re
import urllib.request
import urllib.parse
import zipfile
from pathlib import Path, PurePosixPath
from uuid import uuid4

API = 'https://api.modrinth.com/v2'
HEADERS = {'User-Agent': 'MINEVORA/17.3 (Minecraft launcher; Modrinth API)', 'Accept': 'application/json'}
ALLOWED = {'cdn.modrinth.com', 'github.com', 'raw.githubusercontent.com', 'gitlab.com',
           'objects.githubusercontent.com', 'release-assets.githubusercontent.com'}
MAX_MRPACK = 200 * 1024 * 1024
MAX_FILE = 512 * 1024 * 1024
MAX_TOTAL = 3 * 1024 * 1024 * 1024
MAX_OVERRIDES = 400 * 1024 * 1024


def safe_path(value):
    """Strict, Windows-compatible relative paths for untrusted MRPACK entries."""
    if not isinstance(value, str) or not value or '\\' in value or '\x00' in value:
        raise ValueError('Niebezpieczna ścieżka modpacka.')
    # PurePosixPath silently normalizes repeated separators and ./ components.
    # Validate the original spelling first, including Windows trailing dots/spaces.
    parts = value.split('/')
    illegal = '<>:"|?*'
    if (value.startswith('/') or any(part in ('', '.', '..') or
           part.endswith((' ', '.')) or any(c in part for c in illegal)
           for part in parts)):
        raise ValueError('Niebezpieczna ścieżka modpacka: ' + value[:100])
    for part in parts:
        base = part.split('.', 1)[0].upper()
        if base in {'CON','PRN','AUX','NUL',
                    *(f'COM{i}' for i in range(1,10)),
                    *(f'LPT{i}' for i in range(1,10))}:
            raise ValueError('Niedozwolona nazwa pliku w archiwum.')
    return PurePosixPath(value)


def trusted_url(url):
    u = urllib.parse.urlsplit(url)
    if u.scheme != 'https' or u.hostname not in ALLOWED or u.username or u.password:
        raise ValueError('Modpack zawiera niezatwierdzony adres pobierania.')
    return url


def json_from_api(path, params=None):
    url = API + path
    if params: url += '?' + urllib.parse.urlencode(params)
    with urllib.request.urlopen(urllib.request.Request(url, headers=HEADERS), timeout=35) as f:
        return json.load(f)


def download_verified(url, destination, hashes, maximum, progress=lambda text:None):
    trusted_url(url)
    if not isinstance(hashes, dict) or not any(
            isinstance(hashes.get(k), str) and len(hashes[k]) == n
            and bool(re.fullmatch(r'[a-fA-F0-9]+', hashes[k]))
            for k,n in (('sha512',128),('sha1',40))):
        raise ValueError('Brak poprawnej sumy SHA-512/SHA-1: nie pobieram pliku bez weryfikacji.')
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_name(destination.name+'.'+uuid4().hex+'.part')
    sha512 = hashlib.sha512()
    sha1 = hashlib.sha1()
    count=0
    try:
        req=urllib.request.Request(url,headers={'User-Agent':HEADERS['User-Agent']})
        with urllib.request.urlopen(req,timeout=60) as response, temp.open('wb') as out:
            trusted_url(response.geturl())
            while True:
                block=response.read(128*1024)
                if not block:break
                count+=len(block)
                if count>maximum:raise ValueError('Pobrany plik przekracza limit rozmiaru.')
                sha512.update(block);sha1.update(block);out.write(block)
        for alg,actual in [('sha512',sha512.hexdigest()),('sha1',sha1.hexdigest())]:
            expected=hashes.get(alg)
            if expected and (not isinstance(expected,str) or expected.lower()!=actual.lower()):
                raise ValueError('Błędna suma kontrolna '+alg+' w pliku '+destination.name)
        temp.replace(destination)
    finally:
        temp.unlink(missing_ok=True)
    return count


def pack_release(project, game_version=''):
    if not re.fullmatch('[A-Za-z0-9_-]{2,100}',str(project)):
        raise ValueError('Niepoprawny identyfikator projektu.')
    params={'include_changelog':'false'}
    if game_version:params['game_versions']=json.dumps([game_version])
    versions=json_from_api('/project/'+project+'/version',params)
    for ver in versions:
        files=ver.get('files',[])
        mrpack=next((f for f in files if f.get('primary') and str(f.get('filename','')).endswith('.mrpack')),None)
        mrpack=mrpack or next((f for f in files if str(f.get('filename','')).endswith('.mrpack')),None)
        if mrpack:return ver,mrpack
    raise ValueError('Nie znaleziono wersji .mrpack'+(' dla Minecraft '+game_version if game_version else '')+'. Zmień filtr wersji.')


def get_manifest(pack_path):
    with zipfile.ZipFile(pack_path) as arc:
        if 'modrinth.index.json' not in arc.namelist():
            raise ValueError('Archiwum nie zawiera modrinth.index.json')
        info=arc.getinfo('modrinth.index.json')
        if info.file_size>1024*1024:raise ValueError('Manifest jest zbyt duży.')
        manifest=json.loads(arc.read(info))
    if manifest.get('formatVersion')!=1 or manifest.get('game')!='minecraft':
        raise ValueError('Nieobsługiwany format modpacka.')
    dependencies=manifest.get('dependencies',{})
    if not isinstance(dependencies,dict) or not re.fullmatch('[A-Za-z0-9_.-]+',str(dependencies.get('minecraft',''))):
        raise ValueError('Brak wersji Minecraft w manifeście.')
    if not isinstance(manifest.get('files'),list) or len(manifest['files'])>10000:
        raise ValueError('Nieprawidłowa lista plików modpacka.')
    return manifest


def install_pack_files(pack_path, instance_dir, progress=lambda text:None):
    """Install only client files; refuse paths escaping instance, validate hashes."""
    dest=Path(instance_dir).resolve()
    dest.mkdir(parents=True,exist_ok=True)
    manifest=get_manifest(pack_path)
    total=0;installed=0;optional_skipped=0
    for i,entry in enumerate(manifest['files'],1):
        if not isinstance(entry,dict):raise ValueError('Uszkodzony wpis pliku.')
        env=entry.get('env') or {}
        if env.get('client') in ('unsupported','optional'):
            optional_skipped+=1;continue
        path=safe_path(entry.get('path'))
        url=next((u for u in entry.get('downloads',[]) if isinstance(u,str) and urllib.parse.urlsplit(u).hostname in ALLOWED),None)
        if not url:raise ValueError('Brak zaufanego źródła pobierania dla '+str(path))
        target=dest.joinpath(*path.parts)
        if not target.resolve().is_relative_to(dest):raise ValueError('Niebezpieczna ścieżka docelowa.')
        if target.exists():raise FileExistsError('Plik już istnieje: '+str(path))
        progress(f'Pobieranie {i}/{len(manifest["files"])}: {path.name}')
        total+=download_verified(url,target,entry.get('hashes',{}),MAX_FILE,progress)
        if total>MAX_TOTAL:raise ValueError('Modpack przekracza limit 3 GB.')
        installed+=1
    with zipfile.ZipFile(pack_path) as arc:
        names=arc.infolist()
        if len(names)>20000:raise ValueError('Zbyt dużo plików w archiwum.')
        for prefix in ('overrides/','client-overrides/'):
            for entry in names:
                if not entry.filename.startswith(prefix) or entry.is_dir():continue
                rel=entry.filename[len(prefix):]
                path=safe_path(rel)
                if entry.file_size>MAX_OVERRIDES or total+entry.file_size>MAX_TOTAL:
                    raise ValueError('Przekroczono limit plików w modpacku.')
                if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError('Link symboliczny w archiwum jest niedozwolony.')
                target=dest.joinpath(*path.parts)
                if not target.resolve().is_relative_to(dest):raise ValueError('Niebezpieczna ścieżka docelowa.')
                target.parent.mkdir(parents=True,exist_ok=True)
                progress('Wypakowywanie: '+str(path))
                import shutil
                with arc.open(entry) as src, target.open('wb') as out:
                    amount=0
                    while True:
                        block=src.read(128*1024)
                        if not block:break
                        amount+=len(block)
                        if amount>MAX_OVERRIDES:raise ValueError('Zbyt duży plik overrides.')
                        out.write(block)
                total+=amount
    return manifest,{'files':installed,'optional_skipped':optional_skipped,'bytes':total}


def install_loader(dependencies, progress=lambda x:None):
    """Install Minecraft and the EXACT loader declared by the modpack manifest.

    The 8.x minecraft-launcher-lib mod_loader API returns an installed version
    id. Never infer the chosen loader from a random previously installed build.
    """
    import minecraft_launcher_lib
    from minevora_engine import MC_DIR
    if not isinstance(dependencies,dict):
        raise ValueError('Manifest: niepoprawne zależności.')
    mc=dependencies.get('minecraft')
    if not isinstance(mc,str) or not re.fullmatch(r'[0-9][A-Za-z0-9_.-]*',mc):
        raise ValueError('Manifest: niepoprawna wersja Minecraft.')
    selected=[l for l in ('fabric-loader','forge','neoforge','quilt-loader') if l in dependencies]
    if len(selected)>1:
        raise ValueError('Manifest modpacka wskazuje kilka niezgodnych loaderów.')
    loader=selected[0] if selected else None
    kind={'fabric-loader':'fabric','quilt-loader':'quilt'}.get(loader,loader)
    wanted=dependencies.get(loader) if loader else None
    if wanted is not None and (not isinstance(wanted,str) or not re.fullmatch(r'[0-9][A-Za-z0-9_.+-]*',wanted)):
        raise ValueError('Manifest: niepoprawna wersja loadera.')
    library=Path(MC_DIR)
    library.mkdir(parents=True,exist_ok=True)
    root=library/'versions'
    progress('Instalowanie Minecraft '+mc+' i loadera '+str(kind or 'vanilla') +
             (' '+wanted if wanted else ''))
    installed_id=None
    if kind:
        module=getattr(minecraft_launcher_lib,'mod_loader',None)
        if module and hasattr(module,'get_mod_loader'):
            engine=module.get_mod_loader(kind)
            installed_id=engine.install(mc,str(library),loader_version=wanted)
        elif kind=='fabric' and hasattr(minecraft_launcher_lib,'fabric'):
            minecraft_launcher_lib.fabric.install_fabric(mc,str(library),loader_version=wanted)
        elif kind=='quilt' and hasattr(minecraft_launcher_lib,'quilt'):
            minecraft_launcher_lib.quilt.install_quilt(mc,str(library),loader_version=wanted)
        else:
            raise RuntimeError('Zaktualizuj minecraft-launcher-lib: brak obsługi loadera '+kind)
    else:
        minecraft_launcher_lib.install.install_minecraft_version(mc,str(library))
        installed_id=mc

    if isinstance(installed_id,str):
        if (root/installed_id/(installed_id+'.json')).is_file():
            return installed_id
        raise RuntimeError('Instalator nie zapisał kompletnej wersji: '+installed_id)
    # Older library APIs return None. Locate ONLY matching installed versions.
    if not root.exists():raise RuntimeError('Instalator nie utworzył katalogu wersji Minecraft.')
    matches=[p for p in root.iterdir() if p.is_dir() and (p/(p.name+'.json')).is_file()
             and (p.name==mc if not kind else kind.lower() in p.name.lower() and mc in p.name
                  and (not wanted or wanted in p.name))]
    if len(matches)!=1:
        raise RuntimeError('Nie udało się jednoznacznie ustalić wersji loadera; '
                           'sprawdź instalację ręcznie (znaleziono: %d).' % len(matches))
    return matches[0].name
