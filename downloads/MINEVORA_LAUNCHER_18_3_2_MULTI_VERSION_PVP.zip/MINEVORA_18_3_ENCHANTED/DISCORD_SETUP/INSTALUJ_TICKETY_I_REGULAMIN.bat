@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 (
 echo BLAD: Nie udalo sie zainstalowac bibliotek discord.py.
 echo Sprawdz instalacje Python i polaczenie z internetem.
 pause
 exit /b 1
)
py minevora_tickets_bot.py --install
pause
