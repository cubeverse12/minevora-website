"""Exact Polish/English names for managed Discord channels.
Channel identity is position within the installer PLAN, not free-form matching.
"""
CATEGORY_EN = [
    '📌 START', '💬 COMMUNITY', '⚔️ PVP & SERVERS', '🧱 CREATORS',
    '🔊 VOICE', '🛡️ MODERATION'
]
CHANNELS_EN = [
    ['welcome', 'rules', 'announcements', 'minevora-updates', 'roles-info', 'reporting'],
    ['general-chat', 'introductions', 'screenshots', 'help', 'suggestions'],
    ['pvp-chat', 'looking-for-duel', 'pvp-results', 'minecraft-servers'],
    ['maps-and-builds', 'models-and-rigs', 'marketplace', 'creator-tips'],
    ['General', 'PvP 1', 'PvP 2'],
    ['mod-chat', 'mod-log', 'internal-reports', 'ads-review', 'announcement-planning']
]
TOPICS_EN = [
    ['Welcome to the MINEVORA Discord!', 'Community rules and safety.', 'Official MINEVORA announcements.',
     'MINEVORA launcher release notes and updates.', 'Information about server roles.', 'How to report an issue to staff privately.'],
    ['General community chat.', 'Introduce yourself.', 'Share Minecraft screenshots.',
     'Get help with the launcher.', 'Suggest future MINEVORA features.'],
    ['PvP discussions.', 'Find players for duels.', 'PvP results (not a verified leaderboard).',
     'Community Minecraft servers.'],
    ['Share your Minecraft maps and builds.', 'Blender and Blockbench models and Minecraft rigs.',
     'Discuss Marketplace projects.', 'Creator guides and tips.'],
    [None, None, None],
    ['Private moderator chat.', 'Moderator action log.', 'Private reports.',
     'Review sponsored ads.', 'Plan announcements and new releases.']
]
SEED_EN = {
    'welcome': '# Welcome to MINEVORA! 👋\nRead #rules, then visit #announcements and #minevora-updates. Need help? Visit #help.',
    'rules': '# MINEVORA Rules\n1. Be respectful; no harassment.\n2. No spam, scams, unsafe links, or harmful files.\n3. Respect privacy.\n4. Advertise only in approved areas.\n5. Report issues privately to moderators.\n6. Follow Discord rules. You may appeal a decision privately.',
    'roles-info': '# MINEVORA Roles\n🛡 Moderator — moderation and timeouts.\n🔧 Team — announcements and organization.\n🎨 Creator — builds and 3D models.\n⚔️ PvP Player — PvP community.\n🤝 Partner — collaboration.',
    'reporting': '# Reporting\nAvoid posting private data or private-message screenshots publicly. Contact moderators privately or use Discord reporting.',
    'minevora-updates': '# MINEVORA Updates 🚀\nRelease announcements will appear here. You can connect the webhook in MINEVORA 10.4.'
}


def planned_name(plan, category_i, channel_i=None, language='pl'):
    if channel_i is None:
        return CATEGORY_EN[category_i] if language == 'en' else plan[category_i].name
    return CHANNELS_EN[category_i][channel_i] if language == 'en' else plan[category_i].channels[channel_i].name
