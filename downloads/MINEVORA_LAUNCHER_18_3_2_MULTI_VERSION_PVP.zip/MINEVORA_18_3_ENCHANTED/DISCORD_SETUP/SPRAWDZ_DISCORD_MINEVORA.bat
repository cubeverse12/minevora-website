@echo off
cd /d "%~dp0"
py sprawdz_discord_minevora.py
pause
