@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 (
 echo Instalacja nie powiodla sie. Sprobuj: python -m pip install -r requirements.txt
)
pause
