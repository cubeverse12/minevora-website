"""MINEVORA Discord read-only diagnostics. No changes are made to the server.

Token: local input only, never saved to disk. Requires discord.py>=2.4.<3.
"""
import asyncio
import getpass
import os
import sys

try:
    import discord
except ImportError:
    print('Brak discord.py. Uruchom INSTALUJ.bat w folderze DISCORD_SETUP.')
    sys.exit(1)

from minevora_tickets_core import STAFF_ROLES, TICKET_CATEGORY, TICKET_PANEL_CHANNEL, RULES_CHANNEL


def status(ok, message):
    print(('OK     ' if ok else 'UWAGA  ') + message)


async def inspect(guild, client):
    print(f'\nSERWER: {guild.name} — kontrola tylko do odczytu')
    try:
        me = guild.me or await guild.fetch_member(client.user.id)
    except discord.HTTPException as exc:
        print('Nie udalo sie pobrac konta bota na serwerze:', exc)
        return

    server_perms = me.guild_permissions
    required = {
        'Zarzadzanie kanalami': server_perms.manage_channels,
        'Zarzadzanie rolami (instalacja ról)': server_perms.manage_roles,
        'Wyswietlanie kanalow': server_perms.view_channel,
        'Wysylanie wiadomosci': server_perms.send_messages,
        'Czytanie historii': server_perms.read_message_history,
    }
    print('\nUPRAWNIENIA SERWERA')
    for label, value in required.items():
        status(value, label)
    print('\nROLE OBSLUGI')
    roles = {r.name: r for r in guild.roles}
    for name in STAFF_ROLES:
        role = roles.get(name)
        status(role is not None, f'Rola: {name}')
        if role:
            status(me.top_role > role or me.guild_permissions.administrator,
                   f'Hierarchia bota ponad: {name}')

    print('\nKATEGORIE I KANALY')
    cats = [c for c in guild.categories if c.name in TICKET_CATEGORY.values()]
    status(bool(cats), 'Kategoria ticketow')
    for cat in cats:
        status(cat.permissions_for(me).view_channel, f'Bot widzi: {cat.name}')
        status(cat.permissions_for(me).manage_channels, f'Bot moze zarzadzac: {cat.name}')
    for name in ('🛡️ MODERACJA', '🛡️ MODERATION'):
        cat = discord.utils.get(guild.categories, name=name)
        if cat:
            status(cat.permissions_for(me).view_channel, f'Bot widzi moderacje: {cat.name}')
            status(cat.permissions_for(me).manage_channels, f'Bot zarzadza moderacja: {cat.name}')

    panels = [c for c in guild.text_channels if c.name in TICKET_PANEL_CHANNEL.values()]
    status(bool(panels), '#otworz-ticket / #open-ticket')
    for panel in panels:
        perms = panel.permissions_for(me)
        status(perms.view_channel, f'Bot widzi panel {panel.name}')
        status(perms.read_message_history, f'Bot czyta historie panelu {panel.name}')
        status(perms.send_messages, f'Bot moze wysylac na panelu {panel.name}')
        if perms.view_channel and perms.read_message_history:
            try:
                messages = [m async for m in panel.history(limit=50)]
                matches = [m for m in messages if m.author.id == client.user.id and
                           'MINEVORA • ZGŁOSZENIA' in (m.content or '')]
                status(bool(matches), 'Wiadomosc panelu ticketow')
                if matches:
                    status(any(m.components for m in matches), 'Przycisk otwierania ticketow')
            except discord.HTTPException as exc:
                print('UWAGA  Nie udalo sie sprawdzic panelu:', type(exc).__name__)
    rules = [c for c in guild.text_channels if c.name in RULES_CHANNEL.values()]
    status(bool(rules), '#regulamin / #rules')
    print('\nZAKONCZONO. Test nie tworzy kanalow, nie zmienia rol ani nie wysyla wiadomosci.')
    print('Dzialanie przyciskow na zywo i widocznosc ticketow dla innych kont trzeba sprawdzic recznie.')


class CheckClient(discord.Client):
    async def on_ready(self):
        try:
            print('BOT ONLINE:', str(self.user))
            guilds=list(self.guilds)
            if not guilds:
                print('UWAGA: bot nie jest na zadnym serwerze.')
                return
            for i, guild in enumerate(guilds, 1):
                print(f'{i}. {guild.name}')
            try:
                selection = int(await asyncio.to_thread(input, 'Wybierz numer serwera: ')) - 1
            except ValueError:
                print('Niepoprawny numer serwera.')
                return
            if not 0 <= selection < len(guilds):
                print('Nie ma takiego serwera.')
                return
            await inspect(guilds[selection], self)
        finally:
            await self.close()


def main():
    print('MINEVORA — bezpieczna kontrola Discord (tylko odczyt)')
    print('Nie wysylaj tokenu na czat. Wprowadz go w tym oknie.')
    token = os.environ.get('MINEVORA_DISCORD_BOT_TOKEN', '').strip()
    if not token:
        token = getpass.getpass('Token bota Discord: ').strip()
    if not token:
        print('Nie podano tokenu.')
        return
    intents = discord.Intents.none()
    intents.guilds = True
    try:
        CheckClient(intents=intents).run(token, log_handler=None)
    except discord.LoginFailure:
        print('Niepoprawny token bota.')
    except (discord.HTTPException, OSError) as exc:
        print('Blad polaczenia:', type(exc).__name__)


if __name__ == '__main__':
    main()
