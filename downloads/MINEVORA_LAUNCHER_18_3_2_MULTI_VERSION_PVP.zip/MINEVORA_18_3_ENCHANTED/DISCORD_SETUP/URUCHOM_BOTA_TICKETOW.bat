@echo off
cd /d "%~dp0"
py minevora_tickets_bot.py
pause
