MINEVORA 12.0 — WYGLĄD JAK NA OBRAZKU
=======================================

Ta wersja bazuje na rzeczywistym kodzie MINEVORA 11.7 i zachowuje dotychczasowe
sekcje, w tym logowanie Microsoft, Minecraft Java, mody, marketplace,
PvP, ranking, Together oraz edytor skinów.

NOWOŚĆ: ekran główny wygląda jak na przekazanym obrazie 1536×864.
Grafika z obrazu służy jako warstwa wizualna, a NA niej działają
rzeczywiste przyciski Qt (także dostępne przez Tab/Enter).
Wersja aplikacji, stan logowania i aktywna instancja w obrazie zostały
zamaskowane i zastąpione prawdziwymi wartościami, nie przykładowymi danymi.

Kafelki: MINIGRY -> 7 minigier i wybór trybu, PVP CENTER -> aktualny PvP,
RANKING -> istniejąca zakładka rankingu. Wszystkie nawigacyjne kliknięcia
są podpięte do dotychczasowych funkcji launchera.

Ważne: samo wybranie BedWars / SkyWars itp. nie uruchamia meczu bez hostingu.
Plugin serwera i sieć Velocity wymagają osobnej konfiguracji. Minigry to
na razie działający ekran wyboru, nie aktywna kolejka online.

INSTALACJA NA WINDOWS 11
1. Wypakuj cały ZIP (nie uruchamiaj bezpośrednio w archiwum).
2. Zainstaluj Python 3.11 lub 3.12 64-bit z obsługą PATH.
3. Uruchom INSTALUJ_ZALEZNOSCI.bat.
4. Uruchom URUCHOM_MINEVORA.bat.
5. Zaloguj konto Microsoft i zainstaluj Minecraft.

Jeżeli obraz ekranu głównego nie jest widoczny, sprawdź:
  assets/minevora_home_reference.jpg
Nie usuwaj plików z podfolderu assets.

Wersja oparta na grafice referencyjnej otrzymanej od użytkownika.
Oryginalny minevora_qt.py jest w pliku minevora_qt_11_7_ORIGINAL.py.bak.
Ta paczka zawiera KOD PYTHON, nie gotowy Windows EXE.
