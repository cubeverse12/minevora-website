"""MINEVORA 9.4 — local Fair Play moderation panel, no remote spying.

Does not contact Minecraft accounts, other servers, or third party services.
Information is manually entered and cannot be used for automated bans.
"""
from copy import deepcopy
from datetime import datetime

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFormLayout,
    QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox,
    QPushButton, QScrollArea, QTextEdit, QVBoxLayout, QWidget, QFileDialog)

from minevora_fairplay_core import (KINDS, STATUSES, add_record, clean_name,
    clean_uuid, empty_data, load_data, new_player, save_data, summary, update_record_status, review_queue)

from minevora_guard_import import import_guard_log
from minevora_player_profile_qt import PlayerProfileDialog
from minevora_guard_presets import PRESETS, render_preset

KIND_NAMES = {'ban': '⛔ Ban serwerowy', 'alert': '⚠ Sygnał antycheat',
              'linked': '◈ Zgłoszone powiązanie kont'}


def label(value, size=12, bold=False, muted=False):
    widget = QLabel(value)
    widget.setWordWrap(True)
    widget.setTextFormat(Qt.PlainText)
    widget.setStyleSheet('background:transparent;color:%s;font-size:%dpx;font-weight:%d' %
                         ('#b7c8e6' if muted else '#faf4ff', size, 700 if bold else 400))
    return widget


def button(title, handler, primary=False):
    b = QPushButton(title)
    b.setObjectName('primary' if primary else 'normal')
    b.setCursor(Qt.PointingHandCursor)
    b.clicked.connect(lambda checked=False: handler())
    return b


class PlayerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('MINEVORA • Dodaj profil do Fair Play')
        self.setMinimumWidth(430)
        v = QVBoxLayout(self)
        v.addWidget(label('NOWY PROFIL GRACZA', 21, True))
        form = QFormLayout()
        self.name = QLineEdit()
        self.name.setMaxLength(16)
        self.name.setPlaceholderText('Nick Minecraft Java')
        self.uuid = QLineEdit()
        self.uuid.setMaxLength(36)
        self.uuid.setPlaceholderText('Opcjonalnie: oficjalny UUID gracza')
        form.addRow('Nick:', self.name)
        form.addRow('UUID (opcjonalnie):', self.uuid)
        v.addLayout(form)
        v.addWidget(label('Nick i UUID wpisujesz ręcznie. Launcher nie potwierdza tożsamości konta.', 11, muted=True))
        actions = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        actions.accepted.connect(self.validate)
        actions.rejected.connect(self.reject)
        v.addWidget(actions)

    def validate(self):
        try:
            clean_name(self.name.text())
            clean_uuid(self.uuid.text())
        except ValueError as exc:
            QMessageBox.warning(self, 'Profil Fair Play', str(exc))
            return
        self.accept()


class RecordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('MINEVORA • Raport Fair Play')
        self.setMinimumWidth(490)
        v = QVBoxLayout(self)
        v.addWidget(label('DODAJ RAPORT MODERACYJNY', 21, True))
        form = QFormLayout()
        self.kind = QComboBox()
        for kind in KINDS:
            self.kind.addItem(KIND_NAMES[kind], kind)
        self.server = QLineEdit()
        self.server.setMaxLength(100)
        self.server.setPlaceholderText('Serwer, którym zarządzasz')
        self.status = QComboBox()
        self.account = QLineEdit()
        self.account.setMaxLength(16)
        self.account.setPlaceholderText('Inny nick, tylko przy powiązaniu kont')
        self.reference = QLineEdit()
        self.reference.setMaxLength(80)
        self.reference.setPlaceholderText('Opcjonalny identyfikator zgłoszenia')
        self.details = QTextEdit()
        self.details.setMaximumHeight(90)
        self.details.setPlaceholderText('Krótki opis zdarzenia (bez prywatnych danych)')
        form.addRow('Rodzaj:', self.kind)
        form.addRow('Serwer / sieć:', self.server)
        form.addRow('Status:', self.status)
        form.addRow('Powiązane konto:', self.account)
        form.addRow('Numer raportu:', self.reference)
        form.addRow('Uzasadnienie:', self.details)
        v.addLayout(form)
        v.addWidget(label('Wszystkie dodane tu informacje pozostają ręcznymi wpisami — nawet jeśli wskażesz status „sprawdzone lokalnie”.', 11, muted=True))
        v.addWidget(label('Nie wpisuj adresów IP, danych urządzeń, haseł ani prywatnych informacji graczy.', 11, muted=True))
        self.kind.currentIndexChanged.connect(self.update_status)
        self.update_status()
        actions = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        actions.accepted.connect(self.validate)
        actions.rejected.connect(self.reject)
        v.addWidget(actions)

    def update_status(self, *_):
        kind = self.kind.currentData()
        self.status.clear()
        self.status.addItems(STATUSES[kind])
        self.account.setEnabled(kind == 'linked')
        if kind != 'linked':
            self.account.clear()

    def validate(self):
        try:
            if not self.server.text().strip():
                raise ValueError('Podaj serwer lub sieć.')
            if self.kind.currentData() == 'linked':
                clean_name(self.account.text())
        except ValueError as exc:
            QMessageBox.warning(self, 'Raport Fair Play', str(exc))
            return
        self.accept()

    def values(self):
        return dict(kind=self.kind.currentData(), server=self.server.text().strip(),
                    status=self.status.currentText(), account=self.account.text().strip(),
                    reference=self.reference.text().strip(), detail=self.details.toPlainText().strip())


class FairPlayPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = load_data()
        self.build_ui()
        self.refresh_data()

    def build_ui(self):
        base = QVBoxLayout(self)
        base.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        base.addWidget(scroll)
        area = QWidget()
        v = QVBoxLayout(area)
        v.setContentsMargins(28, 25, 28, 30)
        v.setSpacing(15)
        scroll.setWidget(area)
        v.addWidget(label('🛡  MINEVORA FAIR PLAY', 28, True))
        v.addWidget(label('Panel lokalnych zgłoszeń moderatora · Historia banów, powiązania kont i sygnały antycheat', 12, muted=True))
        info = QFrame()
        info.setObjectName('hero')
        iv = QVBoxLayout(info)
        iv.addWidget(label('ℹ  ZASADA UCZCIWEJ OCENY', 16, True))
        iv.addWidget(label('Nie ma publicznego dostępu do wszystkich banów Minecraft. Nie wykrywamy multikont po IP ani odcisku urządzenia. Nie wyliczamy „% cheatowania” z niepewnych danych.', 12))
        iv.addWidget(label('Raporty mogą pochodzić z wpisów ręcznych albo z zaimportowanych logów serwera. Importowany plik NIE jest niezależnie uwierzytelniany. Decyzję podejmuje moderator po sprawdzeniu dowodów.', 11, muted=True))
        v.addWidget(info)
        row = QHBoxLayout()
        row.addWidget(label('👤  PROFILE GRACZY', 19, True))
        row.addStretch()
        row.addWidget(button('＋ Dodaj gracza', self.add_player, True))
        v.addLayout(row)
        self.search = QLineEdit()
        self.search.setPlaceholderText('Szukaj lokalnego profilu po nicku / UUID…')
        self.search.textChanged.connect(self.refresh_players)
        v.addWidget(self.search)
        self.only_attention = __import__('PySide6.QtWidgets',fromlist=['QCheckBox']).QCheckBox('Pokaż tylko profile z nierozpatrzonymi zgłoszeniami')
        self.only_attention.toggled.connect(self.refresh_players)
        v.addWidget(self.only_attention)
        self.queue_summary = label('Kolejka: sprawdzanie…', 12, True)
        v.addWidget(self.queue_summary)
        self.players = QListWidget()
        self.players.setMinimumHeight(112)
        self.players.setMaximumHeight(200)
        self.players.currentItemChanged.connect(self.refresh_report)
        self.players.itemDoubleClicked.connect(self.open_player_profile)
        v.addWidget(self.players)
        open_row = QHBoxLayout()
        open_row.addWidget(button('👤 Otwórz profil gracza', self.open_player_profile, True))
        open_row.addWidget(label('Dwuklik na nick otwiera historię banów i powiązań.', 11, muted=True))
        v.addLayout(open_row)
        action = QHBoxLayout()
        action.addWidget(button('＋ Nowy raport', self.add_report, True))
        action.addWidget(button('⇧ Import Guard JSONL', self.import_log))
        action.addWidget(button('⚙ Guard: ustawienia', self.guard_config))
        action.addWidget(button('✕ Usuń raport', self.remove_report))
        action.addWidget(button('🗑 Usuń profil i dane', self.remove_player))
        v.addLayout(action)
        v.addWidget(label('📊  PODSUMOWANIE GRACZA', 19, True))
        stats = QFrame()
        stats.setObjectName('panel')
        stat_v = QVBoxLayout(stats)
        self.player_title = label('Wybierz profil gracza.', 18, True)
        stat_v.addWidget(self.player_title)
        self.identity = label('', 11, muted=True)
        stat_v.addWidget(self.identity)
        self.ban_stat = label('', 14, True)
        self.links_stat = label('', 14, True)
        self.alert_stat = label('', 14, True)
        self.review_stat = label('', 12, muted=True)
        for widget in (self.ban_stat, self.links_stat, self.alert_stat, self.review_stat):
            stat_v.addWidget(widget)
        v.addWidget(stats)
        v.addWidget(label('🧾  RAPORTY I ŹRÓDŁA', 19, True))
        self.records = QListWidget()
        self.records.setMinimumHeight(180)
        self.records.setMaximumHeight(260)
        self.records.currentItemChanged.connect(self.refresh_record_detail)
        v.addWidget(self.records)
        self.record_detail = label('Wybierz raport, aby zobaczyć szczegóły.', 11, muted=True)
        v.addWidget(self.record_detail)
        review_row = QHBoxLayout()
        review_row.addWidget(label('Nowy status:'))
        self.quick_status = QComboBox()
        review_row.addWidget(self.quick_status)
        review_row.addWidget(button('✓ Zapisz decyzję', self.review_selected_report, True))
        v.addLayout(review_row)
        v.addWidget(label('Dane tylko na Twoim komputerze: %USERPROFILE%\\.minevora\\fairplay_notes.json. Dostęp do nich powinni mieć wyłącznie uprawnieni moderatorzy. Nie są udostępniane do innych serwerów ani publikowane.', 10, muted=True))
        v.addStretch()

    def selected_player(self):
        item = self.players.currentItem()
        if not item:
            return None
        player_id = item.data(Qt.UserRole)
        return next((p for p in self.data['players'] if p['id'] == player_id), None)

    def selected_record(self):
        player = self.selected_player()
        item = self.records.currentItem()
        if not item or not player:
            return None
        record_id = item.data(Qt.UserRole)
        return next((r for r in player['records'] if r['id'] == record_id), None)

    def persist(self, before):
        try:
            save_data(self.data)
            return True
        except OSError as exc:
            self.data = before
            QMessageBox.warning(self, 'MINEVORA Fair Play', 'Nie można zapisać danych: ' + str(exc))
            self.refresh_data()
            return False

    def refresh_data(self):
        self.data = load_data()
        self.refresh_players()

    def refresh_players(self, selected_id=None):
        if selected_id is None:
            p = self.selected_player()
            selected_id = p['id'] if p else None
        keyword = self.search.text().strip().casefold()
        attention = review_queue(self.data)
        self.queue_summary.setText('Do sprawdzenia: %d zgłoszeń  •  Rozpatruj po weryfikacji dowodów' % len(attention))
        attention_ids = {row['player_id'] for row in attention}
        self.players.blockSignals(True)
        self.players.clear()
        target_row = -1
        for p in self.data['players']:
            if self.only_attention.isChecked() and p['id'] not in attention_ids:
                continue
            if keyword and keyword not in p['name'].casefold() and keyword not in p['uuid']:
                continue
            from PySide6.QtWidgets import QListWidgetItem
            item = QListWidgetItem(f"◈  {p['name']}  ·  {len(p['records'])} raportów")
            item.setData(Qt.UserRole, p['id'])
            self.players.addItem(item)
            if p['id'] == selected_id:
                target_row = self.players.count() - 1
        if target_row < 0 and self.players.count():
            target_row = 0
        self.players.setCurrentRow(target_row)
        self.players.blockSignals(False)
        self.refresh_report()

    def refresh_report(self, *_):
        player = self.selected_player()
        self.records.blockSignals(True)
        self.records.clear()
        if not player:
            self.player_title.setText('Brak wybranego profilu')
            self.identity.setText('Dodaj gracza do lokalnej bazy moderatora.')
            self.ban_stat.setText('')
            self.links_stat.setText('')
            self.alert_stat.setText('')
            self.review_stat.setText('')
            self.record_detail.setText('Brak raportów.')
            self.quick_status.clear()
            self.records.blockSignals(False)
            return
        s = summary(player)
        self.player_title.setText('👤  ' + player['name'])
        self.identity.setText('UUID: ' + (player['uuid'] or 'niepodany / tożsamość niezweryfikowana'))
        self.ban_stat.setText(f"⛔  Bany z lokalnych wpisów: {s['bans_total']}  ·  aktywne: {s['bans_active']}  ·  zgłoszone sieci: {s['servers_reported']}")
        self.links_stat.setText(f"◈  Zgłoszone powiązania kont: {s['linked_reports']}  (bez niezależnego potwierdzenia)")
        self.alert_stat.setText(f"⚠  Otwarte sygnały antycheat: {s['alerts_open']}")
        self.review_stat.setText(s['review_state'] + '  ·  Brak matematycznego prawdopodobieństwa oszukiwania.')
        from PySide6.QtWidgets import QListWidgetItem
        for r in reversed(player['records']):
            item = QListWidgetItem(f"{KIND_NAMES[r['kind']]}  •  {r['server']}  •  {r['status']}")
            item.setData(Qt.UserRole, r['id'])
            self.records.addItem(item)
        self.records.blockSignals(False)
        if self.records.count():
            self.records.setCurrentRow(0)
        else:
            self.record_detail.setText('Brak raportów dla tego profilu.')

    def refresh_record_detail(self, *_):
        r = self.selected_record()
        if not r:
            self.record_detail.setText('Wybierz raport, aby sprawdzić jego pochodzenie.')
            self.quick_status.clear()
            return
        self.quick_status.blockSignals(True)
        self.quick_status.clear()
        self.quick_status.addItems(STATUSES.get(r['kind'],()))
        self.quick_status.setCurrentText(r.get('status',''))
        self.quick_status.blockSignals(False)
        self.record_detail.setText('\n'.join([
            f"Typ: {KIND_NAMES[r['kind']]}  ·  Status: {r['status']}",
            f"Serwer: {r['server']}  ·  Data: {r['created_at'][:19].replace('T',' ')}",
            'Powiązane konto: ' + r['account'] if r['kind'] == 'linked' else '',
            'Numer raportu: ' + r['reference'] if r['reference'] else '',
            'Opis: ' + r['detail'] if r['detail'] else '',
            'Źródło: ' + r['source'],
            'Ostatnia decyzja: ' + (r.get('review_history', [{}])[-1].get('to', '') if r.get('review_history') else 'brak')
        ]).strip())

    def add_player(self):
        dlg = PlayerDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        before = deepcopy(self.data)
        try:
            p = new_player(self.data, dlg.name.text(), dlg.uuid.text())
        except ValueError as exc:
            QMessageBox.warning(self, 'MINEVORA Fair Play', str(exc))
            return
        if self.persist(before):
            self.search.clear()
            self.refresh_players(p['id'])

    def add_report(self):
        player = self.selected_player()
        if not player:
            QMessageBox.information(self, 'MINEVORA Fair Play', 'Najpierw wybierz lub dodaj profil.')
            return
        dlg = RecordDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        before = deepcopy(self.data)
        try:
            add_record(player, **dlg.values())
        except ValueError as exc:
            QMessageBox.warning(self, 'MINEVORA Fair Play', str(exc))
            return
        if self.persist(before):
            self.refresh_players(player['id'])

    def import_log(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, 'Importuj lokalny dziennik MINEVORA Guard', '', 'Log antycheat (*.jsonl)')
        if not file_name:
            return
        if QMessageBox.question(self, 'Import MINEVORA Guard',
                'Importowane alerty są tylko sygnałami do weryfikacji. Plik może być podmieniony; '
                'nie oznacza potwierdzonego cheatowania ani dowodu winy. Kontynuować?') != QMessageBox.Yes:
            return
        before = deepcopy(self.data)
        try:
            result = import_guard_log(self.data, file_name)
        except (OSError, ValueError, UnicodeError) as exc:
            self.data = before
            QMessageBox.warning(self, 'Import MINEVORA Guard', str(exc))
            return
        if self.persist(before):
            self.refresh_data()
            QMessageBox.information(self, 'Import zakończony',
                f"Nowe alerty: {result['imported']}\nPominięte duplikaty: {result['duplicate']}\n"
                f"Nieprawidłowe wpisy: {result['ignored']}\nNowe profile: {result['created_players']}\n"
                f"Pominięte przez limity: {result['full']}\n\nStatus: do ręcznej weryfikacji.")

    def open_player_profile(self, *_):
        player = self.selected_player()
        if not player:
            QMessageBox.information(self, 'Profil gracza', 'Najpierw wybierz lub dodaj profil gracza.')
            return
        dialog = PlayerProfileDialog(deepcopy(player),
            remove_report=self.remove_report_by_id,
            remove_player=self.remove_player_by_id, update_report=self.update_report_by_id, parent=self)
        dialog.exec()

    def review_selected_report(self):
        player, record = self.selected_player(), self.selected_record()
        if not player or not record:
            QMessageBox.information(self, 'Fair Play', 'Wybierz najpierw raport.')
            return
        status = self.quick_status.currentText()
        if status == record.get('status'):
            QMessageBox.information(self, 'Fair Play', 'Status tego raportu nie wymaga zmiany.')
            return
        note, ok = __import__('PySide6.QtWidgets',fromlist=['QInputDialog']).QInputDialog.getText(
            self, 'Decyzja moderatora', 'Krótka notatka (opcjonalnie; bez danych prywatnych):')
        if ok:
            self.update_report_by_id(player['id'], record['id'], status, note)

    def update_report_by_id(self, player_id, record_id, status, note=''):
        player = next((p for p in self.data['players'] if p['id'] == player_id), None)
        if player is None:return False
        before = deepcopy(self.data)
        try:
            result = update_record_status(player, record_id, status, note)
        except ValueError as exc:
            QMessageBox.warning(self, 'Fair Play', str(exc))
            return False
        if not result:return False
        if self.persist(before):
            self.refresh_players(player_id)
            return True
        return False

    def guard_config(self):
        dialog = QDialog(self)
        dialog.setWindowTitle('MINEVORA Guard • bezpieczna konfiguracja')
        dialog.resize(640, 510)
        layout = QVBoxLayout(dialog)
        layout.addWidget(label('⚙ KONFIGURATOR ANTICHEAT', 20, True))
        layout.addWidget(label('Profil konserwatywny ogranicza fałszywe alerty. Zmiany dotyczą tylko pliku config.yml i wymagają restartu lub /mg reload na serwerze Paper.', 11, muted=True))
        picker = QComboBox()
        for code, data in PRESETS.items():picker.addItem(data['title'], code)
        layout.addWidget(picker)
        area = QTextEdit();area.setReadOnly(True)
        layout.addWidget(area, 1)
        def sync():area.setPlainText(render_preset(picker.currentData()))
        picker.currentIndexChanged.connect(sync);sync()
        buttons = QHBoxLayout()
        def save():
            file_name, _ = QFileDialog.getSaveFileName(dialog, 'Zapisz konfigurację Guard', 'config.yml', 'YAML (*.yml *.yaml)')
            if file_name:
                try:
                    from pathlib import Path
                    Path(file_name).write_text(area.toPlainText(), encoding='utf-8')
                except OSError as exc:QMessageBox.warning(dialog, 'Guard', str(exc))
                else:QMessageBox.information(dialog, 'Guard', 'Plik zapisany. Zrób kopię obecnego config.yml serwera przed podmianą.')
        buttons.addWidget(button('💾 Zapisz config.yml',save,True))
        buttons.addWidget(button('Zamknij',dialog.accept))
        layout.addLayout(buttons)
        dialog.exec()

    def remove_report_by_id(self, player_id, record_id):
        player = next((p for p in self.data['players'] if p['id'] == player_id), None)
        if player is None or not any(r['id'] == record_id for r in player['records']):
            return False
        before = deepcopy(self.data)
        player['records'] = [r for r in player['records'] if r['id'] != record_id]
        if self.persist(before):
            self.refresh_players(player_id)
            return True
        return False

    def remove_player_by_id(self, player_id):
        if not any(p['id'] == player_id for p in self.data['players']):
            return False
        before = deepcopy(self.data)
        self.data['players'] = [p for p in self.data['players'] if p['id'] != player_id]
        if self.persist(before):
            self.refresh_players()
            return True
        return False

    def remove_report(self):
        player = self.selected_player()
        record = self.selected_record()
        if not player or not record:
            return
        if QMessageBox.question(self, 'Usuń raport', 'Usunąć wybrany lokalny raport?') == QMessageBox.Yes:
            self.remove_report_by_id(player['id'], record['id'])

    def remove_player(self):
        player = self.selected_player()
        if not player:
            return
        if QMessageBox.question(self, 'Usuń dane gracza',
                f"Usunąć profil „{player['name']}” i całą zapisaną historię raportów?") == QMessageBox.Yes:
            self.remove_player_by_id(player['id'])
