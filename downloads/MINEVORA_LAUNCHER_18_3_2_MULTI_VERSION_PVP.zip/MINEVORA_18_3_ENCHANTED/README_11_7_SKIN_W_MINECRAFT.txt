MINEVORA 11.7 — UŻYJ SKINA W MINECRAFT JAVA EDITION

Nowości:
- Przycisk „UŻYJ SKINA W MINECRAFT” w edytorze Skin Creator.
- Wysyłanie własnego skina PNG do Minecraft Services tylko po wyraźnym potwierdzeniu.
- Wybór ramion: Classic (Steve) lub Slim (Alex).
- Skin zostaje ustawiony na zalogowanym koncie Minecraft Java Edition.
- Kopia pliku PNG automatycznie zapisana w ~/.minevora/skins także w razie błędu połączenia.
- Alternatywny przycisk eksportu do oficjalnego Minecraft Launcher (bez logowania w MINEVORA).
- Serwer Minecraft nie otrzymuje hasła Microsoft. Używany jest wyłącznie token gry z bieżącej sesji RAM.
- Proces wysyłania nie blokuje interfejsu — osobny wątek.

JAK UŻYĆ:
1. Rozpakuj ZIP i uruchom INSTALUJ_ZALEZNOSCI.bat (pierwszy raz), później URUCHOM_MINEVORA.bat.
2. Zaloguj konto Microsoft posiadające Minecraft: Java Edition w launcherze MINEVORA.
3. Wejdź w Skin Studio, stwórz lub wczytaj skin.
4. Wybierz Classic albo Slim.
5. Kliknij „UŻYJ SKINA W MINECRAFT” i potwierdź konto.
6. Poczekaj na komunikat serwera Minecraft o zakończeniu zmiany.

JEŻELI WYSYŁANIE NIE DZIAŁA:
- Użyj „Zapisz PNG do oficjalnego launchera”.
- Otwórz oficjalny Minecraft Launcher > Java Edition > Skins > New Skin.
- Wybierz pobrany PNG, wybierz Classic/Slim i kliknij Save & Use.

UWAGI:
- Działa z Minecraft Java Edition, nie z Minecraft Bedrock.
- Pelerynki nie są automatycznie przypisywane do konta; dotyczą innych uprawnień.
- Wymagane jest działające logowanie Microsoft i ważny token konta posiadającego Java Edition.
- Nie wprowadzaj loginu, hasła ani tokenu w polach czatu lub plikach konfiguracji.
- Żadnego tokenu nie zapisujemy do plików.
- Kod testowany offline; skuteczność prawdziwego wysyłania wymaga konta Minecraft i Windows.
