MINEVORA 11.5 — PREMIUM SKIN STUDIO

Nowości:
- odświeżony wygląd launchera w bardziej premium stylu,
- ulepszony edytor skinów w kolorach MINEVORA,
- większy podgląd 3D,
- motywy tła, zoom, ostatnie skiny,
- szybsze akcje importu/eksportu.

Uwaga:
To nie jest pełny edytor piksel po pikselu. Jest to rozbudowany panel podglądu i zarządzania skinami.
