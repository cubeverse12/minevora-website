"""Offline regression suite for safe MINEVORA Fabric multi-version installer."""
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import minevora_pvp_auto as a
import minevora_pvp_github as gh

def fake_jar(path,mc,version='2.0.5',mod_id=a.MOD_ID):
    path.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('fabric.mod.json',json.dumps({'id':mod_id,'environment':'client',
            'version':version,'depends':{'minecraft':mc}}))
        z.writestr(a.MOD_CLASS,b'\xca\xfe\xba\xbe'+b'A'*400)
    return path

class MultiVersionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        for obj,name,value in [(a,'CACHE_DIR',self.base/'cache'),
                               (a,'CACHE_JAR',self.base/'cache'/'minevora-pvp-hud-fabric-1.21.1.jar'),
                               (a,'BUNDLED_JAR',self.base/'bundle-missing.jar'),
                               (gh,'CACHE_DIR',self.base/'cache')]:
            patcher=patch.object(obj,name,value)
            patcher.start();self.addCleanup(patcher.stop)

    def test_recognise_fabric_and_other_loaders(self):
        self.assertEqual(a.profile_target('fabric-loader-0.16.10-1.21.1'),('fabric','1.21.1'))
        self.assertEqual(a.profile_target('fabric-1.21.10'),('fabric','1.21.10'))
        self.assertEqual(a.profile_target('26.1-fabric'),('fabric','26.1'))
        self.assertEqual(a.profile_target('forge-1.20.1'),('forge','1.20.1'))
        self.assertEqual(a.profile_target('Fabric1.21.1'),('fabric','1.21.1'))
        self.assertEqual(a.profile_target('1.21.1'),(None,None))

    def test_jar_compatibility_exact(self):
        one=fake_jar(self.base/'one.jar','1.21.1')
        four=fake_jar(self.base/'four.jar','1.21.4')
        self.assertTrue(a.is_hud_jar(one,'1.21.1'))
        self.assertFalse(a.is_hud_jar(one,'1.21.4'))
        self.assertTrue(a.is_hud_jar(four,'1.21.4'))
        self.assertFalse(a.is_hud_jar(fake_jar(self.base/'other.jar','1.21.4',mod_id='other')))

    def test_does_not_use_1211_jar_in_1214(self):
        a.cache_jar(fake_jar(self.base/'one.jar','1.21.1'))
        state,msg=a.provision('fabric-loader-1.21.4',self.base/'game')
        self.assertEqual(state,'missing')
        self.assertIn('1.21.4',msg)
        self.assertFalse((self.base/'game'/'mods').exists())

    def test_isolated_install_and_disable_wrong_version(self):
        a.cache_jar(fake_jar(self.base/'one.jar','1.21.1'))
        a.cache_jar(fake_jar(self.base/'four.jar','1.21.4'))
        home=self.base/'instance'
        self.assertEqual(a.provision('fabric-1.21.1',home)[0],'ready')
        self.assertEqual(a.provision('fabric-1.21.4',home)[0],'ready')
        mods=home/'mods'
        self.assertTrue((mods/'minevora-pvp-hud-fabric-1.21.4.jar').exists())
        self.assertTrue((mods/'minevora-pvp-hud-fabric-1.21.1.jar.disabled').exists())
        self.assertEqual(a.provision('fabric-1.21.1',home)[0],'ready')
        self.assertTrue((mods/'minevora-pvp-hud-fabric-1.21.1.jar').exists())
        self.assertTrue((mods/'minevora-pvp-hud-fabric-1.21.4.jar.disabled').exists())

    def test_unsupported_loader_only_disables_verified_hud(self):
        mods=self.base/'instance'/'mods'
        jar=fake_jar(mods/'minevora-pvp-hud-fabric-1.21.1.jar','1.21.1')
        stranger=mods/'minevora-pvp-hud-unknown.jar';stranger.write_bytes(b'UNKNOWN')
        self.assertEqual(a.provision('neoforge-1.21.1',self.base/'instance')[0],'unsupported')
        self.assertFalse(jar.exists())
        self.assertTrue(stranger.exists())

    def test_assets_need_matching_filename(self):
        release=[{'draft':False,'prerelease':False,'assets':[
          {'name':'minevora-pvp-hud-fabric-1.21.1.jar','browser_download_url':'https://github.com/'+gh.REPO+'/releases/download/x/1.jar','size':800},
          {'name':'minevora-pvp-hud-fabric-1.21.4.jar','browser_download_url':'https://github.com/'+gh.REPO+'/releases/download/x/4.jar','size':800}
        ]}]
        asset,_=gh._matching_asset(release,'1.21.4')
        self.assertIn('1.21.4',asset['name'])
        with self.assertRaises(gh.NoRelease):gh._matching_asset(release,'1.20.1')

    def test_release_metadata_mismatch_rejected(self):
        # Deliberately advertise MC 1.21.4 but serve 1.21.1 inside the JAR.
        jar=fake_jar(self.base/'wrong.jar','1.21.1')
        release=[{'draft':False,'prerelease':False,'assets':[
          {'name':'minevora-pvp-hud-fabric-1.21.4.jar','browser_download_url':'https://github.com/'+gh.REPO+'/releases/download/v1/test.jar','size':jar.stat().st_size}]}]
        def request(url,limit=20_000_000):
            return json.dumps(release).encode() if url==gh.API else jar.read_bytes()
        with patch.object(gh,'_request',side_effect=request):
            with self.assertRaisesRegex(ValueError,'nie jest modem'):
                gh.update_from_github(version='fabric-1.21.4')
        self.assertFalse(a.version_cache('1.21.4').exists())

    def test_correct_release_downloaded_and_installed(self):
        jar=fake_jar(self.base/'good.jar','1.21.4')
        release=[{'draft':False,'prerelease':False,'assets':[
          {'name':'minevora-pvp-hud-fabric-1.21.4.jar','browser_download_url':'https://github.com/'+gh.REPO+'/releases/download/v1/test.jar','size':jar.stat().st_size}]}]
        def request(url,limit=20_000_000):
            return json.dumps(release).encode() if url==gh.API else jar.read_bytes()
        with patch.object(gh,'_request',side_effect=request):
            result=gh.update_from_github(version='fabric-1.21.4')
        self.assertIn('1.21.4',result)
        self.assertEqual(a.provision('fabric-1.21.4',self.base/'game')[0],'ready')

    def test_no_downgrading(self):
        a.cache_jar(fake_jar(self.base/'new.jar','1.21.4','2.0.8'))
        old=fake_jar(self.base/'old.jar','1.21.4','2.0.5')
        release=[{'draft':False,'prerelease':False,'assets':[
          {'name':'minevora-pvp-hud-fabric-1.21.4.jar','browser_download_url':'https://github.com/'+gh.REPO+'/releases/download/v1/test.jar','size':old.stat().st_size}]}]
        with patch.object(gh,'_request',side_effect=lambda url,limit=20_000_000:json.dumps(release).encode() if url==gh.API else old.read_bytes()):
            msg=gh.update_from_github(version='fabric-1.21.4')
        self.assertIn('nowszą',msg)
        self.assertEqual(gh._version(a.version_cache('1.21.4')),'2.0.8')

if __name__=='__main__':unittest.main(verbosity=2)
