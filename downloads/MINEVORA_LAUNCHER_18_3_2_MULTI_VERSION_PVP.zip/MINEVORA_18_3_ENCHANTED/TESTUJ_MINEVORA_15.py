"""Offline source, assets, and launcher continuity checks. No promises of full UI testing."""
import ast
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parent
for f in root.glob('*.py'):ast.parse(f.read_text(encoding='utf-8'),filename=str(f))
for n in ('minevora_qt.py','minevora_dashboard.py','minevora_enchanted_theme.py','minevora_skin3d_qt.py','minevora_icons.py','minevora_modrinth.py','minevora_engine.py'):
    assert (root/n).is_file(),n
for n in ('enchanted_hero.jpg','en_pvp.jpg','en_discord.jpg','en_minigames.jpg'):
    with Image.open(root/'assets'/n) as img:img.verify()
icons=list((root/'assets'/'icons').glob('*.png'))
assert len(icons)>=18,len(icons)
for icon in icons:
    with Image.open(icon) as img:
        assert img.size==(256,256)
        img.verify()
mods=ast.parse((root/'minevora_minigames_qt.py').read_text(encoding='utf-8'))
games=next(ast.literal_eval(stmt.value) for stmt in mods.body if isinstance(stmt,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MODES' for t in stmt.targets))
assert len(games)==9
window_ast=ast.parse((root/'minevora_qt.py').read_text(encoding='utf-8'))
window=next(v for v in window_ast.body if isinstance(v,ast.ClassDef) and v.name=='Window')
methods={v.name for v in window.body if isinstance(v,ast.FunctionDef)}
assert set(('home','instances','mods','market','minigames','pvp','leaderboard','discord_page','settings','together','play','skins')).issubset(methods)
print('PASS: source + 9 minigames + complete launcher API + graphic assets + high DPI icon set')
print('Windows GUI, external login, host connection must be tested on a configured Windows system.')
