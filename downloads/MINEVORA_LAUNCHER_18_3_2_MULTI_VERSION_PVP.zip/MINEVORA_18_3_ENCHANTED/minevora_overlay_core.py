"""Display only values that the launcher can actually verify.

FPS, server ping and friend presence are intentionally not estimated from the
launcher process. The Fabric mod renders its own FPS counter in Minecraft.
"""


def display_rows(elapsed_seconds, minecraft_version, *, show_version=True, show_time=True):
    """Return stable, non-speculative HUD rows from current launch metadata."""
    rows = []
    if show_version and minecraft_version:
        safe_version = str(minecraft_version).strip().replace("\n", " ").replace("\r", " ")[:60]
        if safe_version:
            rows.append(("version", "Minecraft: " + safe_version))
    if show_time:
        sec = max(0, int(elapsed_seconds))
        rows.append(("time", "Czas gry: %02d:%02d:%02d" % (sec // 3600, sec // 60 % 60, sec % 60)))
    return rows
