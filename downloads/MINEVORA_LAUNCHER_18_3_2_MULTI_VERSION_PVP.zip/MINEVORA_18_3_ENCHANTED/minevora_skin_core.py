"""UV selections and deterministic original 64x64 Minecraft skin templates.

Pure Python (no GUI dependency) for easy testing and safe reuse.
All rectangles use half-open pixel coordinates (left, top, right, bottom).
"""
import re

W = H = 64

# Standard 64x64 Minecraft Java skin UV islands. UV bounding rectangles include
# every face, top and bottom, and leave unused pixels unaffected by layer tools.
AREAS = {
    'Głowa': [(0, 0, 32, 16)],
    'Tułów': [(16, 16, 40, 32)],
    'Ręce': [(40, 16, 56, 32), (32, 48, 48, 64)],
    'Nogi': [(0, 16, 16, 32), (16, 48, 32, 64)],
    'Kapelusz': [(32, 0, 64, 16)],
    'Kurtka': [(16, 32, 40, 48)],
    'Rękawy': [(40, 32, 56, 48), (48, 48, 64, 64)],
    'Nogawki': [(0, 32, 16, 48), (0, 48, 16, 64)],
}
BASE_NAMES = ('Głowa', 'Tułów', 'Ręce', 'Nogi')
OVERLAY_NAMES = ('Kapelusz', 'Kurtka', 'Rękawy', 'Nogawki')
LAYER_NAMES = ('Wszystko', 'Baza', 'Nakładki') + BASE_NAMES + OVERLAY_NAMES

PRESETS = {
    'Cyber Wilk': {'head': '#8499bc', 'body': '#192947', 'arm': '#27365b', 'leg': '#14253a', 'detail': '#bde4ff'},
    'Strażnik Lasu': {'head': '#d6ae80', 'body': '#315344', 'arm': '#547053', 'leg': '#283d38', 'detail': '#e6dfbb'},
    'Portalowy Mag': {'head': '#c6b5d9', 'body': '#342458', 'arm': '#4b347b', 'leg': '#28244d', 'detail': '#f1d3ff'},
}


def rects_for_layer(name):
    if name == 'Wszystko':
        return [(0, 0, 64, 64)]
    if name == 'Baza':
        names = BASE_NAMES
    elif name == 'Nakładki':
        names = OVERLAY_NAMES
    else:
        names = (name,) if name in AREAS else ()
    return [r for n in names for r in AREAS[n]]


def allowed_pixel(layer, x, y, height=64):
    if not (0 <= x < 64 and 0 <= y < height):
        return False
    return any(l <= x < r and t <= y < b for l, t, r, b in rects_for_layer(layer))


def color_rgb(hex_color):
    color = str(hex_color).strip().lstrip('#')
    if not re.fullmatch(r'[0-9a-fA-F]{6}', color):
        raise ValueError('Kolor musi mieć format #RRGGBB.')
    return tuple(int(color[i:i+2], 16) for i in (0, 2, 4))


def safe_preset_name(label):
    """Generate local filename without traversal, separators or Windows device names."""
    value = re.sub(r'[^A-Za-z0-9_\-]', '_', str(label)).strip('_')[:50]
    if not value or re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])',value,re.I):
        return 'my_skin'
    return value


def generate_preset(kind, accent='#6b63ff'):
    """Return raw 64x64 RGBA bytes for an original, Minecraft UV-compatible skin."""
    if kind not in PRESETS:
        raise ValueError('Nieznany szablon skina: ' + str(kind))
    palette = PRESETS[kind]
    a = color_rgb(accent)
    pixels = bytearray(64*64*4)

    def pixel(x, y, rgb, alpha=255):
        if 0 <= x < 64 and 0 <= y < 64:
            offset = (y*64+x)*4
            pixels[offset:offset+4] = bytes((*rgb, alpha))

    def block(l, t, r, b, rgb, alpha=255):
        for y in range(t,b):
            for x in range(l,r): pixel(x,y,rgb,alpha)

    head=color_rgb(palette['head'])
    body=color_rgb(palette['body'])
    arm=color_rgb(palette['arm'])
    leg=color_rgb(palette['leg'])
    detail=color_rgb(palette['detail'])
    base_colors={'Głowa':head, 'Tułów':body, 'Ręce':arm, 'Nogi':leg}
    for area_name, rgb in base_colors.items():
        for l,t,r,b in AREAS[area_name]:block(l,t,r,b,rgb)

    # Eyes and muzzle of each template on the front of the head (8,8)-(16,16).
    for x in (10, 13):
        pixel(x,11,detail)
        pixel(x,12,(25,38,67))
    for x in (11,12):pixel(x,14,tuple(max(0,int(c*.63)) for c in head))
    for x in range(8,16):pixel(x,8,tuple(min(255,c+20) for c in head))

    # Shirt/armor details on torso front and sleeves.
    block(23,21,25,28,a)
    block(20,20,28,21,detail)
    block(44,22,48,23,a)
    block(36,54,40,55,a)
    for x in range(4,12):
        pixel(x,27,a)
    for x in range(20,28):
        pixel(x,58,a)

    # Transparent secondary / overlay pieces, visible when enabled in Minecraft.
    # Hood band on hat layer front; do not paint entire UV or it hides the face.
    block(40,8,48,10,a)
    pixel(40,10,a);pixel(47,10,a)
    # Jacket stripes and accents on its front face.
    block(20,36,21,48,a)
    block(27,36,28,48,a)
    block(21,36,27,37,detail)
    # Sleeves (right arm and left arm overlay fronts)
    block(44,36,48,38,a)
    block(52,52,56,54,a)
    # Leg overlays / boots
    block(4,44,8,48,a)
    block(4,60,8,64,a)
    return bytes(pixels)


def flood_fill_points(pixel_getter, x, y, replacement, layer, height=64):
    """Find an iterative flood fill constrained to the selected UV layer.

    pixel_getter(x,y) must return a tuple of RGBA components; replacement is RGBA.
    Returns only coordinates; GUI applies the colors in one undoable operation.
    """
    if not allowed_pixel(layer, x, y, height):
        return []
    source=tuple(pixel_getter(x,y))
    if source == tuple(replacement):
        return []
    seen={(x,y)}
    stack=[(x,y)]
    filled=[]
    while stack:
        px,py=stack.pop()
        if tuple(pixel_getter(px,py)) != source:
            continue
        filled.append((px,py))
        for nx,ny in ((px-1,py),(px+1,py),(px,py-1),(px,py+1)):
            if (nx,ny) not in seen and allowed_pixel(layer,nx,ny,height):
                seen.add((nx,ny))
                stack.append((nx,ny))
    return filled


def pixels_on_line(x0,y0,x1,y1):
    """Bresenham segment ensures mouse strokes do not leave gaps."""
    dx=abs(x1-x0); sx=1 if x0<x1 else -1
    dy=-abs(y1-y0); sy=1 if y0<y1 else -1
    err=dx+dy
    while True:
        yield x0,y0
        if x0==x1 and y0==y1:break
        e2=err*2
        if e2>=dy:err+=dy;x0+=sx
        if e2<=dx:err+=dx;y0+=sy
