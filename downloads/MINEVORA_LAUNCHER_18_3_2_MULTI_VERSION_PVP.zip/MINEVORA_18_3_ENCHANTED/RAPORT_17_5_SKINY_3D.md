# MINEVORA 17.5 — testy geometrii skinów

Podstawa: MINEVORA 17.4 ENCHANTED.

## Poprawione

- Głowa 8 × 8 × 8 (poprzednio 8 × 8 × 4).
- Poprawione mapowanie 36 ścian podstawowych brył ciała z atlasu Minecraft Java 64 × 64.
- Poprawione 36 obszarów UV nakładek, z uwzględnieniem przezroczystości PNG.
- Ramiona Steve 4 px i Alex 3 px — poprawne szerokości i UV.
- Zachowane obroty myszy, zoom, import, eksport i opcjonalna nakładka.
- Pozostałe systemy launchera przeniesione bez zmiany logiki.

## Wyniki w środowisku automatycznym

- `pytest -q tests`: **154 tests passed, 24 subtests passed**.
- Wszystkie pliki `.py`: poprawna kompilacja offline przez `compileall`.
- Archiwum ZIP: weryfikacja integralności po utworzeniu.
- Nie przeprowadzono testu interfejsu okna PySide6 w Windows 11 w tym środowisku.

## Testy na Twoim Windows

1. Otwórz zakładkę Skiny 3D.
2. Sprawdź głowę z boku: powinna mieć wyraźnie 8 px głębokości.
3. Obróć model do tyłu i zobacz teksturę tyłu głowy.
4. Przełącz model Steve / Alex oraz warstwę nakładek.
5. Zaimportuj plik PNG 64×64, następnie wyeksportuj go.

W razie błędu nie zastępuj usuniętego folderu MINEVORA 17.4 — zachowaj go jako kopię.
