MINEVORA 9.8 — MARKETPLACE 3D (Windows / Minecraft Java)
===========================================================

NOWE FUNKCJE
- Nowe kategorie: Rigi Minecraft, Modele Blender, Modele Blockbench.
- Przyciski szybkiego dodawania tych typów w Marketplace.
- Filtr formatów, wyszukiwanie również po formacie pliku i tagach.
- Przesyłanie lokalnego pliku projektu i opcjonalnej miniatury.
- Szczegóły: wersja programu, licencja, obecność kości/riga, animacji i tekstur.
- Kopia pliku i miniatury trafia do %USERPROFILE%\.minevora\market_assets\<ID projektu>.
- Możliwość otwarcia folderu kopii projektu ze szczegółów oferty.
- Usunięcie własnej oferty usuwa tylko zarządzaną kopię, nie oryginał.
- XP twórcy (lokalne demo): rig 25, Blender 20, Blockbench 20 za unikalny projekt.

OBSŁUGIWANE FORMATY
- Rigi Minecraft: .bbmodel, .blend, .json, .fbx, .glb, .gltf, .zip
- Blender: .blend, .obj, .fbx, .glb, .gltf, .zip
- Blockbench: .bbmodel, .json, .obj, .glb, .gltf, .zip
- Miniatury: .png, .jpg, .jpeg, .webp
- Dla plików .gltf z teksturami zewnętrznymi zapakuj zasoby do .zip.
- Archiwa są sprawdzane i kopiowane, ale NIGDY automatycznie rozpakowywane.
- Plików .blend/.bbmodel launcher nie renderuje jako interaktywnego 3D; miniaturę dodajesz jako zdjęcie.
- Pliki z Marketplace nie są automatycznie uruchamiane ani importowane do Minecraft, Blender i Blockbench.

INSTALACJA
1. Rozpakuj ZIP do NOWEGO folderu (nie kasuj poprzedniej MINEVORA).
2. W razie potrzeby uruchom INSTALUJ_ZALEZNOSCI.bat.
3. Uruchom URUCHOM_MINEVORA.bat.
4. Marketplace -> wybierz jedną z trzech kategorii lub kliknij przycisk dodawania.
5. Wprowadź nazwę i autora, wybierz plik i opcjonalną miniaturę, zapisz.
6. Kliknij „Szczegóły”, by wyświetlić informacje o modelu i folderze.

ZACHOWANIE DANYCH
- Wszystkie projekty, zakupy testowe i XP: %USERPROFILE%\.minevora\market_demo.json.
- Nowe kopie plików: %USERPROFILE%\.minevora\market_assets.
- Pozostałe funkcje MINEVORA 9.7 pozostają zachowane.
- Zamknięcie/rozpakowanie innej wersji launchera nie usuwa tych danych.

OGRANICZENIA I BEZPIECZEŃSTWO
- Marketplace jest wciąż LOKALNYM DEMO. Nie wysyła projektów innym graczom.
- MVC to waluta testowa; ceny PLN są wyłącznie podglądem.
- Nie udostępniaj cudzych modeli bez licencji/uprawnień.
- Pliki mogą być niebezpieczne dla narzędzi, które je później otworzą;
  podstawowa kontrola formatu nie zastępuje skanowania antywirusowego.
- Nie testowano interfejsu na Windows w tym środowisku; sprawdzono składnię,
  testy automatyczne, reguły zapisu i strukturę archiwum.
