"""End-to-end tests for the local moderation bot HTTP API."""
import importlib.util
import json
import sqlite3
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('minevora_chat_server',BASE/'minevora_chat_server.py')
srv=importlib.util.module_from_spec(spec)
spec.loader.exec_module(srv)
from minevora_chat_guard import DEFAULT_RULES,validate_rules,check_text,check_history

class CoreTests(unittest.TestCase):
    def test_settings_validation(self):
        self.assertFalse(validate_rules({'enabled':False})['enabled'])
        for payload in ({'mute_minutes':0},{'caps_filter':1},{'blocked_phrases':'test'},{'unknown':5}):
            with self.assertRaises(ValueError):validate_rules(payload)
    def test_text_checks(self):
        rules=validate_rules({})
        self.assertEqual(check_text('AAAAAAAAAAAAAAAAAAAA',rules)[0],'caps')
        self.assertEqual(check_text('https://a.com https://b.net',rules)[0],'links')
        self.assertEqual(check_text('@Adam @Ewa @Kasia @Marek',rules)[0],'mentions')
        self.assertEqual(check_text('to jest dobry dzień',rules),None)
        self.assertEqual(check_text('nasz problem',validate_rules({'blocked_phrases':['problem']}))[0],'blocked_phrase')
        self.assertEqual(check_text('AAAAAAAAAAAAAAAAAAAA',validate_rules({'enabled':False})),None)
    def test_history_checks(self):
        cfg=validate_rules({})
        self.assertEqual(check_history('cześć',[('CZEŚĆ',1),('cześć',2)],cfg)[0],'repeat')
        self.assertEqual(check_history('nowe',[(str(i),i) for i in range(4)],cfg)[0],'flood')

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        srv.DB=Path(cls.tmp.name)/'chat.sqlite3';srv.TOKEN='only-for-tests'
        srv.RECENT.clear();srv.ACTIVE.clear();srv.RECENT_REPORT.clear()
        srv.initialize()
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),srv.Handler)
        cls.base=f'http://127.0.0.1:{cls.http.server_port}'
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown();cls.http.server_close();cls.tmp.cleanup()
    def api(self,path,data=None,admin=False):
        headers={'Content-Type':'application/json'}
        if admin:headers['Authorization']='Bearer only-for-tests'
        req=urllib.request.Request(self.base+path,
                json.dumps(data).encode('utf-8') if data is not None else None, headers,
                method='POST' if data is not None else 'GET')
        try:
            with urllib.request.urlopen(req,timeout=3) as response:
                return response.status,json.loads(response.read())
        except urllib.error.HTTPError as err:
            return err.code,json.loads(err.read())
    def send(self,name,body):
        srv.RECENT.clear() # Simulate elapsed 2-second global cooldown between separate requests.
        return self.api('/send',{'name':name,'country':'Polska','body':body})
    def test_01_auth_and_default(self):
        self.assertEqual(self.api('/admin/bot')[0],403)
        self.assertEqual(self.api('/admin/bot/settings',{'enabled':False})[0],403)
        code,data=self.api('/admin/bot',admin=True)
        self.assertEqual(code,200);self.assertTrue(data['rules']['enabled'])
        _,messages=self.api('/messages')
        self.assertTrue(any(m.get('kind')=='bot' for m in messages['messages']))
    def test_02_spam_warnings_mute_and_audit(self):
        for index in range(2):
            code,data=self.send('PlayerXYZ','AAAAAAAAAAAAAAAAAAAA')
            self.assertEqual(code,429);self.assertEqual(data['action'],'warning')
            self.assertEqual(data['strikes'],index+1)
        code,data=self.send('PlayerXYZ','AAAAAAAAAAAAAAAAAAAA')
        self.assertEqual(code,429);self.assertEqual(data['action'],'auto_mute_10m')
        self.assertEqual(self.send('PlayerXYZ','hej')[0],403)
        _,bot=self.api('/admin/bot',admin=True)
        self.assertEqual(len(bot['events']),3)
        self.assertTrue(any(x['rule']=='caps' for x in bot['events']))
        self.assertEqual(self.api('/admin/unmute',{'name':'PlayerXYZ'},admin=True)[0],200)
        self.assertEqual(self.api('/admin/bot/clear',{'name':'PlayerXYZ'},admin=True)[0],200)
        self.assertEqual(self.send('PlayerXYZ','zwykła wiadomość')[0],200)
    def test_03_repeat(self):
        self.assertEqual(self.send('RepeatGuy','hej witaj')[0],200)
        self.assertEqual(self.send('RepeatGuy','hej witaj')[0],200)
        code,data=self.send('RepeatGuy','HEJ  WITAJ')
        self.assertEqual(code,429);self.assertEqual(data['rule'],'repeat')
    def test_04_flood(self):
        for i in range(4):self.assertEqual(self.send('FloodGuy',f'wiadomość numer {i}')[0],200)
        code,data=self.send('FloodGuy','kolejna wiadomość')
        self.assertEqual(code,429);self.assertEqual(data['rule'],'flood')
    def test_05_commands_and_impersonation(self):
        self.assertEqual(self.send('MINEVORA BOT','hej')[0],400)
        self.assertEqual(self.send('NiceGuy','/zasady')[0],200)
        _,messages=self.api('/messages')
        self.assertEqual(messages['messages'][-1]['kind'],'bot')
        self.assertIn('Zasady czatu',messages['messages'][-1]['body'])
    def test_06_update_and_disable(self):
        self.assertEqual(self.api('/admin/bot/settings',{'enabled':False,'caps_filter':True},admin=True)[0],200)
        self.assertEqual(self.send('DisabledBotTest','AAAAAAAAAAAAAAAAAAAA')[0],200)
        _,public=self.api('/messages');self.assertFalse(public['bot_enabled'])
        self.assertEqual(self.api('/admin/bot/settings',{'enabled':True,'blocked_phrases':['zabroniona fraza']},admin=True)[0],200)
        code,data=self.send('PhraseGuy','tu zabroniona fraza')
        self.assertEqual(code,429);self.assertEqual(data['rule'],'blocked_phrase')
        self.assertEqual(self.api('/admin/bot/settings',{'blocked_phrases':[]},admin=True)[0],200)
    def test_07_persistence_and_migration(self):
        with sqlite3.connect(srv.DB) as con:
            self.assertEqual(con.execute('SELECT COUNT(*) FROM bot_settings').fetchone()[0],1)
            self.assertGreaterEqual(con.execute('SELECT COUNT(*) FROM mod_audit').fetchone()[0],2)
        srv.initialize(srv.DB)
        _,data=self.api('/admin/bot',admin=True)
        self.assertTrue(data['rules']['enabled'])
        self.assertGreaterEqual(len(data['events']),2)

if __name__=='__main__':unittest.main(verbosity=2)
