MINEVORA 10.2 — CHAT PLUS
========================

CO NOWEGO
- Karty wiadomości z flagami krajów i nickami Minecraft.
- Opcjonalne główki skinów Minecraft: mc-heads.net po HTTPS.
- Opcja „Zgłoś” przy każdej wiadomości.
- Panel moderatora z tokenem serwera (nie zapisuje się w pliku profilu).
- Usuwanie wiadomości, wyciszenie nicku na 10 min / 1 h / 24 h,
  ban/unban i lista zgłoszeń z oznaczaniem „rozpatrzone”.
- Wiadomości, raporty, blokady i dziennik decyzji w sqlite3.

INSTALACJA
1. Zamknij poprzedni launcher, rozpakuj ZIP do nowego folderu.
2. Uruchom INSTALUJ_ZALEZNOSCI.bat (przy pierwszym uruchomieniu).
3. Uruchom URUCHOM_SERWER_CZATU.bat — zachowaj otwarte okno konsoli.
4. Uruchom URUCHOM_MINEVORA.bat.
5. W czacie kliknij „Profil” i wybierz nick, flagę oraz serwer
   http://127.0.0.1:8766; opcjonalnie włącz pobieranie główek.
6. W konsoli serwera zobaczysz jednorazowy TOKEN MODERATORA na daną sesję.
   Kliknij w launcherze „Moderacja” i wklej token z konsoli.

WAŻNE OGRANICZENIA
- Serwer czatu startuje tylko lokalnie (127.0.0.1), więc osoby
  z innych komputerów nie zobaczą wiadomości bez hostingu.
- Nie publikuj lokalnego serwera wprost w internecie.
  Publiczne wdrożenie wymaga HTTPS, prawdziwego uwierzytelniania kont,
  limitów zapytań na reverse proxy i niezależnej ochrony moderacji.
- Nick nie jest zweryfikowany; blokada nicku jest prostą blokadą
  demonstracyjną — można ją ominąć zmianą nicku.
- Flaga jest deklarowana przez gracza, nie sprawdzana geolokalizacją.
- Pobieranie główek wysyła nick do usługi mc-heads.net. Opcja jest
  wyłączona domyślnie i można ją wyłączyć w każdym momencie.
- Token daje uprawnienia moderatora. Nie pokazuj go innym.
- Gdy MINEVORA_CHAT_ADMIN_TOKEN nie jest ustawiony, serwer generuje
  nowy token po każdym uruchomieniu. Dla stałego tokenu ustaw zmienną
  środowiskową w bezpiecznym miejscu (nie w publicznym ZIP/repo).
- Wszyscy użytkownicy czatu korzystają z jednego serwera; host czatu
  musi uruchomić minevora_chat_server.py. Stary serwer 7.7 nie obsługuje
  nowej moderacji — zastąp go tym plikiem.
- Gdy masz stary minevora_chat.sqlite3, przenieś go do folderu serwera;
  migracja zachowa wiadomości i raporty.

JAK WYGLĄDA PUBLIKACJA DLA SPOŁECZNOŚCI?
Do wspólnego globalnego czatu potrzebne są: stały serwer/VPS,
HTTPS, bezpieczne konta Minecraft oraz infrastruktura antyspamowa.
Nie umieszczaj tokenu moderatora w launcherze ani kodzie udostępnianym
użytkownikom.
