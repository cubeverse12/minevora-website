@echo off
cd /d "%~dp0"
py -3 -m unittest -v TESTY_MULTI_VERSION_PVP
pause
