"""Update the confirmed local user's leaderboard record from saved local state.

Never invent online statistics or claim other players were verified.
"""
from minevora_leaderboard_core import clean_nick, put_player, save_local
from minevora_rewards import ensure as ensure_creator


def local_player_entry(nick, market_data, pvp_data):
    nickname=clean_nick(nick)
    xp=ensure_creator(market_data)['xp']
    stats=pvp_data.get('stats',{}) if isinstance(pvp_data,dict) else {}
    return {'nick':nickname, 'xp':max(0,xp) if type(xp) is int else 0,
            **{key:max(0,stats.get(key,0)) if type(stats.get(key)) is int else 0
               for key in ('wins','losses','kills','deaths')}}


def sync_local(current, nick, market_data, pvp_data, path=None):
    # The nick must come from an authenticated launcher session; caller ensures this.
    row=local_player_entry(nick,market_data,pvp_data)
    updated=put_player(current,row)
    if updated==current:return current,False
    if path is None:return save_local(updated),True
    return save_local(updated,path),True
