"""Offline MINEVORA Guard JSONL import. Third-party log files are NOT independently authenticated."""
import json
from datetime import datetime
from pathlib import Path
from minevora_fairplay_core import MAX_PLAYERS, MAX_RECORDS, clean_name, clean_uuid, new_player

MAX_FILE_BYTES = 5_000_000
MAX_LINES = 10000
MAX_NEW_EVENTS = 1000
SOURCE = 'IMPORT JSONL — deklarowane przez serwer; brak niezależnego potwierdzenia'
CHECKS = {'SPEED', 'HOVER', 'REACH', 'FAST_SWING', 'FAST_PLACE'}


def import_guard_log(data, path):
    """Mutates a loaded Fair Play dict. Caller should save on success or discard on error."""
    path = Path(path)
    if path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError('Plik przekracza bezpieczny limit 5 MB.')
    known = {r.get('reference') for p in data['players'] for r in p.get('records', []) if r.get('source') == SOURCE}
    stats = {'imported': 0, 'duplicate': 0, 'ignored': 0, 'created_players': 0, 'full': 0}
    with path.open('r', encoding='utf-8-sig') as fh:
        for index, line in enumerate(fh):
            if index >= MAX_LINES:
                stats['ignored'] += 1
                break
            if not line.strip():
                continue
            try:
                item = json.loads(line)
                if not isinstance(item, dict) or item.get('schema') != 'minevora.guard.v1':
                    raise ValueError('schema')
                uid = clean_uuid(item.get('player_uuid'))
                nick = clean_name(item.get('player_name'))
                server = str(item.get('server') or '').strip()
                check = str(item.get('check') or '').strip().upper()
                event_id = str(item.get('event_id') or '').strip()
                timestamp = str(item.get('timestamp') or '')
                evidence = str(item.get('evidence') or '').strip()
                if not uid or not event_id or len(event_id) > 80 or len(server) > 100 or not server or check not in CHECKS:
                    raise ValueError('Invalid event')
                if len(evidence) > 400 or len(timestamp) > 40:
                    raise ValueError('Invalid size')
                datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            except (ValueError, TypeError, KeyError, json.JSONDecodeError):
                stats['ignored'] += 1
                continue
            if event_id in known:
                stats['duplicate'] += 1
                continue
            # Never merge two UUID identities solely because usernames happen to match.
            player = next((p for p in data['players'] if p['uuid'] and p['uuid'] == uid), None)
            if player is None:
                conflicting = next((p for p in data['players'] if p['name'].casefold() == nick.casefold()), None)
                if conflicting and conflicting['uuid'] and conflicting['uuid'] != uid:
                    stats['ignored'] += 1
                    continue
                if conflicting:
                    player = conflicting
                    player['uuid'] = uid
                else:
                    if len(data['players']) >= MAX_PLAYERS:
                        stats['full'] += 1
                        continue
                    player = new_player(data, nick, uid)
                    stats['created_players'] += 1
            if len(player['records']) >= MAX_RECORDS or stats['imported'] >= MAX_NEW_EVENTS:
                stats['full'] += 1
                continue
            player['records'].append({
                'id': __import__('uuid').uuid4().hex, 'kind': 'alert', 'server': server,
                'detail': ('[' + check + '] ' + evidence)[:500], 'status': 'do sprawdzenia',
                'account': '', 'reference': event_id, 'source': SOURCE,
                'created_at': timestamp[:40],
            })
            known.add(event_id)
            stats['imported'] += 1
    return stats
