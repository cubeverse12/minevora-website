MINEVORA 11.2 — OPTIMIZED EDITION
================================

INSTALACJA WINDOWS 11
1. Wyodrebnij caly plik ZIP do NOWEGO folderu. Nie nadpisuj starszej wersji.
2. Uruchom INSTALUJ_ZALEZNOSCI.bat (jesli biblioteki nie sa zainstalowane).
3. Uruchom URUCHOM_MINEVORA.bat.
4. Jezeli launcher nadal przycina, wybierz Ustawienia -> Plynnosc -> Oszczedne lub Wylaczone.
5. W razie bledu uruchom SPRAWDZ_LAUNCHER.bat i zachowaj komunikat.

ZMIANY:
- wyszukiwanie Marketplace odroczone o 210 ms; kafelki maks. 18 na strone z przyciskiem kolejne;
- obrazki ofert przechowywane w pamieci do 60 miniatur, szybsza transformacja obrazu;
- mniej niepotrzebnych timerow: PvP tylko gdy karta widoczna, HUD tylko podczas gry;
- przejscia alfa miedzy ekranami wylaczone domyslnie;
- dodatkowe pikselowe glowy na kafelkach i wyrazne podswietlenie po kliknieciu;
- funkcja WYCZYSC FILTRY, wyszukiwanie bez polskich znakow i slowa wielokrotne;
- Modrinth sortowanie, wersja i loader ponownie wyszukuja wyniki;
- lokalny ranking XP aktualizuje sie automatycznie przy zapisie progresu tworcy,
  po zalogowaniu Microsoft oraz zmianach zapisanych lokalnie statystyk PvP.

WAŻNE O RANKINGU
- Wlasny nick pobierany jest z zalogowanej sesji Microsoft, nie wpisywany recznie.
- XP dotyczy PROJEKTOW W MARKETPLACE, naliczanych lokalnie przez launcher.
- Dane PvP pochodza z lokalnego dziennika/treningu, NIE sa automatycznie
  odczytywane z Minecraft ani z zewnetrznych serwerow.
- Wyniki innych graczy NIE sa zsynchronizowane globalnie.
- Strona GitHub Pages wymaga nadal recznego eksportu ranking.json; nie ma
  publicznego backendu.
- Historyczne reczne wpisy pozostaja w lokalnym pliku danych i nie sa zweryfikowane.

PACZKI I AKTUALIZACJE MODOW
- Mody -> Sprawdz aktualizacje -> Utworz paczke, podaj wersje Minecraft i loader.
- Lokalizacja: %USERPROFILE%\.minevora\modpacks\NAZWA\mods
- Dodaj recznie swoje pliki .jar do folderu mods wybranej paczki.
- Sprawdz aktualizacje (Modrinth), zaznacz pliki i zatwierdz zmiany.
- Globalny folder .minecraft\mods NIE JEST automatycznie aktualizowany.
- Przed zamiana kazdego moda jest tworzona kopia zapasowa .jar.
- Paczka z tego edytora NIE jest jeszcze automatycznie powiazana z profilem gry.
  Wymaga osobnej konfiguracji instalacji/uruchamiania.

DANE I PRYWATNOSC
- MINEVORA nie usuwa folderu %USERPROFILE%\.minevora.
- Zalecane wykonanie kopii zapasowej danych przed instalacja.
- MVC w Marketplace pozostaje waluta demonstracyjna (brak platnosci).
- Hosting lokalny nie jest dodawany w tej wersji, zgodnie z decyzja uzytkownika.

TESTY
- TESTY_11_2.py: filtry, modpacki, lokalny ranking; 16 testow.
- Legacy testy: TESTY_RANKING.py, TESTY_BACKUP.py, TESTY_CZATU.py, TESTY_GUARD_BOT.py.
- Testy GUI na Windows 11 i prawdziwego klienta Minecraft musisz wykonac lokalnie;
  w srodowisku budowania nie bylo PySide6.
