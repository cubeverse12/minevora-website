MINEVORA 10.0 — ADS MANAGER (LOKALNY PROTOTYP)
================================================

NOWOŚCI
- Własne banery reklamowe dodawane w launcherze, aktywne od razu.
- Sponsorowane zgłoszenia reklamowe: stan OCZEKUJE do zatwierdzenia.
- Panel administratora: zatwierdź, odrzuć (z powodem), wstrzymaj,
  wznow, edytuj i usuń.
- Banery oznaczone jako REKLAMA / SPONSOROWANE i wstawione do:
  strony głównej, Marketplace i nowego panelu Serwery.
- Tytuł, opis, autor/reklamodawca, obraz PNG/JPG/WebP do 5 MB,
  link HTTPS, daty rozpoczęcia / zakończenia.
- Liczniki wyświetleń (maksymalnie jeden na reklamę/miejsce w sesji)
  i ręcznych kliknięć; bez profilowania i zewnętrznych analityk.
- Zachowane istniejące moduły: Marketplace 3D/Drag & Drop, PvP Arena,
  Fair Play, Guard plugin, Discord Hub, HUD, rangi, Modrinth.

JAK URUCHOMIĆ NA WINDOWS
1. Rozpakuj ZIP do nowego folderu.
2. Jeśli brakuje bibliotek, uruchom INSTALUJ_ZALEZNOSCI.bat.
   Zalecany Python 3.12/3.13 (zgodnie z dostępnością PySide6).
3. Uruchom URUCHOM_MINEVORA.bat.
4. W menu po lewej wybierz 'Reklamy / Ads'.
5. Wybierz '+ Własny baner' lub '+ Zgłoś sponsorowaną'.
6. Aby zatwierdzić sponsorowaną, otwórz
   'Panel administratora (lokalny)', zaznacz zgłoszenie i kliknij
   'Zatwierdź'. Baner pojawi się w wybranej zakładce zgodnie z datą.

DANE
Kampanie: %USERPROFILE%\.minevora\ads_local.json
Obrazy:   %USERPROFILE%\.minevora\ads_images\
Uwaga: są to dane lokalne, zapamiętywane na jednym komputerze.
Stare pliki projektów i ustawienia Marketplace nie są kasowane.

WAŻNE OGRANICZENIA
- NIE MA prawdziwych płatności, przyjmowania opłat ani publikacji
  kampanii przez internet.
- Panel administracyjny NIE ma bezpiecznej autoryzacji po stronie
  serwera. Osoba mająca dostęp do launchera i plików komputera może
  zarządzać lokalnymi kampaniami. Nie używaj tego jako publicznego
  systemu zatwierdzania reklam.
- Prawdziwy system reklam sponsorowanych wymaga backendu HTTPS,
  kont administracyjnych/rolowego dostępu, moderacji i ochrony
  prywatności. Uwzględnij zasady promocji skierowanej do nieletnich.
- Zewnętrzne linki otwierają się dopiero po kliknięciu użytkownika.
- Pozycje reklamowe są czytelnie oznaczone. Żadnych popupów w grze.
- Testy jednostkowe przechodzą; interfejs GUI nie był tu uruchomiony
  na Windows i wymaga przetestowania po rozpakowaniu.
