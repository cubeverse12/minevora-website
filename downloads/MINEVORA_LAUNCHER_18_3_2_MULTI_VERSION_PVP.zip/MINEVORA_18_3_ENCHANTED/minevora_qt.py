"""MINEVORA 11.7 — Creator Edition: pixel skin editor and presets."""
import os, sys, subprocess, json, urllib.request, urllib.error, time, copy, math
from pathlib import Path
from datetime import datetime, timezone
from uuid import uuid4
from PySide6.QtCore import Qt, QProcess, QThread, Signal, QTimer, QPointF, QUrl, QPropertyAnimation, QEasingCurve, QEvent, QSize
from PySide6.QtGui import QPainter, QColor, QPolygonF, QPen, QLinearGradient, QRadialGradient, QFont, QIcon, QPixmap, QDesktopServices
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QFrame,QVBoxLayout,QHBoxLayout,
 QLabel,QPushButton,QComboBox,QScrollArea,QGridLayout,QStackedWidget,QMessageBox,QSizePolicy,QInputDialog,QLineEdit,QDialog,QDialogButtonBox,QFormLayout,QListWidget,QProgressBar,QTextEdit,QSpinBox,QCheckBox,QFileDialog,QFormLayout,QTabWidget,QGraphicsOpacityEffect)
from minevora_engine import LoginWorker, PlayWorker, client_id, save_client_id, MC_DIR
from minevora_loader_core import filter_loader_versions
from minevora_dashboard import EnchantedDashboard
from minevora_icons import apply_clear_icons, icon_for_label
from minevora_enchanted_theme import ENCHANTED_QSS, EnchantedSectionBanner
from minevora_minigames_qt import MinigamesHub
from minevora_visuals import valid_motion_mode, animation_interval_ms, should_animate
from minevora_modrinth import ModrinthDialog
from minevora_together_qt import TogetherPage
from minevora_mod_updates_qt import ModUpdatesDialog
from minevora_auto_dependencies import detect_loader_and_version
from minevora_auto_dependencies_qt import AutoDependenciesWorker
from minevora_market_filters import find_offers, PAGE_SIZE
from minevora_auto_ranking import sync_local
from minevora_i18n import translate, translate_widget_tree
from minevora_skin3d_qt import SkinDialog
from minevora_profiles import load as load_profiles, create as create_profile
import minecraft_launcher_lib
from minevora_rank_animation import RankUpDialog
from minevora_pvp import PvpHub
from minevora_pvp_modmenu_qt import PvPModMenu
from minevora_pvp_auto import provision as provision_pvp_hud, read_auto_enabled as auto_pvp_enabled
from minevora_oneclick_core import install_selected, LOADERS
from minevora_leaderboard_qt import LeaderboardPage
from minevora_fairplay import FairPlayPanel
from minevora_discord import DiscordHub
from minevora_discord_core import valid_application_id, normalize_invite, presence_payload, should_publish, OFFICIAL_MINEVORA_DISCORD_INVITE
from minevora_assets import (MODEL_CATEGORIES, ASSET_SUFFIXES, accepted_suffixes, validate_asset, store_project_asset, remove_project_asset)
from minevora_dropzone import AssetDropZone
from minevora_chat_plus import ChatPlus
from minevora_ads import AdsHub, ad_widget
from minevora_ads_core import load_data as load_ads, save_data as save_ads, ads_for_slot, record_event, validate_url
from minevora_ai_qt import MinevoraAIPanel
from minevora_easy_core import FEATURES, CATEGORY_NAMES, filter_features, navigation_group, version_sort_key, sanitize_preferences
from minevora_overlay_core import display_rows
from minevora_rewards import (RANKS, DAILY_MVC, WEEKLY_MVC, XP_BY_CATEGORY, ensure as ensure_progress,
    level_floor, level_of, rank_of, migrate_projects, award_project, can_claim_daily,
    claim_daily, pending_level_rewards, claim_levels, claim_weekly, can_claim_weekly,
    activate_boost, boost_remaining)
BASE=Path(__file__).resolve().parent
MARKET_PATH=Path.home()/'.minevora'/'market_demo.json'
PREFS_PATH=Path.home()/'.minevora'/'preferences.json'
CATEGORY_ICONS={'Mapy':'🗺','Budowle':'🏰','Pluginy':'⚙','Mody':'✨','Modpacki':'📦','Tekstury':'🎨','Schematy':'📐','Rigi Minecraft':'🦴','Modele Blender':'🧊','Modele Blockbench':'🪄'}
ICON_OPTIONS=['🗺','🏰','⚙','✨','📦','🎨','📐','🌲','💎','🧱','🏯','🔮','🦴','🧊','🪄']

def read_prefs():
 try:
  data=json.loads(PREFS_PATH.read_text(encoding='utf-8'))
  return sanitize_preferences(data)
 except (OSError,ValueError):return {}

MARKET_DEFAULT=[{'id':'sample_castle','title':'Zamek Fantasy','category':'Budowle','description':'Przykładowa budowla do testowania zakupów.','price':150,'author':'MINEVORA Demo','url':''},{'id':'sample_map','title':'Mapa przygodowa','category':'Mapy','description':'Darmowa przykładowa oferta.','price':0,'author':'MINEVORA Demo','url':''},{'id':'sample_plugin','title':'Plugin Economy','category':'Pluginy','description':'Przykładowy plugin demonstracyjny.','price':250,'author':'MINEVORA Demo','url':''}]

class InstallWorker(QThread):
 status=Signal(str)
 error=Signal(str)
 done=Signal(str)
 def __init__(self, version):
  super().__init__();self.version=version
 def run(self):
  try:
   MC_DIR.mkdir(parents=True, exist_ok=True)
   self.status.emit('Instalowanie Minecraft '+self.version+'…')
   minecraft_launcher_lib.install.install_minecraft_version(self.version,str(MC_DIR))
   self.done.emit(self.version)
  except Exception as exc:self.error.emit(str(exc))

class ModLoaderCatalogWorker(QThread):
 """Obtain the loader-specific Minecraft version catalog without freezing Qt."""
 done=Signal(object,object)
 error=Signal(str)
 def __init__(self,loader_id):
  super().__init__();self.loader_id=loader_id
 def run(self):
  try:
   loader=minecraft_launcher_lib.mod_loader.get_mod_loader(self.loader_id)
   all_versions=loader.get_minecraft_versions(False)
   stable_versions=loader.get_minecraft_versions(True)
   self.done.emit(all_versions,stable_versions)
  except Exception as exc:self.error.emit(str(exc))

class ModLoaderInstallWorker(QThread):
 """Install only Minecraft/loader combinations verified by the loader API."""
 status=Signal(str)
 error=Signal(str)
 done=Signal(str)
 def __init__(self,loader_id,minecraft_version):
  super().__init__();self.loader_id=loader_id;self.minecraft_version=minecraft_version
 def run(self):
  try:
   MC_DIR.mkdir(parents=True,exist_ok=True)
   loader=minecraft_launcher_lib.mod_loader.get_mod_loader(self.loader_id)
   if not loader.is_minecraft_version_supported(self.minecraft_version):
    raise ValueError(f'{self.loader_id.title()} nie obsługuje Minecraft {self.minecraft_version}. Wybierz wersję z katalogu.')
   self.status.emit('Instalowanie '+self.loader_id.title()+' dla Minecraft '+self.minecraft_version+'…')
   # minecraft-launcher-lib >=8 installs missing vanilla dependencies automatically.
   installed_id=loader.install(self.minecraft_version,str(MC_DIR))
   if not isinstance(installed_id,str) or not installed_id.strip():
    raise RuntimeError('Instalator nie zwrócił identyfikatora wersji.')
   installed_id=installed_id.strip()
   if '/' in installed_id or chr(92) in installed_id or installed_id in ('.','..'):
    raise RuntimeError('Nieprawidłowy identyfikator zainstalowanej wersji.')
   json_path=MC_DIR/'versions'/installed_id/(installed_id+'.json')
   if not json_path.is_file():
    raise RuntimeError('Nie znaleziono pliku instalacji: '+str(json_path))
   self.done.emit(installed_id)
  except Exception as exc:self.error.emit(str(exc))

class AllLoadersForVersionWorker(QThread):
 """Install each compatible loader for a chosen game version; no external installers."""
 progress=Signal(str)
 done=Signal(object)
 def __init__(self,version):
  super().__init__();self.version=version
 def run(self):
  results=[]
  MC_DIR.mkdir(parents=True,exist_ok=True)
  for name in ('fabric','forge','neoforge','quilt'):
   try:
    loader=minecraft_launcher_lib.mod_loader.get_mod_loader(name)
    if not loader.is_minecraft_version_supported(self.version):
     results.append((name,'pominięto: nieobsługiwana wersja'));continue
    self.progress.emit(f'Instalowanie {name} dla {self.version}…')
    installed=loader.install(self.version,str(MC_DIR))
    if not isinstance(installed,str) or not installed.strip():raise RuntimeError('brak identyfikatora wersji')
    installed=installed.strip()
    if '/' in installed or chr(92) in installed or installed in ('.','..'):
     raise RuntimeError('nieprawidłowy identyfikator wersji')
    check=MC_DIR/'versions'/installed/(installed+'.json')
    if not check.is_file():raise RuntimeError('brak pliku instalacji')
    results.append((name,'OK: '+installed))
   except Exception as exc:
    results.append((name,'błąd: '+str(exc)))
  self.done.emit(results)

class OneClickInstallWorker(QThread):
 """Install one requested release/loader in a worker thread before launching."""
 progress=Signal(str)
 done=Signal(str, bool)
 error=Signal(str)
 def __init__(self, loader_id, minecraft_version):
  super().__init__();self.loader_id=loader_id;self.minecraft_version=minecraft_version
 def run(self):
  try:
   version,downloaded=install_selected(minecraft_launcher_lib,MC_DIR,
     self.loader_id,self.minecraft_version,notify=self.progress.emit)
   self.done.emit(version,downloaded)
  except Exception as exc:self.error.emit(str(exc))

class VersionsWorker(QThread):
 done=Signal(object)
 error=Signal(str)
 def run(self):
  try:
   versions=minecraft_launcher_lib.utils.get_version_list()
   self.done.emit([(x['id'],x.get('type','release')) for x in versions if x.get('type') in ('release','snapshot')])
  except Exception as exc:self.error.emit(str(exc))

COLORS={'bg':'#0a0f1d','side':'#10182e','panel':'#17253d','border':'#5f5ed6','blue':'#8c7cff','muted':'#b8c3e0'}
CSS="""
QWidget {background:#09101d;color:#f7f8ff;font-family:'Segoe UI';font-size:13px}
QFrame#sidebar {background:#0e1628;border-right:1px solid #223454}
QFrame#topbar {background:#101a2e;border-bottom:1px solid #233651}
QFrame#chatSidebar {background:#0f1830;border-left:2px solid #5a6de0}
QFrame#footer {background:#10192f;border-top:1px solid #2a4070}
QFrame#card {background:#141f34;border:1px solid #2a3d63;border-radius:18px}
QFrame#card:hover {background:#1a2740;border:1px solid #6a7dff}
QFrame#hero {background:#10162c;border:1px solid #405a94;border-radius:30px}
QFrame#stats {background:#16223a;border:1px solid #334b79;border-radius:22px}
QFrame#panel {background:#121c32;border:1px solid #2a3d63;border-radius:18px}
QLabel#eyebrow {color:#91a8ff;font-size:11px;font-weight:800;letter-spacing:2px}
QLabel#pageTitle {font-size:31px;font-weight:800;color:#ffffff}
QPushButton {background:#1b2a46;border:1px solid #34517d;border-radius:13px;padding:12px 17px;font-weight:700;color:#f7f9ff}
QPushButton:hover {background:#23365a;border:1px solid #88a3ff}
QPushButton:pressed {background:#16243a;padding-top:13px;padding-bottom:11px}
QPushButton:focus {border:2px solid #aebeff}
QPushButton[clicked="true"] {background:#536dff;border:2px solid #dbe1ff;color:#ffffff}
QPushButton#nav[clicked="true"] {background:#223766;border-left:4px solid #dbe1ff}
QPushButton#primary {background:#6b63ff;border:1px solid #c5c8ff;color:#fff;font-size:15px;padding:15px 22px}
QPushButton#primary:hover {background:#8d88ff;border:1px solid #ebedff}
QPushButton#discordJoin {background:#5865f2;color:white;border:1px solid #b8c1ff;border-radius:12px;padding:12px 8px;font-size:12px;font-weight:800}
QPushButton#discordJoin:hover {background:#7289ff;border-color:#d4daff}
QPushButton#discordJoin:pressed {background:#4452cb}
QPushButton#nav {background:transparent;border:0;border-left:4px solid transparent;text-align:left;padding:15px 14px;color:#bdcae5;border-radius:10px}
QPushButton#nav:hover {background:#192846;color:#fff}
QPushButton#nav[active="true"] {background:#1f3158;border-left:4px solid #aebeff;color:#fff}
QComboBox,QLineEdit,QTextEdit,QListWidget {background:#0f1830;color:#f8f9ff;border:1px solid #31476f;border-radius:12px;padding:11px;selection-background-color:#5a6de0}
QLineEdit:focus,QTextEdit:focus {border:1px solid #b8c3ff}
QTextEdit#chatfeed {background:#0c1427;border:1px solid #31476f;border-radius:16px;padding:9px}
QPushButton:disabled {color:#95a0b8;background:#162137;border:1px solid #29384d}
QToolTip {background:#1a2238;color:#ffffff;border:1px solid #7e92d9;padding:6px}
QTabWidget::pane {border:1px solid #31476f;border-radius:12px;background:#10192f}
QTabBar::tab {background:#16233b;color:#dce3ff;padding:10px 15px;margin:2px;border-radius:8px}
QTabBar::tab:selected {background:#4c64e8;color:#ffffff}
QProgressBar {background:#0f1730;border:1px solid #31476f;border-radius:9px;text-align:center;color:white}
QProgressBar::chunk {background:#6b63ff;border-radius:8px}
QScrollArea {border:0;background:transparent}
QScrollBar:vertical {background:#0e1628;width:10px}
QScrollBar::handle:vertical {background:#5167c5;border-radius:5px;min-height:25px}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {height:0}
"""

def text(t,size=12,bold=False,muted=False):
 x=QLabel(t);x.setWordWrap(True);x.setStyleSheet(f'font-size:{size}px;font-weight:{700 if bold else 400};color:{"#aebcda" if muted else "#fbf5ff"};background:transparent');return x

def btn(t,fn,primary=False):
 b=QPushButton(t);b.setObjectName('primary' if primary else 'normal');b.setCursor(Qt.PointingHandCursor)
 b.setAccessibleName(t)
 def feedback():
  b.setProperty('clicked',True);b.style().unpolish(b);b.style().polish(b)
  QTimer.singleShot(220,lambda:clear_feedback(b))
 b.clicked.connect(feedback)
 b.clicked.connect(fn)
 return b

def clear_feedback(button):
 try:
  button.setProperty('clicked',False);button.style().unpolish(button);button.style().polish(button)
 except RuntimeError:pass

def card(title,description,fn,action='OTWÓRZ',symbol='✧',head_index=None):
 f=QFrame();f.setObjectName('card');v=QVBoxLayout(f);v.setContentsMargins(20,18,20,18);v.setSpacing(9)
 badge=QLabel(symbol);badge.setFixedSize(43,43);badge.setAlignment(Qt.AlignCenter)
 badge.setStyleSheet('background:#45376d;border:1px solid #876bbd;border-radius:13px;color:#f2d7ff;font-size:23px')
 avatar=BASE/'tile_heads'/('head_'+str((head_index if head_index is not None else sum(map(ord,title)))%9)+'.png')
 if avatar.is_file():
  badge.setPixmap(QPixmap(str(avatar)).scaled(41,41,Qt.KeepAspectRatio,Qt.FastTransformation))
 v.addWidget(badge);v.addWidget(text(title,17,True));v.addWidget(text(description,11,muted=True));v.addStretch()
 b=btn(action+'   ↗',fn);b.setMinimumHeight(38);v.addWidget(b);f.setMinimumHeight(207);return f

class LandscapeHero(QFrame):
 """A cached painted fantasy background with lightweight animated portal and stars.

 The static mountains/forest are painted once per size change. The animation
 clock is suspended whenever the widget is hidden or the window is minimized.
 """
 def __init__(self):
  super().__init__();self.setObjectName('hero')
  self.mode='smooth';self.animations_enabled=True;self._cached_backdrop=None;self._cache_size=None
  self._epoch=time.monotonic();self.timer=QTimer(self)
  self.timer.setTimerType(Qt.CoarseTimer)
  self.timer.timeout.connect(self.animate)
  self.refresh_animation_state()

 def set_motion_mode(self,mode,enabled=True):
  self.mode=valid_motion_mode(mode)
  self.animations_enabled=bool(enabled)
  self.refresh_animation_state()
  self.update()

 def refresh_animation_state(self):
  window=self.window()
  minimized=bool(window.isMinimized()) if window else False
  active=should_animate(self.animations_enabled,self.isVisible(),minimized,self.mode)
  if active:
   interval=animation_interval_ms(self.mode)
   if self.timer.interval()!=interval:self.timer.setInterval(interval)
   if not self.timer.isActive():self.timer.start()
  elif self.timer.isActive():self.timer.stop()

 def animate(self):
  if not self.isVisible() or self.window().isMinimized():
   self.timer.stop();return
  self.update()

 def showEvent(self,event):
  super().showEvent(event)
  self.refresh_animation_state()

 def hideEvent(self,event):
  self.timer.stop()
  super().hideEvent(event)

 def resizeEvent(self,event):
  self._cached_backdrop=None;self._cache_size=None
  super().resizeEvent(event)

 def _build_backdrop(self,w,h):
  pixmap=QPixmap(w,h);pixmap.fill(QColor('#110d2b'))
  p=QPainter(pixmap);p.setRenderHint(QPainter.Antialiasing)
  sky=QLinearGradient(0,0,w,h)
  sky.setColorAt(0,QColor('#110d2b'));sky.setColorAt(.45,QColor('#30245b'));sky.setColorAt(1,QColor('#795b91'))
  p.fillRect(0,0,w,h,sky);p.setPen(Qt.NoPen)
  def poly(coords,color):
   p.setBrush(QColor(color));p.drawPolygon(QPolygonF([QPointF(x,y) for x,y in coords]))
  poly([(0,h*.83),(w*.16,h*.25),(w*.36,h*.85)],'#443b79')
  poly([(w*.19,h*.86),(w*.42,h*.12),(w*.64,h*.86)],'#5c4a8d')
  poly([(w*.35,h*.86),(w*.68,h*.22),(w*.97,h*.86)],'#342e69')
  poly([(w*.36,h*.31),(w*.42,h*.12),(w*.48,h*.34),(w*.43,h*.29),(w*.41,h*.36)],'#a99dcf')
  poly([(0,h*.79),(w*.15,h*.69),(w*.35,h*.83),(w*.61,h*.67),(w,h*.83),(w,h),(0,h)],'#1b2346')
  for i in range(14):
   x=w*(i/13);y=h*(.78+(i%3)*.05)
   p.setBrush(QColor('#101d2f'));p.drawRect(int(x-3),int(y-5),7,int(h-y+10))
   poly([(x-20,y),(x,y-70-(i%4)*10),(x+20,y)],'#182f40')
   poly([(x-15,y-22),(x,y-84-(i%4)*10),(x+15,y-22)],'#244355')
  overlay=QLinearGradient(0,0,w*.74,0)
  overlay.setColorAt(0,QColor(9,8,26,225));overlay.setColorAt(.72,QColor(15,11,35,125));overlay.setColorAt(1,QColor(15,11,35,0))
  p.fillRect(0,0,w,h,overlay)
  p.end();self._cached_backdrop=pixmap;self._cache_size=(w,h)

 def paintEvent(self,event):
  super().paintEvent(event)
  w,h=self.width(),self.height()
  if w<2 or h<2:return
  if self._cached_backdrop is None or self._cache_size!=(w,h):self._build_backdrop(w,h)
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
  p.setClipRect(self.rect().adjusted(2,2,-2,-2))
  p.drawPixmap(0,0,self._cached_backdrop)
  # Pause time evolution without removing the portal graphic.
  phase=(time.monotonic()-self._epoch) if self.animations_enabled and self.mode!='off' else 0.0
  cx,cy=w*.73,h*.53
  pulse=1+.025*math.sin(phase*2.4)
  halo=QRadialGradient(QPointF(cx,cy),h*.51)
  halo.setColorAt(0,QColor(165,105,255,155));halo.setColorAt(.48,QColor(92,54,181,55));halo.setColorAt(1,QColor(60,20,110,0))
  p.setPen(Qt.NoPen);p.setBrush(halo);p.drawEllipse(QPointF(cx,cy),h*.51,h*.51)
  p.setBrush(QColor('#26223e'));p.setPen(QPen(QColor('#9e86c7'),8))
  p.drawEllipse(QPointF(cx,cy),h*.25,h*.38)
  p.setPen(QPen(QColor('#ddbdff'),4));p.setBrush(QColor('#6945c9'))
  p.drawEllipse(QPointF(cx,cy),h*.205,h*.335)
  inner=QRadialGradient(QPointF(cx-h*.06,cy-h*.08),h*.38)
  inner.setColorAt(0,QColor('#a9e5ff'));inner.setColorAt(.34,QColor('#946aff'));inner.setColorAt(.75,QColor('#4e2b9e'));inner.setColorAt(1,QColor('#261b64'))
  p.setPen(Qt.NoPen);p.setBrush(inner);p.drawEllipse(QPointF(cx,cy),h*.192*pulse,h*.322*pulse)
  # Fewer glowing particles in economy mode.
  count=15 if self.mode=='eco' else 30
  for i in range(count):
   x=(i*139.7+math.sin(phase*.7+i)*15)%(w+30)
   y=(i*59.3-phase*(5+i%4))%(h+30)
   alpha=int(95+95*(.5+.5*math.sin(phase*2+i)))
   p.setBrush(QColor(222,188,255,alpha))
   radius=1.2+(i%3)*.65
   p.drawEllipse(QPointF(x,y),radius,radius)
  p.end()

CHAT_CONFIG=Path.home()/'.minevora'/'chat_settings.json'
FLAGS={'Polska':'🇵🇱','Niemcy':'🇩🇪','Wielka Brytania':'🇬🇧','USA':'🇺🇸','Ukraina':'🇺🇦','Francja':'🇫🇷','Hiszpania':'🇪🇸','Inny':'🌍'}

class ChatRequest(QThread):
  result=Signal(object)
  failed=Signal(str)
  def __init__(self,url,method='GET',data=None):
   super().__init__();self.url=url;self.method=method;self.data=data
  def run(self):
   try:
    payload=json.dumps(self.data).encode('utf-8') if self.data is not None else None
    req=urllib.request.Request(self.url,data=payload,method=self.method,headers={'Content-Type':'application/json','User-Agent':'MINEVORA-7.9'})
    with urllib.request.urlopen(req,timeout=5) as r:self.result.emit(json.loads(r.read(200000).decode('utf-8')))
   except Exception as exc:self.failed.emit(str(exc))

class Window(QMainWindow):
 def __init__(self):
  super().__init__();self.setWindowTitle('MINEVORA 18.3 • ENCHANTED LAUNCHER');self.resize(1536,900);self.setMinimumSize(1050,680);self.setWindowIcon(QIcon(str(BASE/'minevora_logo.png')))
  self.prefs=read_prefs();self.language=self.prefs.get('language','pl');self.ads_data=load_ads();self.ads_seen=set();self.ad_holders={};self.setStyleSheet(ENCHANTED_QSS);self.processes=[];self.session=None;self.login_worker=None;self.play_worker=None;self.current_version=None;self.install_worker=None;self.versions_worker=None;self.active_profile=None;self.deps_worker=None;self.pending_launch=None;self.oneclick_worker=None;self.oneclick_pending=False
  main=QWidget();self.setCentralWidget(main);layout=QHBoxLayout(main);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
  side=QFrame();side.setObjectName('sidebar');side.setFixedWidth(242);sv=QVBoxLayout(side);sv.setContentsMargins(12,20,12,14);sv.setSpacing(5)
  logo_row=QHBoxLayout();logo_icon=QLabel();logo_icon.setPixmap(QIcon(str(BASE/'minevora_logo.png')).pixmap(52,52));logo_row.addWidget(logo_icon);logo=QLabel('MINEVORA');logo.setStyleSheet('color:#fff;font-size:23px;font-weight:900;background:transparent');logo_row.addWidget(logo);logo_row.addStretch();sv.addLayout(logo_row)
  sv.addWidget(text('ENCHANTED  •  18.3',10,muted=True))
  sv.addSpacing(13)
  banner=QFrame();banner.setObjectName('panel');bv=QVBoxLayout(banner);bv.setContentsMargins(13,15,13,15)
  bv.addWidget(text('✦  THE ENCHANTED REALM',12,True))
  bv.addWidget(text('Otwórz portal do swojej przygody.',11,muted=True))
  sv.addWidget(banner);sv.addSpacing(8)
  self.nav=[]
  nav_wrap=QWidget()
  nav_wrap.setStyleSheet('background:transparent')
  nav_layout=QVBoxLayout(nav_wrap)
  nav_layout.setContentsMargins(0,0,0,0)
  nav_layout.setSpacing(3)
  # Eight clearly named destinations replace nineteen always-visible buttons.
  primary_navigation=[('⌂  Start',self.home),('▶  Graj / Wersje',self.instances),
      ('◈  Mody i dodatki',self.mods),('♟  Skiny 3D',self.skins),('▣  Marketplace',self.market),('🎮  Minigry',self.minigames),
      ('⚔  PvP',self.pvp),('⚔  PvP Mod Menu',self.pvp_mod_menu),('🏆  Ranking',self.leaderboard),('◉  Discord',self.discord_page),
      ('✦  Wszystkie funkcje',self.features_page),('⚙  Ustawienia',self.settings),
      ('♡  Together',self.together),('✦  Co nowego',self.release_notes),('?  Pomoc',self.help_page)]
  for name,fn in primary_navigation:
   b=btn(name,fn);b.setObjectName('nav');b.setToolTip(name);nav_layout.addWidget(b);self.nav.append(b)
  nav_layout.addStretch()
  nav_scroll=QScrollArea()
  nav_scroll.setWidgetResizable(True)
  nav_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  nav_scroll.setWidget(nav_wrap)
  sv.addWidget(nav_scroll,1)
  self.discord_invite_button=btn('💬  DOŁĄCZ NA DISCORD',self.open_minevora_discord)
  self.discord_invite_button.setObjectName('discordJoin')
  self.discord_invite_button.setToolTip('Oficjalny serwer Discord MINEVORA: '+OFFICIAL_MINEVORA_DISCORD_INVITE)
  sv.addWidget(self.discord_invite_button)
  sv.addSpacing(7)
  sv.addWidget(text('✧  KONTO GRACZA',11,True))
  self.account_button=btn('◉  Zaloguj Microsoft',self.login);sv.addWidget(self.account_button)
  sv.addWidget(text('MINEVORA 18.3 • Java Edition',10,muted=True))
  layout.addWidget(side)
  right=QWidget();rv=QVBoxLayout(right);rv.setContentsMargins(0,0,0,0);rv.setSpacing(0)
  top=QFrame();top.setObjectName('topbar');top.setFixedHeight(82);th=QHBoxLayout(top);th.setContentsMargins(26,10,26,10);head=QVBoxLayout();head.setSpacing(2);head.addWidget(text('✦  THE ENCHANTED LAUNCHER',10,True,True));head.addWidget(text('Witaj w MINEVORA',20,True));th.addLayout(head);th.addStretch();th.addWidget(btn('↻',self.refresh))
  self.quick_search=QLineEdit();self.quick_search.setPlaceholderText('⌕ Znajdź funkcję… (Ctrl+K)');self.quick_search.setMaximumWidth(245)
  th.addWidget(self.quick_search)
  self.fairplay_shortcut=btn('🛡 Profil gracza',self.fairplay)
  self.fairplay_shortcut.setToolTip('Otwórz profile graczy i kolejkę raportów Guard')
  th.addWidget(self.fairplay_shortcut)
  self.chat_toggle_button=btn('☏ Pokaż czat',self.toggle_chat);th.addWidget(self.chat_toggle_button)
  self.language_quick=QComboBox();self.language_quick.addItem('🇵🇱 PL','pl');self.language_quick.addItem('🇬🇧 EN','en');self.language_quick.setCurrentIndex(1 if self.language=='en' else 0);self.language_quick.currentIndexChanged.connect(self.quick_language_change);th.addWidget(self.language_quick);rv.addWidget(top)
  self.enchanted_banner=EnchantedSectionBanner()
  rv.addWidget(self.enchanted_banner)
  self.enchanted_banner.hide()
  self.pages=QStackedWidget();rv.addWidget(self.pages,1)
  self.homepage=QWidget();hv=QVBoxLayout(self.homepage);hv.setContentsMargins(26,12,26,12);hv.setSpacing(18)
  hero=LandscapeHero();self.hero=hero;hero.setMinimumHeight(240);hero.setMaximumHeight(290);hh=QVBoxLayout(hero);hh.setContentsMargins(38,38,38,34)
  hh.addWidget(text('✧  TWOJA PRZYGODA ZACZYNA SIĘ TUTAJ',12,True))
  hh.addSpacing(8);hh.addWidget(text('MINECRAFT JEDNYM KLIKNIĘCIEM',30,True))
  hh.addWidget(text('Wybierz wersję, zaloguj konto Microsoft i graj.',14))
  hh.addStretch()
  line=QHBoxLayout();line.addWidget(btn('▶  GRAJ W MINECRAFT',self.play,True));line.addWidget(btn('✦  ONE CLICK',self.oneclick_play));line.addWidget(btn('＋  Instaluj wersję',self.install_version));line.addWidget(btn('🎨  UŻYJ SKINA',self.skins));line.addStretch();hh.addLayout(line);hv.addWidget(hero)
  self.ad_holders['home']=self.make_ad_holder();hv.addWidget(self.ad_holders['home'])
  status=QFrame();status.setObjectName('panel');st=QVBoxLayout(status);st.setSpacing(8)
  st.addWidget(text('3 KROKI DO GRY',16,True))
  self.home_account=text('1. Konto: sprawdzanie…',12)
  self.home_version=text('2. Wersja Minecraft: sprawdzanie…',12)
  self.home_ready=text('3. Gotowość: sprawdzanie…',12)
  for element in (self.home_account,self.home_version,self.home_ready):st.addWidget(element)
  steps=QHBoxLayout();steps.addWidget(btn('1  Zaloguj',self.login));steps.addWidget(btn('2  Instaluj Minecraft',self.install_version));steps.addWidget(btn('3  Graj',self.play,True));st.addLayout(steps);hv.addWidget(status)
  hv.addWidget(text('NAJCZĘŚCIEJ UŻYWANE',19,True))
  shortcuts=QGridLayout();shortcuts.setSpacing(10)
  for i,(name,description,fn) in enumerate([
    ('♡ MINEVORA Together','Zapraszaj znajomych do gry',self.together),
    ('◈ Mody','Modrinth i aktualizacje',self.mods),
    ('▣ Marketplace','Mapy, rigi i modele',self.market),
    ('🏆 Moje rangi','Poziomy i bonusy XP',self.creator_page),
    ('⚔ PvP Arena','Serwery i trening',self.pvp),
    ('🏆 Ranking graczy','Twórcy XP i PvP',self.leaderboard),
    ('✧ Pomoc AI','Porady i rozwiązywanie błędów',self.ai_page),
    ('🛡 Fair Play','Profile i alerty Guard',self.fairplay),
    ('💾 Kopia danych','Backup przed zmianą komputera',self.open_backup_tool),
    ('✦ Pozostałe','Znajdź dowolną funkcję',self.features_page)]):
   shortcuts.addWidget(card(name,description,fn,action='OTWÓRZ',symbol='✦',head_index=i),i//3,i%3)
  hv.addLayout(shortcuts)
  hv.addWidget(btn('Wszystkie funkcje MINEVORA →',self.features_page))
  hv.addStretch();scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.homepage);self.pages.addWidget(scroll)
  ip=QWidget();iv=QVBoxLayout(ip);iv.setContentsMargins(26,20,26,20);iv.addWidget(text('▣  BIBLIOTEKA ŚWIATÓW',27,True));iv.addWidget(text('Wybierz zainstalowaną wersję. Uruchomisz ją przyciskiem GRAJ.',12,muted=True))
  actions=QHBoxLayout();actions.addWidget(btn('✦ JEDEN KLIK • GRAJ',self.oneclick_play,True));actions.addWidget(btn('＋ Instaluj wersję Minecraft',self.install_version,True));actions.addWidget(btn('⚙ Instaluj Fabric / Forge / NeoForge / Quilt',self.install_mod_loader));actions.addWidget(btn('＋ Utwórz profil',self.add_profile));iv.addLayout(actions)
  iv.addWidget(btn('✦ Zainstaluj wszystkie obsługiwane loadery dla wybranej wersji',self.install_all_loaders_for_version))
  iv.addWidget(text('✧  TWOJE WERSJE I PROFILE',16,True))
  self.install_scroll=QScrollArea();self.install_scroll.setWidgetResizable(True)
  install_content=QWidget();self.instance_list=QVBoxLayout(install_content);self.instance_list.setSpacing(10)
  self.install_scroll.setWidget(install_content);iv.addWidget(self.install_scroll,1);self.pages.addWidget(ip)
  foot=QFrame();foot.setObjectName('footer');foot.setMinimumHeight(75);fl=QHBoxLayout(foot);fl.setContentsMargins(26,14,26,14)
  info=QVBoxLayout();info.addWidget(text('✦  AKTYWNA INSTANCJA',11,True,True));self.selected=text('Wczytywanie...',16,True);info.addWidget(self.selected);fl.addLayout(info);fl.addStretch()
  fl.addWidget(text('RAM',12,True));self.ram=QComboBox();self.ram.addItems(['2 GB','4 GB','6 GB','8 GB','12 GB','16 GB']);self.ram.setCurrentText('4 GB');self.ram.setToolTip('Ilość RAM przekazywana do JVM przy uruchomieniu gry.');fl.addWidget(self.ram)
  fl.addWidget(btn('▶  WEJDŹ DO GRY',self.play,True));rv.addWidget(foot);layout.addWidget(right,1)
  self.chat_panel=QFrame();self.chat_panel.setObjectName('chatSidebar');self.chat_panel.setFixedWidth(310);layout.addWidget(self.chat_panel)
  self.setup_chat();self.setup_stats();self.setup_market();self.setup_creator_page()
  self.set_chat_visible(bool(self.prefs.get('chat_visible',True)),save=False)
  self.pvp_hub=PvpHub(launch_game=self.play,open_instances=self.instances,get_version=lambda:self.current_version,parent=self)
  self.pages.addWidget(self.pvp_hub)
  self.pvp_mod_panel=PvPModMenu(self,get_game_dir=lambda:(self.active_profile.get('game_dir') if isinstance(self.active_profile,dict) else None) or str(MC_DIR),get_version=lambda:self.current_version,is_running=self.game_active)
  self.pages.addWidget(self.pvp_mod_panel)
  self.minigames_hub=MinigamesHub(self.play,self.home,parent=self)
  self.pages.addWidget(self.minigames_hub)
  self.leaderboard_panel=LeaderboardPage(get_market=lambda:self.market_state,
      get_pvp=lambda:self.pvp_hub.data,
      get_nick=lambda:(str(self.session.get('name','')) if isinstance(self.session,dict) else ''),parent=self)
  self.pages.addWidget(self.leaderboard_panel)
  self.pvp_hub.stats_changed.connect(self.sync_my_ranking)
  self.fairplay_panel=FairPlayPanel(parent=self)
  self.pages.addWidget(self.fairplay_panel)
  self.refresh_fairplay_shortcut()
  self.discord_panel=DiscordHub(prefs_getter=lambda:self.prefs,
      save=self.discord_save_settings,connect=self.discord_update,
      status=lambda:getattr(self,'discord_state',{'connected':False,'message':'Nie skonfigurowano'}),
      is_playing=self.game_active,version=lambda:self.current_version,parent=self)
  self.discord_panel.layout().addWidget(btn('🌐  Discord — język kanałów / Channel language',self.open_discord_language_tool))
  self.discord_panel.layout().addWidget(btn('🎫  Tickety i regulamin Discord',self.open_discord_tickets_tool))
  self.pages.addWidget(self.discord_panel)
  self.together_panel=TogetherPage(
      game_dir=lambda:(self.active_profile.get('game_dir') if isinstance(self.active_profile,dict) else None) or str(MC_DIR),
      get_version=lambda:self.current_version,game_running=self.game_active,launch_game=self.play,
      open_chat=self.chat,open_skins=self.skins,parent=self)
  self.pages.addWidget(self.together_panel)
  self.ads_hub=AdsHub(self.ads_data,changed=self.ads_updated,parent=self);self.pages.addWidget(self.ads_hub)
  self.ai_panel=MinevoraAIPanel(lambda:self.language,parent=self);self.pages.addWidget(self.ai_panel)
  self.server_catalog=QWidget();sr=QVBoxLayout(self.server_catalog);sr.setContentsMargins(25,18,25,20)
  sr.addWidget(text('🌐  SERWERY MINECRAFT',27,True))
  sr.addWidget(text('Wybierz tryb i przeglądaj zapisane serwery w PvP Arena. Ogólnodostępny katalog MINEVORA Network jest planowany.',12,muted=True))
  self.ad_holders['servers']=self.make_ad_holder();sr.addWidget(self.ad_holders['servers'])
  sr.addWidget(btn('⚔  Otwórz listę serwerów PvP',self.pvp,True));sr.addStretch();self.pages.addWidget(self.server_catalog)
  self.setup_features_hub()
  # Permanent native MINEVORA studio pages; all Qt controls remain interactive.
  self.skin_panel=SkinDialog(self,session_getter=lambda:self.session)
  self.skin_panel.setWindowFlags(Qt.Widget)
  self.skin_panel.setMinimumSize(650,460)
  self.skin_panel.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  self.pages.addWidget(self.skin_panel)
  self.mod_panel=ModrinthDialog(str(MC_DIR),None,self,
      language=self.language,update_callback=self.mod_updates_dialog,
      auto_dependencies=self.prefs.get('auto_install_missing_mods',True),
      game_running=self.game_active,
      on_modpack_installed=self.modpack_profile_ready)
  self.mod_panel.setWindowFlags(Qt.Widget)
  self.mod_panel.setMinimumSize(650,460)
  self.mod_panel.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  self.pages.addWidget(self.mod_panel)
  self._workspace_prior_chat=None
  self.pages.currentChanged.connect(self.on_workspace_changed)
  self._transition_anim=None;self._transition_effect=None;self._transition_widget=None
  self.pages.currentChanged.connect(self.animate_page_transition)
  self.quick_search.textChanged.connect(self.global_search_changed)
  from PySide6.QtGui import QShortcut, QKeySequence
  find_shortcut=QShortcut(QKeySequence('Ctrl+K'),self)
  find_shortcut.activated.connect(self.quick_search.setFocus)
  self.ads_updated()
  QApplication.instance().aboutToQuit.connect(self.pvp_hub.stop_session)
  # Home and secondary sections are interactive Qt widgets, never static screenshots.
  self.enchanted_dashboard=EnchantedDashboard(self,self.pages)
  previous_home=self.pages.widget(0)
  self.pages.removeWidget(previous_home)
  # Keep old inactive controls alive: update_home_state and ad widgets still refer to them.
  previous_home.hide()
  self.pages.insertWidget(0,self.enchanted_dashboard)
  self.setup_183_info_pages()
  self.pages.currentChanged.connect(self.on_reference_page_changed)
  self.pages.currentChanged.connect(self.update_enchanted_banner)
  self.setup_overlay();self.refresh();self.home();self.apply_prefs();self.apply_language()
  apply_clear_icons(self)
  self.pages.currentChanged.connect(lambda _idx:QTimer.singleShot(0,lambda:apply_clear_icons(self)))
  self.statusBar().showMessage('MINEVORA 18.3 • Enchanted Edition',7000)
  QTimer.singleShot(1000,self.discord_update)


 def setup_183_info_pages(self):
  """Native interactive pages corresponding to website sections."""
  self.release_page=QScrollArea()
  self.release_page.setWidgetResizable(True)
  content=QWidget();layout=QVBoxLayout(content);layout.setContentsMargins(26,22,26,22);layout.setSpacing(13)
  header=QLabel('✦  MINEVORA 18.3  /  CO NOWEGO')
  header.setObjectName('pageTitle');layout.addWidget(header)
  description=QLabel('Jedna stylistyka Enchanted w launcherze i na stronie WWW. Pozostałe funkcje 18.2 zostały zachowane.')
  description.setWordWrap(True);layout.addWidget(description)
  details=[
   ('18.3 • WSPÓLNY WYGLĄD','Ciemny granat, fioletowe akcenty, ta sama kolorystyka kart, paneli i aktywnej nawigacji.'),
   ('18.3 • LEPSZA NAWIGACJA','Nowe strony Co nowego i Pomoc. Wszystkie wcześniejsze moduły launchera pozostają dostępne.'),
   ('18.2 • PVP HUD','Instalowanie zgodnego moda z GitHub Releases albo z dołączonej kopii, z kontrolą pliku JAR.'),
   ('ZGODNOŚĆ','PvP HUD jest aktualnie obsługiwany przez Minecraft Java 1.21.1 Fabric. Nie działa automatycznie na każdej wersji.')]
  for heading,body in details:
   item=QFrame();item.setObjectName('newsCard');inner=QVBoxLayout(item)
   tag=QLabel(heading);tag.setObjectName('releaseTag');inner.addWidget(tag)
   copy=QLabel(body);copy.setWordWrap(True);inner.addWidget(copy);layout.addWidget(item)
  actions=QHBoxLayout()
  for name,callback in [('⚔  Otwórz PvP HUD',self.pvp_mod_menu),('▶  Wersje Minecraft',self.instances),('⚙  Ustawienia',self.settings)]:
   button=QPushButton(name);button.clicked.connect(callback);actions.addWidget(button)
  layout.addLayout(actions);layout.addStretch(1);self.release_page.setWidget(content);self.pages.addWidget(self.release_page)
  self.help_hub=QScrollArea();self.help_hub.setWidgetResizable(True)
  help_content=QWidget();help_box=QVBoxLayout(help_content);help_box.setContentsMargins(26,22,26,22);help_box.setSpacing(14)
  help_title=QLabel('✦  MINEVORA 18.3  /  POMOC');help_title.setObjectName('pageTitle');help_box.addWidget(help_title)
  questions=[('Jak zainstalować PvP HUD?','Wybierz instancję Fabric 1.21.1, otwórz PvP Mod Menu i kliknij pobieranie/instalację. Wymagany jest Fabric API.'),
   ('Czy HUD działa we wszystkich wersjach?','Nie. Obecny plik moda został przygotowany wyłącznie dla Fabric 1.21.1. Inne wersje wymagają osobnych kompilacji.'),
   ('Nie otwiera się menu HUD','Sprawdź profil Fabric, Fabric API, plik JAR w katalogu mods i przypisanie klawisza w ustawieniach moda.'),
   ('Gdzie są funkcje Minecraft?','Graj / Wersje umożliwia wybór profilu. Mody i dodatki zawierają narzędzia Modrinth, a PvP Mod Menu ustawienia HUD.')]
  for heading,body in questions:
   item=QFrame();item.setObjectName('newsCard');iv=QVBoxLayout(item)
   title=QLabel(heading);title.setStyleSheet('font-weight:800;font-size:16px');iv.addWidget(title)
   detail=QLabel(body);detail.setWordWrap(True);iv.addWidget(detail);help_box.addWidget(item)
  button=QPushButton('⚔  Otwórz konfigurację PvP HUD');button.clicked.connect(self.pvp_mod_menu);help_box.addWidget(button)
  help_box.addStretch(1);self.help_hub.setWidget(help_content);self.pages.addWidget(self.help_hub)

 def release_notes(self):
  self.pages.setCurrentWidget(self.release_page)
  self.highlight_nav(len(self.nav)-2)

 def help_page(self):
  self.pages.setCurrentWidget(self.help_hub)
  self.highlight_nav(len(self.nav)-1)

 def animate_page_transition(self,index):
  # Keep animations short; no costly fade while offscreen or in economy mode.
  previous=self._transition_widget
  if self._transition_anim is not None:
   self._transition_anim.stop()
   self._transition_anim=None
  if previous is not None and self._transition_effect is not None:
   try:previous.setGraphicsEffect(None)
   except RuntimeError:pass
  self._transition_widget=None;self._transition_effect=None
  if not self.isVisible() or self.isMinimized():return
  if not self.prefs.get('page_fades',False) or self.prefs.get('motion_mode','eco')!='smooth':return
  page=self.pages.widget(index)
  if page is None:return
  effect=QGraphicsOpacityEffect(page);page.setGraphicsEffect(effect);effect.setOpacity(.84)
  anim=QPropertyAnimation(effect,b'opacity',self)
  anim.setDuration(165);anim.setStartValue(.84);anim.setEndValue(1.)
  anim.setEasingCurve(QEasingCurve.OutCubic)
  self._transition_widget=page;self._transition_effect=effect;self._transition_anim=anim
  anim.finished.connect(lambda p=page,e=effect:self.finish_page_transition(p,e))
  anim.start()

 def finish_page_transition(self,page,effect):
  if self._transition_widget is page and self._transition_effect is effect:
   page.setGraphicsEffect(None)
   self._transition_widget=None;self._transition_effect=None;self._transition_anim=None

 def changeEvent(self,event):
  super().changeEvent(event)
  if event.type()==QEvent.Type.WindowStateChange and hasattr(self,'hero'):
   self.hero.refresh_animation_state()

 def update_home_state(self):
  if not hasattr(self,'home_account'):return
  logged=isinstance(self.session,dict) and bool(self.session.get('access_token'))
  name=str(self.session.get('name','')) if logged else ''
  english=self.language=='en'
  self.home_account.setText(('✓ 1. Microsoft: '+name) if logged else ('○ 1. Microsoft: sign in' if english else '○ 1. Microsoft: zaloguj konto'))
  self.home_version.setText(('✓ 2. Minecraft: '+str(self.current_version)) if self.current_version else ('○ 2. Minecraft: install a version' if english else '○ 2. Minecraft: zainstaluj wersję'))
  ready=logged and bool(self.current_version)
  self.home_ready.setText(('✓ 3. Ready — click PLAY!' if english else '✓ 3. Gotowe — kliknij GRAJ!') if ready else ('○ 3. Complete the missing steps' if english else '○ 3. Wykonaj brakujące kroki powyżej'))
  if hasattr(self,'account_button'):self.account_button.setText('✓ '+name if logged else ('◉ Microsoft sign in' if english else '◉ Zaloguj Microsoft'))
  if hasattr(self,'enchanted_dashboard'):self.enchanted_dashboard.update_state()

 def set_chat_visible(self,visible,save=True):
  visible=bool(visible)
  self.chat_panel.setVisible(visible)
  if hasattr(self,'chat_toggle_button'):
   self.chat_toggle_button.setText(('☏ Hide chat' if visible else '☏ Show chat') if self.language=='en' else ('☏ Ukryj czat' if visible else '☏ Pokaż czat'))
  if hasattr(self,'chat_timer'):
   if visible:
    if not self.chat_timer.isActive():self.chat_timer.start(int(self.prefs.get('chat_interval',4))*1000)
    self.chat_view.refresh()
   else:self.chat_timer.stop()
  if save:self.save_local_pref('chat_visible',visible)

 def toggle_chat(self):
  self.set_chat_visible(not self.chat_panel.isVisible())

 def setup_features_hub(self):
  self.hub_widget=QWidget();root=QVBoxLayout(self.hub_widget);root.setContentsMargins(25,20,25,20);root.setSpacing(12)
  root.addWidget(text('WSZYSTKIE FUNKCJE',25,True))
  root.addWidget(text('Znajdź funkcję po nazwie: profil gracza, raporty, Guard, Minecraft, Marketplace…',12,muted=True))
  filters=QHBoxLayout()
  self.hub_search=QLineEdit();self.hub_search.setPlaceholderText('Szukaj: skiny, rangi, konto, tickety…')
  self.hub_filter_timer=QTimer(self);self.hub_filter_timer.setSingleShot(True);self.hub_filter_timer.setInterval(180)
  self.hub_filter_timer.timeout.connect(self.filter_hub)
  self.hub_search.textChanged.connect(lambda *_:self.hub_filter_timer.start())
  filters.addWidget(self.hub_search,1)
  self.hub_category=QComboBox();self.hub_category.addItems(CATEGORY_NAMES)
  self.hub_category.currentIndexChanged.connect(self.filter_hub);filters.addWidget(self.hub_category)
  root.addLayout(filters)
  self.hub_counter=text('',11,muted=True);root.addWidget(self.hub_counter)
  view=QScrollArea();view.setWidgetResizable(True)
  container=QWidget();self.hub_results=QVBoxLayout(container);self.hub_results.setContentsMargins(4,4,4,8)
  self.hub_results.setSpacing(9);view.setWidget(container);root.addWidget(view,1)
  self.pages.addWidget(self.hub_widget)
  self.filter_hub()

 def features_page(self):
  self.pages.setCurrentWidget(self.hub_widget)
  self.mark(99)

 def global_search_changed(self,value):
  if value.strip():
   self.hub_search.setText(value)
   self.features_page()
  elif self.pages.currentWidget()==self.hub_widget:
   self.hub_search.clear()

 def filter_hub(self,*_):
  while self.hub_results.count():
   item=self.hub_results.takeAt(0)
   if item.widget():item.widget().deleteLater()
  results=filter_features(self.hub_search.text(),self.hub_category.currentText())
  self.hub_counter.setText((f'Found {len(results)} of {len(FEATURES)} features' if self.language=='en' else f'Znaleziono: {len(results)} z {len(FEATURES)} funkcji'))
  if not results:self.hub_results.addWidget(text('Nie znaleziono funkcji. Wpisz inną nazwę.',13,muted=True))
  for feature in results:
   row=QFrame();row.setObjectName('panel');line=QHBoxLayout(row);line.setContentsMargins(15,12,15,12)
   details=QVBoxLayout();details.addWidget(text(translate(feature['title'],self.language),15,True))
   details.addWidget(text(translate(feature['description'],self.language),11,muted=True))
   line.addLayout(details,1)
   fn=getattr(self,feature['method'])
   line.addWidget(btn('Open  →' if self.language=='en' else 'Otwórz  →',fn))
   self.hub_results.addWidget(row)
  self.hub_results.addStretch()

 def ai_page(self):
  self.ai_panel.refresh_mode()
  self.pages.setCurrentWidget(self.ai_panel)
  self.mark(18)

 def make_ad_holder(self):
  frame=QWidget();outer=QVBoxLayout(frame);outer.setContentsMargins(0,0,0,0);outer.setSpacing(7)
  frame.hide();return frame

 def ads_updated(self):
  for slot in list(self.ad_holders):self.render_ads(slot)
  if hasattr(self,'ads_hub'):self.ads_hub.refresh()

 def render_ads(self,slot):
  frame=self.ad_holders.get(slot)
  if frame is None:return
  layout=frame.layout()
  while layout.count():
   element=layout.takeAt(0)
   if element.widget():element.widget().deleteLater()
  entries=ads_for_slot(self.ads_data,slot)
  selected=[]
  for kind in ('own','sponsored'):
   item=next((a for a in entries if a.get('type')==kind),None)
   if item:selected.append(item)
  frame.setVisible(bool(selected))
  for ad in selected:
   layout.addWidget(ad_widget(ad,self.open_ad))
   key=(slot,ad['id'])
   if key not in self.ads_seen:
    self.ads_seen.add(key)
    record_event(self.ads_data,ad['id'],'impression')
    save_ads(self.ads_data)

 def open_ad(self,ad):
  try:url=validate_url(str(ad.get('url','')))
  except ValueError as exc:
   QMessageBox.warning(self,'MINEVORA Ads',str(exc));return
  if not url:return
  record_event(self.ads_data,ad['id'],'click');save_ads(self.ads_data)
  self.ads_hub.refresh()
  QDesktopServices.openUrl(QUrl(url))

 def ads_page(self):
  self.pages.setCurrentWidget(self.ads_hub);self.ads_hub.refresh();self.mark(16)

 def open_minevora_discord(self):
  """Open the official MINEVORA community invite in the system browser."""
  if not QDesktopServices.openUrl(QUrl(OFFICIAL_MINEVORA_DISCORD_INVITE)):
   QMessageBox.warning(self,'MINEVORA Discord','Nie można otworzyć przeglądarki. Skopiuj link: '+OFFICIAL_MINEVORA_DISCORD_INVITE)

 def discord_page(self):
  self.pages.setCurrentWidget(self.discord_panel)
  self.mark(11)
  self.discord_panel.refresh_status()

 def pvp_mod_menu(self):
  self.pvp_mod_panel.refresh_target()
  self.pages.setCurrentWidget(self.pvp_mod_panel)
  self.mark(14)

 def pvp(self):
  self.pages.setCurrentWidget(self.pvp_hub)
  self.pvp_hub.refresh_all()
  self.mark(14)

 def sync_my_ranking(self):
  # Do not create a record until Microsoft has confirmed the Minecraft nickname.
  if not isinstance(self.session,dict) or not self.session.get('access_token'):
   return
  nick=self.session.get('name','')
  if not hasattr(self,'leaderboard_panel') or not hasattr(self,'pvp_hub'):
   return
  try:
   data,changed=sync_local(self.leaderboard_panel.data,nick,self.market_state,self.pvp_hub.data)
   if changed:
    self.leaderboard_panel.data=data
    if self.pages.currentWidget()==self.leaderboard_panel:
     self.leaderboard_panel.refresh_table()
  except (ValueError,OSError) as exc:
   self.statusBar().showMessage('Synchronizacja rankingu: '+str(exc)[:120],6000)

 def leaderboard(self):
  self.sync_my_ranking()
  self.leaderboard_panel.refresh_table()
  self.pages.setCurrentWidget(self.leaderboard_panel)
  self.mark(19)

 def fairplay(self):
  self.pages.setCurrentWidget(self.fairplay_panel)
  self.fairplay_panel.refresh_data()
  self.refresh_fairplay_shortcut()
  self.mark(15)

 def refresh_fairplay_shortcut(self):
  from minevora_fairplay_core import review_queue, load_data
  try:
   pending=len(review_queue(load_data()))
  except (OSError,ValueError):pending=0
  self.fairplay_shortcut.setText('🛡 Fair Play (%d)' % pending if pending else '🛡 Profil gracza')
  self.fairplay_shortcut.setToolTip('Nierozpatrzone lokalne zgłoszenia: %d. Nie są dowodem oszukiwania.' % pending)

 def setup_creator_page(self):
  self.creator_view=QWidget();scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(self.creator_view)
  self.creator_root=QVBoxLayout(self.creator_view);self.creator_root.setContentsMargins(30,22,30,26);self.creator_root.setSpacing(15)
  self.creator_root.addWidget(text('🏆  TWÓJ PROFIL TWÓRCY',27,True))
  self.creator_root.addWidget(text('Publikuj własne mapy i budowle w lokalnym Marketplace, zdobywaj XP i odbieraj MineCoins (demo).',12,muted=True))
  hero=QFrame();hero.setObjectName('hero');h=QHBoxLayout(hero);h.setContentsMargins(25,20,25,20)
  self.creator_image=QLabel();self.creator_image.setFixedSize(116,116);self.creator_image.setAlignment(Qt.AlignCenter);h.addWidget(self.creator_image)
  rank_info=QVBoxLayout();self.creator_rank=text('',25,True);rank_info.addWidget(self.creator_rank)
  self.creator_level=text('',15,True);rank_info.addWidget(self.creator_level)
  self.creator_xp=text('',12,muted=True);rank_info.addWidget(self.creator_xp)
  self.creator_progress=QProgressBar();self.creator_progress.setRange(0,1000);self.creator_progress.setFixedHeight(21)
  self.creator_progress.setStyleSheet('QProgressBar {border:1px solid #8870c6;border-radius:9px;background:#10172b;color:white;text-align:center} QProgressBar::chunk {background:#9569e9;border-radius:8px}')
  rank_info.addWidget(self.creator_progress)
  h.addLayout(rank_info,1);self.creator_root.addWidget(hero)
  counts=QFrame();counts.setObjectName('panel');cv=QHBoxLayout(counts)
  self.creator_counts=QLabel();self.creator_counts.setWordWrap(True);cv.addWidget(self.creator_counts);self.creator_root.addWidget(counts)
  rewards=QHBoxLayout();rewards.setSpacing(14)
  daily=QFrame();daily.setObjectName('card');dv=QVBoxLayout(daily)
  dv.addWidget(text('💎  CODZIENNA NAGRODA',17,True));dv.addWidget(text(f'Odbierz {DAILY_MVC} MVC raz dziennie (według czasu UTC).',11,muted=True))
  self.creator_daily_button=btn('Odbierz nagrodę',self.creator_claim_daily,True);dv.addWidget(self.creator_daily_button)
  self.creator_daily_status=text('',10,muted=True);dv.addWidget(self.creator_daily_status);rewards.addWidget(daily,1)
  milestone=QFrame();milestone.setObjectName('card');mv=QVBoxLayout(milestone)
  mv.addWidget(text('✨  NAGRODY ZA POZIOM',17,True));mv.addWidget(text('Odbieraj MineCoins za zdobyte poziomy 2, 3, 4 i kolejne.',11,muted=True))
  self.creator_level_button=btn('Odbierz premie',self.creator_claim_levels,True);mv.addWidget(self.creator_level_button)
  self.creator_level_status=text('',10,muted=True);mv.addWidget(self.creator_level_status);rewards.addWidget(milestone,1)
  self.creator_root.addLayout(rewards)
  bonus=QFrame();bonus.setObjectName('panel');bv=QVBoxLayout(bonus)
  bv.addWidget(text('⚡  BONUS TYGODNIOWY I PODWÓJNE XP',20,True))
  bv.addWidget(text('Raz w tygodniu: +100 MVC (demo) i jeden booster ×2 XP na 30 minut. Bonus dotyczy wyłącznie nowych, unikalnych projektów.',11,muted=True))
  boost_row=QHBoxLayout()
  self.creator_weekly_button=btn('🎁 Odbierz bonus tygodniowy',self.creator_claim_weekly,True)
  self.creator_boost_button=btn('⚡ Aktywuj ×2 XP',self.creator_activate_boost)
  boost_row.addWidget(self.creator_weekly_button);boost_row.addWidget(self.creator_boost_button);bv.addLayout(boost_row)
  self.creator_boost_status=QLabel();self.creator_boost_status.setWordWrap(True);bv.addWidget(self.creator_boost_status)
  self.creator_root.addWidget(bonus)
  self.creator_boost_timer=QTimer(self);self.creator_boost_timer.timeout.connect(self.refresh_boost_status)
  self.creator_boost_timer.start(1000)
  self.creator_root.addWidget(text('✦  LOGA RANG',22,True))
  animation_panel=QFrame();animation_panel.setObjectName('panel')
  animation_row=QHBoxLayout(animation_panel)
  animation_row.addWidget(text('✨  ANIMACJA AWANSU',14,True))
  self.creator_animation_enabled=QCheckBox('Pokazuj automatycznie')
  self.creator_animation_enabled.setChecked(bool(self.prefs.get('rank_animations',True)))
  self.creator_animation_enabled.toggled.connect(self.creator_animation_toggle)
  animation_row.addWidget(self.creator_animation_enabled)
  animation_row.addStretch()
  animation_row.addWidget(btn('▶  Podgląd animacji',self.creator_preview_animation))
  self.creator_root.addWidget(animation_panel)
  self.creator_root.addWidget(text('Rangi zmieniają się automatycznie po osiągnięciu wymaganego poziomu.',11,muted=True))
  self.creator_rank_grid=QGridLayout();self.creator_rank_grid.setSpacing(10)
  self.creator_rank_cards=[]
  for index,r in enumerate(RANKS):
   panel=QFrame();panel.setObjectName('panel');v=QVBoxLayout(panel)
   icon=QLabel();icon.setAlignment(Qt.AlignCenter)
   icon.setPixmap(QPixmap(str(BASE/'rank_icons'/r['icon'])).scaled(88,88,Qt.KeepAspectRatio,Qt.SmoothTransformation));v.addWidget(icon)
   name=text(r['name'],15,True);name.setAlignment(Qt.AlignCenter);v.addWidget(name)
   status=text('',11,muted=True);status.setAlignment(Qt.AlignCenter);v.addWidget(status)
   self.creator_rank_cards.append((panel,status,r))
   self.creator_rank_grid.addWidget(panel,index//3,index%3)
  self.creator_root.addLayout(self.creator_rank_grid)
  self.creator_root.addWidget(btn('＋  Dodaj mapę lub budowlę',self.market_add_listing,True))
  self.creator_root.addWidget(text('Postęp i MVC są lokalne, demonstracyjne — nie są walutą do wypłaty ani rangami serwera. Za unikalną mapę: +120 XP, budowlę: +80 XP, inny projekt: +15 XP. Ponowne dodanie tej samej nazwy przez tego samego autora nie daje dodatkowego XP.',10,muted=True))
  self.creator_root.addStretch();self.pages.addWidget(scroll);self.creator_scroll=scroll
  self.refresh_creator_page()

 def creator_page(self):
  self.refresh_creator_page()
  self.pages.setCurrentWidget(self.creator_scroll);self.mark(13)

 def refresh_creator_page(self):
  if not hasattr(self,'creator_rank'):return
  p=ensure_progress(self.market_state);level=level_of(p['xp']);rank=rank_of(level)
  image=QPixmap(str(BASE/'rank_icons'/rank['icon']))
  if not image.isNull():self.creator_image.setPixmap(image.scaled(110,110,Qt.KeepAspectRatio,Qt.SmoothTransformation))
  self.creator_rank.setText('RANGA: '+rank['name'].upper())
  self.creator_level.setText(f'POZIOM {level}  ·  {self.market_state["balance"]} MVC (demo)')
  lower=level_floor(level);upper=level_floor(level+1)
  self.creator_xp.setText(f'{p["xp"]} XP  •  {upper-p["xp"]} XP do poziomu {level+1}')
  self.creator_progress.setValue(round((p['xp']-lower)/(upper-lower)*1000))
  self.creator_progress.setFormat(f'{p["xp"]-lower}/{upper-lower} XP')
  c=p['project_counts']
  self.creator_counts.setText(f'🗺  Mapy: {c["Mapy"]}     🏰  Budowle: {c["Budowle"]}     ✦  Inne: {c["Inne"]}     ◆  Łącznie: {sum(c.values())}')
  allowed=can_claim_daily(self.market_state)
  self.creator_daily_button.setEnabled(allowed)
  self.creator_daily_button.setText(f'💎  Odbierz {DAILY_MVC} MVC' if allowed else '✓  Odebrano dzisiaj')
  self.creator_daily_status.setText('Dostępne teraz' if allowed else 'Następna nagroda po zmianie daty UTC')
  pending=pending_level_rewards(self.market_state);coins=sum(coin for _,coin in pending)
  self.creator_level_button.setEnabled(bool(pending))
  self.creator_level_button.setText(f'✨  Odbierz {coins} MVC' if pending else '✓  Wszystkie premie odebrane')
  self.creator_level_status.setText(f'Nagrody za {len(pending)} poziomów' if pending else 'Dodawaj projekty, aby zdobywać kolejne poziomy')
  self.refresh_boost_status()
  for panel,status,r in self.creator_rank_cards:
   unlocked=level>=r['min_level'];is_current=rank['name']==r['name']
   status.setText(('★ AKTYWNA RANGA' if is_current else '✓ ODBLOKOWANA') if unlocked else f'🔒  Od poziomu {r["min_level"]}')
   panel.setStyleSheet('QFrame#panel {border:2px solid '+(r['color'] if unlocked else '#303d58')+';border-radius:18px;background:#19243b}')

 def refresh_boost_status(self):
  if not hasattr(self,'creator_boost_status'):return
  remaining=boost_remaining(self.market_state)
  inventory=ensure_progress(self.market_state)['boost_inventory']
  active=remaining>0
  self.creator_weekly_button.setEnabled(can_claim_weekly(self.market_state))
  self.creator_weekly_button.setText('🎁 Odbierz +100 MVC i booster ×2' if can_claim_weekly(self.market_state) else '✓ Tygodniowy bonus odebrany')
  self.creator_boost_button.setEnabled(inventory>0 and not active)
  self.creator_boost_status.setText((f'⚡ ×2 XP AKTYWNE — {remaining//60:02d}:{remaining%60:02d} min:s' if active else 'Booster nieaktywny')+f'  ·  Dostępne boostery: {inventory}')

 def creator_claim_weekly(self):
  before=copy.deepcopy(self.market_state)
  amount=claim_weekly(self.market_state)
  if amount and self._creator_save(before):
   QMessageBox.information(self,'Bonus tygodniowy',f'Odebrano +{amount} MVC (demo) i 1 booster ×2 XP. Aktywuj go przed dodaniem projektu!')
  self.refresh_boost_status()

 def creator_activate_boost(self):
  before=copy.deepcopy(self.market_state)
  if activate_boost(self.market_state):
   if self._creator_save(before):QMessageBox.information(self,'×2 XP','Booster aktywny przez 30 minut! Działa na nowe, unikalne projekty.')
  self.refresh_boost_status()

 def creator_animation_toggle(self,enabled):
  self.prefs['rank_animations']=bool(enabled)
  try:
   PREFS_PATH.parent.mkdir(parents=True,exist_ok=True)
   temp=PREFS_PATH.with_suffix('.tmp')
   temp.write_text(json.dumps(self.prefs,ensure_ascii=False,indent=2),encoding='utf-8')
   temp.replace(PREFS_PATH)
  except OSError as exc:QMessageBox.warning(self,'Ustawienia animacji',f'Nie zapisano ustawień: {exc}')

 def show_creator_ascension(self,old_level,new_level,preview=False):
  # Rank/level is computed from the stored XP, not from text in the dialog.
  previous_rank=rank_of(old_level)
  next_rank=rank_of(new_level)
  earned=sum(coins for _,coins in pending_level_rewards(self.market_state)) if not preview else 0
  dialog=RankUpDialog(next_rank,BASE/'rank_icons'/next_rank['icon'],
                      new_level,old_level,next_rank['name']!=previous_rank['name'],
                      earned,preview,parent=self)
  dialog.claim_requested.connect(self.creator_claim_levels)
  # Non-blocking open keeps the launcher event loop and painted effects responsive.
  dialog.setAttribute(Qt.WA_DeleteOnClose,True)
  dialog.open()
  self._creator_ascension=dialog

 def creator_preview_animation(self):
  actual=level_of(ensure_progress(self.market_state)['xp'])
  next_rank=next((r for r in RANKS if r['min_level']>actual),RANKS[-1])
  target=next_rank['min_level']
  previous=target-1 if target>1 else target
  self.show_creator_ascension(previous,target,preview=True)

 def _creator_save(self,before):
  try:self.save_market_state()
  except OSError as exc:
   self.market_state=before;QMessageBox.warning(self,'Zapis nagrody',str(exc));return False
  if self.pages.currentWidget()==self.market_page:self.market_render()
  self.refresh_creator_page();return True

 def creator_claim_daily(self):
  before=copy.deepcopy(self.market_state)
  amount=claim_daily(self.market_state)
  if not amount:
   self.refresh_creator_page();return
  if self._creator_save(before):QMessageBox.information(self,'Nagroda dzienna',f'Odebrano +{amount} MVC (demo)!')

 def creator_claim_levels(self):
  before=copy.deepcopy(self.market_state)
  amount,levels=claim_levels(self.market_state)
  if not levels:
   self.refresh_creator_page();return
  if self._creator_save(before):QMessageBox.information(self,'Nagrody za poziomy',f'Odebrano +{amount} MVC (demo) za poziomy: {", ".join(map(str, levels))}.')

 def setup_overlay(self):
  # An external launcher window cannot read Minecraft's in-game FPS / ping.
  # Only show facts available from the session managed by the launcher.
  self.session_started=None
  self._overlay_version=None
  self.overlay=QFrame(None,Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint|Qt.Tool|Qt.WindowDoesNotAcceptFocus)
  self.overlay.setObjectName('overlay')
  self.overlay.setAttribute(Qt.WA_TranslucentBackground)
  self.overlay.setAttribute(Qt.WA_TransparentForMouseEvents,True)
  ov=QVBoxLayout(self.overlay);ov.setContentsMargins(13,9,13,10);ov.setSpacing(3)
  title=QLabel('◆ MINEVORA');title.setObjectName('overlayTitle');ov.addWidget(title)
  self.overlay_labels={}
  for key,caption in [('version','Minecraft'),('time','Czas gry')]:
   lbl=QLabel(caption);ov.addWidget(lbl);self.overlay_labels[key]=lbl
  self.overlay_timer=QTimer(self)
  self.overlay_timer.timeout.connect(self.update_overlay)
  self.overlay_timer.setInterval(1000)
  self.overlay.hide();self.apply_overlay_settings()
  self.discord_rpc=None;self.discord_started=None
  self.discord_state={'connected':False,'message':'Włącz Rich Presence i zapisz Application ID.'}
  self.discord_timer=QTimer(self)
  self.discord_timer.timeout.connect(self.discord_periodic)
  self.discord_timer.start(60000)
 def game_active(self):
  return getattr(self,'session_started',None) is not None and self.play_worker is not None and self.play_worker.isRunning()
 def apply_overlay_settings(self):
  size=int(self.prefs.get('hud_size',12));opacity=int(self.prefs.get('hud_opacity',78))
  self.overlay.setStyleSheet(f'QFrame#overlay{{background:rgba(13,20,39,{round(opacity*2.55)});border:1px solid #a780ed;border-radius:12px}} QLabel{{color:#f5eeff;background:transparent;font-size:{size}px;font-weight:600}} QLabel#overlayTitle{{color:#caacff;font-size:{size+1}px;font-weight:800}}')
  for key,label in self.overlay_labels.items():
   label.setVisible(bool(self.prefs.get('hud_'+key,True)))
  self.overlay.adjustSize()
  width=max(165,min(390,self.overlay.sizeHint().width()+12))
  self.overlay.setFixedWidth(width)
  self.overlay.adjustSize()
  screen=QApplication.primaryScreen()
  if screen:
   rect=screen.availableGeometry();position=self.prefs.get('hud_position','Prawy górny')
   x=rect.right()-self.overlay.width()-20 if 'Prawy' in position else rect.left()+20
   y=rect.bottom()-self.overlay.height()-20 if 'dolny' in position else rect.top()+20
   self.overlay.move(x,y)
 def toggle_overlay(self):
  self.overlay_settings_dialog()
 def overlay_settings_dialog(self):
  dialog=QDialog(self);dialog.setWindowTitle('MINEVORA • Ustawienia nakładki');dialog.resize(440,350)
  root=QVBoxLayout(dialog);root.addWidget(text('◆ NAKŁADKA MINECRAFT',20,True))
  root.addWidget(text('Pokazuje tylko sprawdzone informacje podczas gry uruchomionej z MINEVORA.',11,muted=True))
  form=QFormLayout()
  enabled=QCheckBox('Automatycznie pokazuj podczas gry');enabled.setChecked(self.prefs.get('hud_enabled',True));form.addRow('Aktywacja:',enabled)
  position=QComboBox();position.addItems(['Prawy górny','Lewy górny','Prawy dolny','Lewy dolny']);position.setCurrentText(self.prefs.get('hud_position','Prawy górny'));form.addRow('Pozycja:',position)
  size=QSpinBox();size.setRange(10,18);size.setValue(int(self.prefs.get('hud_size',12)));form.addRow('Rozmiar tekstu:',size)
  opacity=QSpinBox();opacity.setRange(25,100);opacity.setSuffix(' %');opacity.setValue(int(self.prefs.get('hud_opacity',78)));form.addRow('Widoczność tła:',opacity)
  fields={}
  for key,name in [('version','Wersja Minecraft'),('time','Czas gry')]:
   cb=QCheckBox(name);cb.setChecked(self.prefs.get('hud_'+key,True));fields[key]=cb;form.addRow('Pokaż:',cb)
  root.addLayout(form)
  root.addWidget(text('FPS wyświetlisz w grze przez MINEVORA PvP HUD (mod).\nPing, serwer i lista znajomych nie są jeszcze połączone z launcherem — nie pokazujemy nieprawdziwych odczytów.',10,muted=True))
  buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel)
  buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);root.addWidget(buttons)
  if dialog.exec()!=QDialog.Accepted:return
  self.prefs.update({'hud_enabled':enabled.isChecked(),'hud_position':position.currentText(),'hud_size':size.value(),'hud_opacity':opacity.value()})
  for key,cb in fields.items():self.prefs['hud_'+key]=cb.isChecked()
  try:
   PREFS_PATH.parent.mkdir(parents=True,exist_ok=True)
   temp=PREFS_PATH.with_suffix('.tmp');temp.write_text(json.dumps(self.prefs,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(PREFS_PATH)
  except OSError as exc:QMessageBox.warning(self,'HUD',str(exc));return
  self.apply_overlay_settings();self.update_overlay()
 def update_overlay(self):
  if not hasattr(self,'overlay_labels'):return
  if not self.game_active() or not self.prefs.get('hud_enabled',True):
   self.overlay.hide();return
  elapsed=max(0,int(time.monotonic()-self.session_started))
  values=dict(display_rows(elapsed,self._overlay_version,
    show_version=bool(self.prefs.get('hud_version',True)),
    show_time=bool(self.prefs.get('hud_time',True))))
  for key,label in self.overlay_labels.items():
   label.setText(values.get(key,''))
   label.setVisible(key in values)
  if not values:
   self.overlay.hide();return
  self.apply_overlay_settings()
  if not self.overlay.isVisible():self.overlay.show()
 def game_launch_failed(self,msg):
  self.overlay_timer.stop()
  self.overlay.hide()
  self.session_started=None
  self.discord_started=None
  self.discord_update()
  QMessageBox.critical(self,'Błąd uruchamiania',msg)

 def game_finished(self,code):
  self.overlay_timer.stop()
  self.statusBar().showMessage(f'Minecraft zakończył działanie • kod {code}')
  self.session_started=None
  self.discord_started=None
  self.overlay.hide()
  self.update_overlay()
  self.discord_update()
 def discord_dialog(self):
  # Backwards-compatible entry point used by Settings.
  self.discord_page()

 def discord_save_settings(self,values):
  application_id=str(values.get('discord_app_id','')).strip()
  if values.get('discord_enabled') and not valid_application_id(application_id):
   return False,'Włączając Rich Presence, podaj poprawny Discord Application ID (15–22 cyfr). To nie jest identyfikator konta.'
  if application_id and not valid_application_id(application_id):
   return False,'Discord Application ID musi składać się z 15–22 cyfr.'
  try:invite_url=normalize_invite(values.get('discord_invite_url',''))
  except ValueError as exc:return False,str(exc)
  safe={'discord_app_id':application_id,
        'discord_enabled':bool(values.get('discord_enabled',False)),
        'discord_only_in_game':bool(values.get('discord_only_in_game',True)),
        'discord_show_version':bool(values.get('discord_show_version',False)),
        'discord_invite_url':invite_url}
  updated=dict(self.prefs);updated.update(safe)
  try:
   PREFS_PATH.parent.mkdir(parents=True,exist_ok=True)
   PREFS_PATH.write_text(json.dumps(updated,ensure_ascii=False,indent=2),encoding='utf-8')
  except OSError as exc:
   return False,'Nie udało się zapisać ustawień: '+str(exc)
  self.prefs.update(safe)
  self.discord_update()
  return True,('Ustawienia zapisane. '+self.discord_state.get('message',''))

 def discord_periodic(self):
  if not hasattr(self,'discord_rpc') or not self.prefs.get('discord_enabled'):
   return
  if self.discord_rpc is not None:
   try:
    payload=presence_payload(self.prefs,self.game_active(),self.current_version,self.discord_started)
    self.discord_rpc.update(**payload)
   except Exception:
    self.discord_update()
  elif should_publish(self.prefs,self.game_active()):
   self.discord_update()

 def discord_update(self):
  if self.discord_rpc is not None:
   try:self.discord_rpc.clear();self.discord_rpc.close()
   except Exception:pass
   self.discord_rpc=None
  if not self.prefs.get('discord_enabled',False):
   self.discord_state={'connected':False,'message':'Rich Presence jest wyłączone. Możesz je włączyć w zakładce Discord.'}
  elif not valid_application_id(self.prefs.get('discord_app_id','')):
   self.discord_state={'connected':False,'message':'Brakuje poprawnego Discord Application ID.'}
  elif not should_publish(self.prefs,self.game_active()):
   self.discord_state={'connected':False,'message':'Czeka na uruchomienie Minecraft — wybrano tryb tylko podczas gry.'}
  else:
   rpc=None
   try:
    from pypresence import Presence
    rpc=Presence(self.prefs['discord_app_id'])
    rpc.connect()
    payload=presence_payload(self.prefs,self.game_active(),self.current_version,self.discord_started)
    rpc.update(**payload)
    self.discord_rpc=rpc
    self.discord_state={'connected':True,'message':'Aktywność MINEVORA wysłana do Discorda. Zmień status aktywności w ustawieniach prywatności Discorda.'}
   except ImportError:
    self.discord_state={'connected':False,'message':'Nie zainstalowano pypresence. Uruchom INSTALUJ_ZALEZNOSCI.bat.'}
   except Exception as exc:
    if rpc is not None:
     try:rpc.close()
     except Exception:pass
    self.discord_state={'connected':False,'message':'Brak połączenia z aplikacją Discord: '+str(exc)[:160]}
  if hasattr(self,'discord_panel'):
   self.discord_panel.refresh_status()
  if not self.discord_state.get('connected',False) and self.prefs.get('discord_enabled',False):
   self.statusBar().showMessage('Discord: '+self.discord_state['message'][:150])

 def setup_market(self):
  self.market_state=self.load_market_state()
  self.market_page=QWidget();root=QVBoxLayout(self.market_page);root.setContentsMargins(22,14,22,14);root.setSpacing(12)
  root.addWidget(text('◆  MINEVORA MARKETPLACE',27,True))
  root.addWidget(text('Mapy, budowle, rigi Minecraft oraz modele Blender i Blockbench • lokalny katalog demonstracyjny',11,muted=True))
  self.ad_holders['market']=self.make_ad_holder();root.addWidget(self.ad_holders['market'])
  wallet=QFrame();wallet.setObjectName('panel');wv=QHBoxLayout(wallet)
  self.market_balance=text('',17,True);wv.addWidget(self.market_balance);wv.addStretch()
  wv.addWidget(btn('Moja biblioteka',self.market_library))
  wv.addWidget(btn('＋ Dodaj projekt',self.market_add_listing,True));root.addWidget(wallet)
  self.market_extra=QWidget();tools=QGridLayout(self.market_extra);tools.setContentsMargins(0,0,0,0)
  for index,(title,action) in enumerate([('🏆 Rangi',self.creator_page),('Moje projekty',self.market_my_projects),('Historia',self.market_history),
      ('🦴 Dodaj rig',lambda checked=False:self.market_add_listing('Rigi Minecraft')),
      ('🧊 Blender',lambda checked=False:self.market_add_listing('Modele Blender')),
      ('🪄 Blockbench',lambda checked=False:self.market_add_listing('Modele Blockbench'))]):
   tools.addWidget(btn(title,action),index//3,index%3)
  self.market_extra.hide()
  root.addWidget(btn('⚙ Więcej opcji Marketplace  ▾',lambda checked=False:self.market_extra.setVisible(not self.market_extra.isVisible())))
  root.addWidget(self.market_extra)
  bar=QHBoxLayout();self.market_search=QLineEdit();self.market_search.setPlaceholderText('⌕  Szukaj projektów, autorów i kategorii…');self.market_filter_timer=QTimer(self);self.market_filter_timer.setSingleShot(True);self.market_filter_timer.setInterval(210)
  self.market_filter_timer.timeout.connect(self.market_reset_page)
  self.market_search.textChanged.connect(lambda *_:self.market_filter_timer.start())
  bar.addWidget(self.market_search,1)
  self.market_category_combo=QComboBox();self.market_category_combo.addItems(['Wszystkie']+list(CATEGORY_ICONS))
  self.market_category_combo.setToolTip('Filtruj według kategorii')
  self.market_category_combo.currentTextChanged.connect(self.market_set_category);bar.addWidget(self.market_category_combo)
  self.market_sort=QComboBox();self.market_sort.addItems(['Najnowsze','Nazwa A–Z','Cena rosnąco','Cena malejąco']);self.market_sort.currentIndexChanged.connect(self.market_reset_page);bar.addWidget(self.market_sort)
  advanced_filters=QWidget();advanced_layout=QHBoxLayout(advanced_filters);advanced_layout.setContentsMargins(0,0,0,0)
  self.market_price_filter=QComboBox();self.market_price_filter.addItems(['Wszystkie','Darmowe','Za MVC','Cena PLN (informacyjnie)']);self.market_price_filter.currentIndexChanged.connect(self.market_reset_page);advanced_layout.addWidget(self.market_price_filter)
  self.market_format_filter=QComboBox();self.market_format_filter.addItems(['Każdy format']+sorted(ASSET_SUFFIXES));self.market_format_filter.currentIndexChanged.connect(self.market_reset_page);advanced_layout.addWidget(self.market_format_filter)
  root.addLayout(bar);root.addWidget(btn('⌕ Zaawansowane filtry  ▾',lambda checked=False:advanced_filters.setVisible(not advanced_filters.isVisible())))
  root.addWidget(advanced_filters);advanced_filters.hide()
  self.market_counter=text('',11,muted=True);root.addWidget(self.market_counter)
  root.addWidget(btn('↺ Wyczyść filtry',self.market_clear_filters))
  self.market_visible_limit=PAGE_SIZE
  self.market_pix_cache={}
  area=QHBoxLayout();area.setSpacing(13)
  sidebar=QFrame();sidebar.setObjectName('panel');sidebar.setFixedWidth(170);sv=QVBoxLayout(sidebar);sv.setContentsMargins(9,14,9,12);sv.setSpacing(5)
  sv.addWidget(text('KATEGORIE',12,True));self.market_category_buttons=[];self.market_active_category='Wszystkie'
  for category in ['Wszystkie']+list(CATEGORY_ICONS):
   symbol='◉' if category=='Wszystkie' else CATEGORY_ICONS[category]
   b=btn(symbol+'  '+category,lambda checked=False,c=category:self.market_set_category(c))
   b.setObjectName('nav');b.setMinimumHeight(35);sv.addWidget(b);self.market_category_buttons.append((category,b))
  sv.addWidget(text('STYLE BUDOWLI',11,True))
  self.market_style=QComboBox();self.market_style.addItems(['Dowolny','Medieval','Modern','Fantasy','Wooden','Japanese','Steampunk','Starter','Inny']);self.market_style.currentIndexChanged.connect(self.market_reset_page);advanced_layout.addWidget(self.market_style)
  sv.addStretch();self.market_sidebar=sidebar;area.addWidget(sidebar);sidebar.hide()
  scroll=QScrollArea();scroll.setWidgetResizable(True);contents=QWidget();self.market_items=QGridLayout(contents);self.market_items.setSpacing(12);self.market_items.setAlignment(Qt.AlignTop);scroll.setWidget(contents);area.addWidget(scroll,1);root.addLayout(area,1)
  self.market_more=btn('＋ Pokaż kolejne projekty',self.market_show_more)
  root.addWidget(self.market_more)
  root.addWidget(text('DEMO: pliki projektów 3D zapisują się lokalnie. Brak wysyłania do internetu, płatności i instalacji modeli w Minecraft.',10,muted=True))
  self.pages.addWidget(self.market_page);self.market_render()
 def market_reset_page(self,*_):
  self.market_visible_limit=PAGE_SIZE
  self.market_render()

 def market_show_more(self):
  self.market_visible_limit+=PAGE_SIZE
  self.market_render()

 def market_clear_filters(self):
  for widget in (self.market_search,self.market_category_combo,self.market_sort,
                 self.market_price_filter,self.market_format_filter,self.market_style):
   widget.blockSignals(True)
  self.market_search.clear();self.market_category_combo.setCurrentIndex(0)
  self.market_sort.setCurrentIndex(0);self.market_price_filter.setCurrentIndex(0)
  self.market_format_filter.setCurrentIndex(0);self.market_style.setCurrentIndex(0)
  self.market_active_category='Wszystkie'
  for widget in (self.market_search,self.market_category_combo,self.market_sort,
                 self.market_price_filter,self.market_format_filter,self.market_style):
   widget.blockSignals(False)
  self.market_reset_page()

 def market_pixmap(self,path):
  try:
   file=Path(path)
   if not file.is_file():return None
   stamp=(str(file.resolve()),file.stat().st_mtime_ns)
   if stamp not in self.market_pix_cache:
    pix=QPixmap(str(file))
    if pix.isNull():return None
    if len(self.market_pix_cache)>=60:self.market_pix_cache.clear()
    # Preserve the aspect ratio; crop centrally rather than stretching thumbnails.
    scaled=pix.scaled(320,126,Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation)
    x=max(0,(scaled.width()-320)//2)
    y=max(0,(scaled.height()-126)//2)
    self.market_pix_cache[stamp]=scaled.copy(x,y,min(320,scaled.width()),min(126,scaled.height()))
   return self.market_pix_cache[stamp]
  except (OSError,ValueError):return None

 def market_set_category(self,category):
  self.market_active_category=category
  if category not in ('Budowle','Wszystkie') and self.market_style.currentText()!='Dowolny':
   self.market_style.blockSignals(True);self.market_style.setCurrentIndex(0);self.market_style.blockSignals(False)
  if hasattr(self,'market_category_combo') and self.market_category_combo.currentText()!=category:
   self.market_category_combo.blockSignals(True)
   self.market_category_combo.setCurrentText(category)
   self.market_category_combo.blockSignals(False)
  self.market_reset_page()
 def load_market_state(self):
  default={'balance':1000,'listings':[dict(x) for x in MARKET_DEFAULT],'purchases':[],'favorites':[]}
  try:
   data=json.loads(MARKET_PATH.read_text(encoding='utf-8'))
   if not isinstance(data,dict) or type(data.get('balance')) is not int or data['balance']<0 or not isinstance(data.get('listings'),list) or not isinstance(data.get('purchases'),list):raise ValueError('Invalid data')
   if not isinstance(data.get('favorites',[]),list):data['favorites']=[]
   data.setdefault('favorites',[])
   if not isinstance(data.get('creator_progress'),dict):
    migrate_projects(data)
    try:
     MARKET_PATH.parent.mkdir(parents=True,exist_ok=True)
     tmp=MARKET_PATH.with_suffix('.tmp')
     tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
     tmp.replace(MARKET_PATH)
    except OSError:pass
   else:ensure_progress(data)
   return data
  except (OSError,ValueError,TypeError):return default
 def save_market_state(self):
  MARKET_PATH.parent.mkdir(parents=True,exist_ok=True)
  temp=MARKET_PATH.with_suffix('.tmp');temp.write_text(json.dumps(self.market_state,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(MARKET_PATH)
  self.sync_my_ranking()
 def market(self):
  self.render_ads('market');self.market_render();self.pages.setCurrentWidget(self.market_page);self.mark(6)
 def market_render(self,*args):
  progress=ensure_progress(self.market_state)
  self.market_balance.setText(f"💎  {self.market_state['balance']} MVC (demo)   ·   🏆 Lv {level_of(progress['xp'])}  {rank_of(level_of(progress['xp']))['name']}")
  while self.market_items.count():
   item=self.market_items.takeAt(0)
   if item.widget():item.widget().deleteLater()
  for category,b in self.market_category_buttons:
   b.setProperty('active',category==self.market_active_category);b.style().unpolish(b);b.style().polish(b)
  purchases={p.get('id') for p in self.market_state['purchases'] if isinstance(p,dict)}
  offers=find_offers(self.market_state['listings'], query=self.market_search.text(),
     category=self.market_active_category, price_mode=self.market_price_filter.currentText(),
     style=self.market_style.currentText(),fmt=self.market_format_filter.currentText(),
     sort=self.market_sort.currentText())
  visible=offers[:self.market_visible_limit]
  self.market_more.setVisible(len(offers)>len(visible))
  self.market_counter.setText(f'Znaleziono: {len(offers)} • Wyświetlono: {len(visible)} • Reset filtrów poniżej')
  for i,listing in enumerate(visible):
   title=str(listing.get('title',''))[:80];category=str(listing.get('category',''));price=listing.get('price',0);currency=listing.get('currency','MVC')
   panel=QFrame();panel.setObjectName('card');panel.setMinimumWidth(190);v=QVBoxLayout(panel);v.setContentsMargins(9,9,9,11);v.setSpacing(7)
   picture=QLabel();picture.setFixedHeight(126);picture.setAlignment(Qt.AlignCenter)
   path=str(listing.get('image',''))
   if path:
    pix=self.market_pixmap(path)
    if pix is not None:picture.setPixmap(pix)
   if picture.pixmap() is None or picture.pixmap().isNull():
    symbol=str(listing.get('icon') or CATEGORY_ICONS.get(category,'✦'))
    picture.setText(symbol);picture.setStyleSheet('background:#283553;border-radius:12px;font-size:47px;color:#dbcaff')
   # Small original pixel avatar in each tile, not a remote player skin.
   head=QLabel(panel);head.setFixedSize(33,33)
   pic=BASE/'tile_heads'/('head_'+str(sum(map(ord,title))%9)+'.png')
   if pic.exists():head.setPixmap(QPixmap(str(pic)).scaled(32,32,Qt.KeepAspectRatio,Qt.FastTransformation))
   v.addWidget(head)
   v.addWidget(picture)
   v.addWidget(text(title,15,True));v.addWidget(text(category+'  •  '+str(listing.get('author','Twórca'))[:35],10,muted=True))
   if listing.get('style') and category=='Budowle':v.addWidget(text('Styl: '+str(listing['style']),10,muted=True))
   if category in MODEL_CATEGORIES:
    v.addWidget(text('Format: '+str(listing.get('asset_format') or 'brak')+'  •  '+str(listing.get('model_version') or category),10,muted=True))
   v.addWidget(text(str(listing.get('description',''))[:110],11))
   price_label='DARMOWE' if price==0 else (str(price)+' MVC' if currency=='MVC' else f'{price} PLN • podgląd')
   v.addWidget(text(price_label,14,True))
   owned=listing.get('id') in purchases
   if currency=='PLN' and price>0:
    button=btn('Płatności niedostępne',lambda:None);button.setEnabled(False)
   else:
    button=btn('✓ W bibliotece' if owned else ('Dodaj za darmo' if price==0 else 'Kup testowo'),lambda checked=False,x=listing:self.market_buy(x),not owned);button.setEnabled(not owned)
   actions=QHBoxLayout();actions.setSpacing(4)
   actions.addWidget(btn('Szczegóły',lambda checked=False,x=listing:self.market_details(x)))
   fav=listing.get('id') in self.market_state['favorites']
   actions.addWidget(btn('♥' if fav else '♡',lambda checked=False,x=listing:self.market_toggle_favorite(x)))
   v.addLayout(actions);v.addWidget(button);self.market_items.addWidget(panel,i//2,i%2)
  if not offers:self.market_items.addWidget(text('Brak ofert dla wybranych filtrów.',14,muted=True),0,0)
 def market_buy(self,listing):
  price=listing['price'];title=listing['title']
  if any(p.get('id')==listing['id'] for p in self.market_state['purchases']):return
  if price>self.market_state['balance']:
   QMessageBox.warning(self,'MineCoins','Brak wystarczającej liczby testowych MVC.');return
  if QMessageBox.question(self,'Zakup demonstracyjny',f'Czy dodać „{title}” do testowej biblioteki za {price} MVC?\n\nNie zostaną pobrane żadne pliki.')!=QMessageBox.Yes:return
  self.market_state['balance']-=price
  self.market_state['purchases'].append({'id':listing['id'],'title':title,'price':price,'date':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')})
  try:self.save_market_state()
  except OSError as exc:
   self.market_state['balance']+=price;self.market_state['purchases'].pop();QMessageBox.critical(self,'Zapis zakupu',str(exc));return
  self.market_render();QMessageBox.information(self,'MineCoins','Zakup testowy zapisany w lokalnej bibliotece.')
 def market_history(self):
  records=self.market_state['purchases']
  content='\n'.join(f"{p.get('date','')}  •  {p.get('title','')}  •  {p.get('price',0)} MVC" for p in reversed(records)) or 'Nie masz jeszcze zakupów.'
  QMessageBox.information(self,'Historia zakupów MVC',content[:3500])
 def market_add_listing(self,default_category=None):
  dialog=QDialog(self);dialog.setWindowTitle('MINEVORA • Dodaj projekt / rig / model 3D');dialog.resize(760,800)
  root=QVBoxLayout(dialog);root.addWidget(text('＋  DODAJ PROJEKT DO MARKETPLACE',22,True))
  root.addWidget(text('Lokalna biblioteka demonstracyjna — pliki nie są udostępniane innym graczom.',11,muted=True))
  scroll=QScrollArea();scroll.setWidgetResizable(True);inner=QWidget();inside=QVBoxLayout(inner);form=QFormLayout();form.setSpacing(10);advanced_form=QFormLayout();advanced_form.setSpacing(10)
  title=QLineEdit();title.setMaxLength(80);title.setPlaceholderText('np. Fantasy Minecraft Rig');form.addRow('Nazwa:',title)
  author=QLineEdit();author.setMaxLength(40)
  known_nick=str(getattr(self,'chat_config',{}).get('name','')).strip()
  if known_nick:author.setText(known_nick[:40])
  form.addRow('Nick autora:',author)
  role=QComboBox();role.addItems(['Niepełnoletni — tylko darmowe','Dorosły — darmowe lub cena demo']);advanced_form.addRow('Typ twórcy:',role)
  category=QComboBox();category.addItems(list(CATEGORY_ICONS));form.addRow('Kategoria:',category)
  if isinstance(default_category,str) and default_category in CATEGORY_ICONS:category.setCurrentText(default_category)
  style=QComboBox();style.addItems(['Medieval','Modern','Fantasy','Wooden','Japanese','Steampunk','Starter','Inny']);advanced_form.addRow('Styl budowli:',style)
  icon=QComboBox();icon.addItems(ICON_OPTIONS);advanced_form.addRow('Ikona:',icon)
  version=QLineEdit();version.setPlaceholderText('np. Minecraft 1.21.4 (opcjonalnie)');advanced_form.addRow('Wersja Minecraft:',version)
  model_version=QLineEdit();model_version.setPlaceholderText('np. Blender 4.3 / Blockbench 4.12');advanced_form.addRow('Wersja narzędzia:',model_version)
  currency=QComboBox();currency.addItems(['Darmowe','MVC (testowe)','PLN (tylko podgląd)']);advanced_form.addRow('Rodzaj oferty:',currency)
  price=QSpinBox();price.setRange(0,1000000);price.setEnabled(False);advanced_form.addRow('Cena:',price)
  image_zone=AssetDropZone(lambda:'miniatura',thumbnail=True)
  form.addRow('Miniatura:',image_zone)
  description=QTextEdit();description.setPlaceholderText('Opisz model, kości riga, tekstury, sposób użycia…');description.setMaximumHeight(85);form.addRow('Opis:',description)
  tags=QLineEdit();tags.setPlaceholderText('np. minecraft, rig, animacje, postać');advanced_form.addRow('Tagi:',tags)
  def match_format(path):
   # Sugeruj prawidłową kategorię tylko dla formatów jednoznacznych.
   extension=path.suffix.lower()
   current=category.currentText()
   if extension=='.blend' and current not in ('Modele Blender','Rigi Minecraft'):
    category.setCurrentText('Modele Blender')
   elif extension=='.bbmodel' and current not in ('Modele Blockbench','Rigi Minecraft'):
    category.setCurrentText('Modele Blockbench')
   elif extension in ('.obj','.fbx','.glb','.gltf') and current not in MODEL_CATEGORIES:
    category.setCurrentText('Modele Blender')
   elif extension=='.json' and current not in MODEL_CATEGORIES:
    category.setCurrentText('Modele Blockbench')

  file_zone=AssetDropZone(category.currentText,before_validate=match_format)
  root.addWidget(file_zone)
  def autofill_name(path):
   if path and not title.text().strip():
    title.setText(Path(path).stem.replace('_',' ').replace('-',' ')[:80])
  file_zone.fileSelected.connect(autofill_name)
  license_field=QComboBox();license_field.addItems(['Własny projekt — posiadam prawa','CC0','CC BY 4.0','CC BY-SA 4.0','Inna (opisz w wymaganiach)']);advanced_form.addRow('Licencja:',license_field)
  flags=QWidget();flags_layout=QHBoxLayout(flags);flags_layout.setContentsMargins(0,0,0,0)
  rigged=QCheckBox('Kości / rig');animated=QCheckBox('Animacje');textured=QCheckBox('Tekstury')
  for widget in (rigged,animated,textured):flags_layout.addWidget(widget)
  advanced_form.addRow('Zawartość:',flags)
  requirements=QLineEdit();requirements.setPlaceholderText('np. Blender 4.x, Blockbench, resource pack');advanced_form.addRow('Wymagania:',requirements)
  hint=text('',11,muted=True)
  def sync(*unused):
   cat=category.currentText();is_model=cat in MODEL_CATEGORIES;minor=role.currentIndex()==0
   file_zone.refresh_category()
   if minor:currency.setCurrentIndex(0)
   currency.setEnabled(not minor);price.setEnabled(not minor and currency.currentIndex()!=0)
   if currency.currentIndex()==0:price.setValue(0)
   style.setEnabled(cat=='Budowle')
   model_version.setEnabled(is_model)
   for x in (rigged,animated,textured,license_field):x.setEnabled(is_model)
   if is_model:
    hint.setText('Wybierz plik: '+', '.join(accepted_suffixes(cat))+'. Projekt zostanie skopiowany do lokalnego katalogu MINEVORA.')
    if cat=='Rigi Minecraft':rigged.setChecked(True)
   else:hint.setText('Plik i miniatura są opcjonalne. Projekty nie są publikowane w internecie.')
  role.currentIndexChanged.connect(sync);currency.currentIndexChanged.connect(sync);category.currentIndexChanged.connect(sync);sync()
  inside.addLayout(form)
  extra_fields=QWidget();extra_layout=QVBoxLayout(extra_fields);extra_layout.setContentsMargins(0,0,0,0);extra_layout.addLayout(advanced_form)
  extra_fields.hide()
  inside.addWidget(btn('⚙ Dodatkowe informacje (opcjonalne) ▾',lambda checked=False:extra_fields.setVisible(not extra_fields.isVisible())))
  inside.addWidget(extra_fields)
  inside.addWidget(hint);inside.addWidget(text('Dodawaj tylko własne pliki lub pliki, do których masz uprawnienia. MINEVORA nie uruchamia modeli, skryptów ani dodatków z przesłanych plików.',10,muted=True))
  inside.addWidget(text('MVC to waluta testowa. Ceny PLN są wyłącznie podglądem bez płatności i wypłat.',10,muted=True))
  inside.addStretch();scroll.setWidget(inner);root.addWidget(scroll,1)
  buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Save).setText('Dodaj projekt lokalnie')
  def validate_before_closing():
   if not title.text().strip() or not author.text().strip():
    QMessageBox.warning(dialog,'Projekt','Podaj nazwę projektu i nick autora.');return
   cat=category.currentText()
   if cat in MODEL_CATEGORIES and not file_zone.path():
    QMessageBox.warning(dialog,'Brak pliku','Przeciągnij plik modelu do pola lub kliknij „Wybierz plik”.');return
   try:
    if file_zone.path():validate_asset(file_zone.path(),cat)
    if image_zone.path():validate_asset(image_zone.path(),'miniatura')
   except (ValueError,OSError) as exc:
    QMessageBox.warning(dialog,'Nieprawidłowy plik',str(exc));return
   dialog.accept()
  buttons.accepted.connect(validate_before_closing);buttons.rejected.connect(dialog.reject);root.addWidget(buttons)
  if dialog.exec()!=QDialog.Accepted:return
  if not title.text().strip() or not author.text().strip():
   QMessageBox.warning(self,'Projekt','Podaj nazwę projektu i nick autora.');return
  cat=category.currentText();is_model=cat in MODEL_CATEGORIES;chosen_file=file_zone.path()
  if is_model and not chosen_file:
   QMessageBox.warning(self,'Brak pliku','Rig lub model 3D wymaga wskazania pliku projektu.');return
  try:
   if chosen_file:validate_asset(chosen_file,cat)
   if image_zone.path():validate_asset(image_zone.path(),'miniatura')
  except (ValueError,OSError) as exc:
   QMessageBox.warning(self,'Nieprawidłowy plik',str(exc));return
  mode=currency.currentIndex();amount=price.value() if mode else 0;project_id=str(uuid4())
  listing={'id':project_id,'title':title.text().strip(),'category':cat,
   'style':style.currentText() if cat=='Budowle' else '',
   'description':description.toPlainText().strip()[:1000], 'price':amount,
   'currency':'PLN' if mode==2 else 'MVC','author':author.text().strip(),
   'icon':icon.currentText() if not is_model else CATEGORY_ICONS[cat], 'image':'',
   'mc_version':version.text().strip()[:30], 'tags':tags.text().strip()[:180],
   'file':'','original_filename':Path(chosen_file).name if chosen_file else '',
   'asset_format':Path(chosen_file).suffix.lower() if chosen_file else '',
   'model_version':model_version.text().strip()[:80] if is_model else '',
   'license':license_field.currentText() if is_model else '',
   'rigged':rigged.isChecked() if is_model else False,
   'animated':animated.isChecked() if is_model else False,
   'textured':textured.isChecked() if is_model else False,
   'requirements':requirements.text().strip()[:180], 'url':'','local_owner':True}
  try:
   stored=store_project_asset(project_id,chosen_file,image_zone.path(),cat)
   listing.update(stored)
  except (ValueError,OSError) as exc:
   QMessageBox.critical(self,'Zapis pliku','Nie udało się zapisać kopii projektu: '+str(exc));return
  previous=copy.deepcopy(self.market_state)
  previous_level=level_of(ensure_progress(previous)['xp'])
  self.market_state['listings'].append(listing)
  gained=award_project(self.market_state,listing)
  current_level=level_of(ensure_progress(self.market_state)['xp'])
  try:self.save_market_state()
  except OSError as exc:
   self.market_state=previous;remove_project_asset(project_id)
   QMessageBox.critical(self,'Zapis oferty',str(exc));return
  self.market_render();self.refresh_creator_page()
  info=(f'Projekt został dodany do lokalnego Marketplace.\n\n+{gained} XP twórcy!' if gained
        else 'Projekt zapisany. XP za taką samą nazwę i kategorię już przyznano.')
  if gained and current_level>previous_level and self.prefs.get('rank_animations',True):
   self.statusBar().showMessage(f'Dodano projekt: +{gained} XP • Poziom {current_level}',8000)
   self.show_creator_ascension(previous_level,current_level)
  else:QMessageBox.information(self,'Marketplace',info)
 def market_toggle_favorite(self,listing):
  favorites=self.market_state.setdefault('favorites',[])
  ident=listing.get('id')
  if ident in favorites:favorites.remove(ident)
  else:favorites.append(ident)
  try:self.save_market_state()
  except OSError as exc:QMessageBox.warning(self,'Ulubione',str(exc))
  self.market_render()
 def market_details(self,listing):
  dialog=QDialog(self);dialog.setWindowTitle('Projekt • '+str(listing.get('title','')));dialog.resize(680,680)
  root=QVBoxLayout(dialog);root.setSpacing(12)
  image=QLabel();image.setAlignment(Qt.AlignCenter);image.setFixedHeight(205)
  path=str(listing.get('image',''))
  if path and Path(path).is_file():
   pix=QPixmap(path)
   if not pix.isNull():image.setPixmap(pix.scaled(610,205,Qt.KeepAspectRatio,Qt.SmoothTransformation))
  if image.pixmap() is None or image.pixmap().isNull():
   image.setText(str(listing.get('icon') or CATEGORY_ICONS.get(listing.get('category'),'✦')))
   image.setStyleSheet('background:#253554;border-radius:15px;font-size:70px')
  root.addWidget(image)
  root.addWidget(text(str(listing.get('title','')),24,True))
  price=listing.get('price',0);currency=listing.get('currency','MVC')
  root.addWidget(text(('DARMOWE' if not price else f'{price} {currency}'+(' • wyłącznie podgląd' if currency=='PLN' else ' • demo')),17,True))
  root.addWidget(text('Autor: '+str(listing.get('author','?'))+'  •  '+str(listing.get('category',''))+'  •  '+str(listing.get('style','')),12,muted=True))
  root.addWidget(text('Minecraft: '+str(listing.get('mc_version') or 'Nie podano')+'  |  Wymagania: '+str(listing.get('requirements') or 'Nie podano'),12))
  root.addWidget(text('Tagi: '+str(listing.get('tags') or 'Brak'),11,muted=True))
  if listing.get('category') in MODEL_CATEGORIES:
   details='Format: '+str(listing.get('asset_format') or 'Nieznany')+'  |  Narzędzie: '+str(listing.get('model_version') or 'Nie podano')
   root.addWidget(text(details,12,True))
   features=', '.join(name for name,enabled in [('Rig / kości',listing.get('rigged')),('Animacje',listing.get('animated')),('Tekstury',listing.get('textured'))] if enabled) or 'Bez oznaczonych dodatków'
   root.addWidget(text('Zawartość: '+features+'  |  Licencja: '+str(listing.get('license') or 'Nie podano'),11,muted=True))
  desc=QTextEdit();desc.setReadOnly(True);desc.setPlainText(str(listing.get('description','Brak opisu')));root.addWidget(desc,1)
  file_path=str(listing.get('file',''))
  if file_path:
   root.addWidget(text('Plik lokalny: '+str(listing.get('original_filename') or Path(file_path).name)+' (bez automatycznego uruchamiania i wysyłania)',11,muted=True))
   if listing.get('local_owner') and Path(file_path).is_file():
    root.addWidget(btn('📁  Otwórz folder projektu',lambda checked=False,f=file_path:QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(f).resolve().parent)))))
  buttons=QHBoxLayout();buttons.addWidget(btn('♡ / ♥  Ulubione',lambda checked=False:self.market_toggle_favorite(listing)))
  if listing.get('local_owner'):
   buttons.addWidget(btn('Usuń moją ofertę',lambda checked=False:self.market_delete_listing(listing,dialog)))
  if price==0 or currency=='MVC':
   buttons.addWidget(btn('Dodaj do biblioteki' if price==0 else 'Kup testowo',lambda checked=False:self.market_buy(listing),True))
  buttons.addWidget(btn('Zamknij',dialog.accept));root.addLayout(buttons)
  dialog.exec()
 def market_delete_listing(self,listing,dialog=None):
  if not listing.get('local_owner'):return
  if QMessageBox.question(self,'Usuń projekt','Usunąć tę lokalną ofertę?')!=QMessageBox.Yes:return
  original=list(self.market_state['listings'])
  self.market_state['listings']=[x for x in original if x.get('id')!=listing.get('id')]
  try:self.save_market_state()
  except OSError as exc:
   self.market_state['listings']=original;QMessageBox.warning(self,'Zapis',str(exc));return
  if dialog:dialog.accept()
  if listing.get('local_owner'):remove_project_asset(str(listing.get('id','')))
  self.market_render()
 def market_my_projects(self):
  offers=[x for x in self.market_state['listings'] if isinstance(x,dict) and x.get('local_owner')]
  dialog=QDialog(self);dialog.setWindowTitle('Moje projekty • lokalne');dialog.resize(550,450)
  layout=QVBoxLayout(dialog);layout.addWidget(text('MOJE PROJEKTY',22,True))
  layout.addWidget(text('Oferty zapisane na tym komputerze. Kliknij projekt, aby wyświetlić szczegóły.',11,muted=True))
  listing=QListWidget();layout.addWidget(listing,1)
  for x in offers:listing.addItem(str(x.get('title',''))+'  •  '+str(x.get('category','')))
  def open_selected(item):
   index=listing.row(item)
   if 0<=index<len(offers):self.market_details(offers[index]);dialog.accept()
  listing.itemDoubleClicked.connect(open_selected)
  layout.addWidget(btn('Zamknij',dialog.accept));dialog.exec()
 def market_library(self):
  dialog=QDialog(self);dialog.setWindowTitle('Moja biblioteka');dialog.resize(570,480)
  layout=QVBoxLayout(dialog);layout.addWidget(text('MOJA BIBLIOTEKA',22,True))
  tabs=QComboBox();tabs.addItems(['Zakupione / odebrane','Ulubione']);layout.addWidget(tabs)
  items=QListWidget();layout.addWidget(items,1)
  def fill():
   items.clear()
   ids=({p.get('id') for p in self.market_state['purchases'] if isinstance(p,dict)} if tabs.currentIndex()==0 else set(self.market_state.get('favorites',[])))
   for x in self.market_state['listings']:
    if isinstance(x,dict) and x.get('id') in ids:items.addItem(str(x.get('title',''))+'  •  '+str(x.get('category','')))
   if not items.count():items.addItem('Brak projektów w tej sekcji.')
  tabs.currentIndexChanged.connect(fill);fill()
  layout.addWidget(text('Biblioteka lokalna — brak udostępniania modeli innym osobom i pobierania plików.',11,muted=True))
  layout.addWidget(btn('Zamknij',dialog.accept));dialog.exec()
 def setup_chat(self):
  self.chat_view=ChatPlus(self.chat_panel)
  outer=QVBoxLayout(self.chat_panel);outer.setContentsMargins(0,0,0,0);outer.addWidget(self.chat_view)
  self.chat_view.stats.connect(self.chat_update_stats)
  self.chat_config=self.chat_view.config
  self.chat_input=self.chat_view.input
  self.chat_timer=self.chat_view.timer
  self.chat_total=0;self.chat_online=0
 def chat_update_stats(self,total,online,config):
  self.chat_total=total;self.chat_online=online;self.chat_config=config
  self.update_stats()
 def refresh_chat(self):
  self.chat_view.refresh()
 def setup_stats(self):
  self.stats_page=QWidget();layout=QVBoxLayout(self.stats_page);layout.setContentsMargins(30,26,30,26);layout.setSpacing(17)
  layout.addWidget(text('◉  KRONIKI PODRÓŻNIKA',29,True))
  layout.addWidget(text('Statystyki z lokalnego czatu MINEVORA • dane demonstracyjne i bieżące liczniki serwera',12,muted=True))
  self.stats_name=text('Podróżnik bez nicku',19,True);layout.addWidget(self.stats_name)
  grid=QGridLayout();grid.setSpacing(16);self.stats_values={}
  for i,(key,title) in enumerate([('messages','WIADOMOŚCI NA SERWERZE'),('online','AKTYWNI OSTATNIO'),('country','TWÓJ KRAJ'),('version','WYBRANA WERSJA')]):
   frame=QFrame();frame.setObjectName('stats');v=QVBoxLayout(frame);v.setContentsMargins(23,23,23,23)
   v.addWidget(text(title,11,True,True));value=text('—',23,True);v.addWidget(value);self.stats_values[key]=value
   grid.addWidget(frame,i//2,i%2)
  layout.addLayout(grid)
  layout.addWidget(text('Liczniki wiadomości i aktywnych pochodzą z serwera czatu. Nie są to statystyki osobiste, a czas gry nie jest jeszcze rejestrowany.',12,muted=True))
  layout.addStretch();self.pages.addWidget(self.stats_page);self.update_stats()
 def update_stats(self):
  if not hasattr(self,'stats_values'):return
  self.stats_values['messages'].setText(str(getattr(self,'chat_total',0)))
  self.stats_values['online'].setText(str(getattr(self,'chat_online',0)))
  country=self.chat_config.get('country','Nie wybrano')
  self.stats_values['country'].setText(FLAGS.get(country,'🌍')+' '+country)
  self.stats_values['version'].setText(str(self.current_version or 'Brak'))
  self.stats_name.setText('✧  '+self.chat_config.get('name','Podróżnik bez nicku'))
 def stats(self):
  self.update_stats();self.pages.setCurrentWidget(self.stats_page);self.mark(8)
 def save_chat_settings(self):
  self.chat_view.edit_profile()
 def send_chat(self):
  self.chat_view.send()
 def highlight_nav(self,target):
  """Mark a real sidebar destination; keep every other item deactivated."""
  previous=getattr(self,'_nav_active',None)
  if previous==target:return
  for i in {previous,target}:
   if i is None or i<0 or i>=len(self.nav):continue
   button=self.nav[i]
   button.setProperty('active',i==target)
   button.style().unpolish(button)
   button.style().polish(button)
  self._nav_active=target

 def mark(self,index):
  target=5 if index==100 else navigation_group(index)
  if index!=100 and 4<=target<=9:target+=2
  elif target==3:target=4
  self.highlight_nav(target)
 def toggle_maximize(self):
  if self.isMaximized():self.showNormal()
  else:self.showMaximized()

 def eventFilter(self,obj,event):
  return super().eventFilter(obj,event)

 def on_reference_page_changed(self,index):
  # Native dashboard needs no image overlay; preserve callback compatibility.
  if index==0 and hasattr(self,'enchanted_dashboard'):
   self.enchanted_dashboard.update_state()

 def update_enchanted_banner(self,index):
  """Apply one matching visual banner to all real, interactive pages."""
  if not hasattr(self,'enchanted_banner'):return
  sections={
   1:('GRAJ / WERSJE','Zarządzaj Minecraft Java, profilami i instalacjami.'),
  }
  named={
   'market_page':('MARKETPLACE','Mapy, budowle, pluginy i darmowe materiały.'),
   'pvp_hub':('PVP CENTER','Duels, Crystal PvP, trening i serwery PvP.'),
   'minigames_hub':('MINIGRY','BedWars, SkyWars, TNT Run i pozostałe tryby MINEVORA.'),
   'leaderboard_panel':('RANKING','Porównuj osiągnięcia i wyniki graczy.'),
   'discord_panel':('DISCORD • MINEVORA','Społeczność i status połączenia Discord.'),
   'together_panel':('MINEVORA TOGETHER','Graj ze znajomymi i zarządzaj sesjami.'),
   'server_catalog':('SERWERY MINECRAFT','Znajdź serwer i dołącz do gry.'),
   'stats_page':('TWOJE STATYSTYKI','Sprawdź aktywność oraz postępy.'),
   'ai_panel':('POMOC AI','Porady dotyczące launchera i Minecraft.'),
   'fairplay_panel':('FAIR PLAY','Ochrona konta i bezpieczna rozgrywka.'),
   'ads_hub':('OGŁOSZENIA','Najnowsze informacje społeczności MINEVORA.'),
   'skin_panel':('EDYTOR SKINÓW 3D','Maluj piksele, obracaj postać, eksportuj PNG i zarządzaj skinami.'),
   'mod_panel':('MODY I DODATKI','Modrinth, modpacki, tekstury, shadery i zależności modów.'),
   'settings_panel':('USTAWIENIA MINEVORA','Wygląd, język i konfiguracja wszystkich systemów.'),
  }
  for name,details in named.items():
   page=getattr(self,name,None)
   if page is not None and self.pages.indexOf(page)==index:
    sections[index]=details
    break
  title,desc=sections.get(index,('ODKRYWAJ MINEVORA','Jedno miejsce dla wszystkich funkcji launchera.'))
  self.enchanted_banner.set_section(title,desc)
  self.enchanted_banner.setVisible(index!=0 and self.pages.widget(index) is not getattr(self,'skin_panel',None))

 def focus_search(self):
  self.quick_search.setFocus()
  self.quick_search.selectAll()

 def minigames(self):
  self.pages.setCurrentWidget(self.minigames_hub)
  self.mark(100)

 def home(self):
  self.render_ads('home');self.pages.setCurrentIndex(0);self.mark(0)
  if hasattr(self,'enchanted_dashboard'):
   self.enchanted_dashboard.update_state()

 def instances(self):self.refresh();self.pages.setCurrentIndex(1);self.mark(1)
 def refresh(self):
  root=Path(os.environ.get('APPDATA',str(Path.home())))/'.minecraft'/'versions';versions=[]
  if root.exists():versions=sorted((p.name for p in root.iterdir() if p.is_dir() and (p/(p.name+'.json')).exists()),key=version_sort_key,reverse=True)
  if self.active_profile:
   self.current_version=self.active_profile['version']
  elif self.current_version not in versions:
   self.current_version=versions[0] if versions else None
  self.selected.setText((self.active_profile['name']+' • '+self.current_version) if self.active_profile else (self.current_version or 'Brak zainstalowanych wersji'))
  self.selected.setToolTip(self.current_version or '')
  self.update_stats();self.update_home_state()
  profiles=load_profiles()
  signature=(tuple(versions),tuple((str(p.get('id','')),str(p.get('name','')),str(p.get('version','')),str(p.get('game_dir',''))) for p in profiles))
  if signature==getattr(self,'_instance_signature',None):return
  self._instance_signature=signature
  while self.instance_list.count():
   it=self.instance_list.takeAt(0)
   if it.widget():it.widget().deleteLater()
  for profile in profiles:
   self.instance_list.addWidget(card(profile['name'],f"Profil • Minecraft {profile['version']}",lambda checked=False,p=profile:self.choose_profile(p),'WYBIERZ PROFIL'))
  for v in versions:self.instance_list.addWidget(card(v,'Minecraft Java • zainstalowana wersja',lambda checked=False,version=v:self.choose_version(version),'WYBIERZ'))
  if not versions and not profiles:self.instance_list.addWidget(text('Nie wykryto wersji w .minecraft. Zainstaluj wersję przez narzędzia launchera.',13,muted=True))
 def modloader_profile(self,version):
  """Auto-create separate mods/config folders for installed modded versions."""
  import re as _re
  match=_re.search(r'(?:fabric|forge|neoforge|quilt)',str(version),_re.I)
  if not match:return None
  for profile in load_profiles():
   if profile.get('version')==version:return profile
  loader=match.group().title()
  # Keep the profile name under 40 chars, avoiding collisions with user profiles.
  name=('MINEVORA '+loader+' '+str(version))[:40]
  existing={str(p['name']).casefold() for p in load_profiles()}
  if name.casefold() in existing:
   name=('MINEVORA '+loader+' '+str(uuid4().hex[:7]))[:40]
  try:return create_profile(name,version)
  except (OSError,ValueError,KeyError) as exc:
   self.statusBar().showMessage('Profil: '+str(exc),9000)
   return None

 def choose_version(self,version):
  matched=self.modloader_profile(version)
  if matched:
   self.choose_profile(matched)
   return
  self.active_profile=None
  self.current_version=version
  self.selected.setText(version);self.update_home_state()
  QMessageBox.information(self,'MINEVORA',f'Wybrano wersję: {version}')
 def add_profile(self):
  name,ok=QInputDialog.getText(self,'Nowy profil Minecraft','Nazwa profilu:')
  if not ok or not name.strip():return
  root=Path(os.environ.get('APPDATA',str(Path.home())))/'.minecraft'/'versions'
  versions=sorted([p.name for p in root.iterdir() if p.is_dir() and (p/(p.name+'.json')).exists()],key=version_sort_key,reverse=True) if root.exists() else []
  if not versions:
   QMessageBox.warning(self,'MINEVORA','Najpierw zainstaluj wersję Minecraft.');return
  default=versions.index(self.current_version) if self.current_version in versions else 0
  version,ok=QInputDialog.getItem(self,'Nowy profil Minecraft','Wersja Minecraft:',versions,default,False)
  if not ok:return
  try:profile=create_profile(name,version)
  except (ValueError,OSError,KeyError) as exc:
   QMessageBox.warning(self,'Błąd profilu',str(exc));return
  self.choose_profile(profile)
  self.instances()
  QMessageBox.information(self,'MINEVORA',f"Utworzono profil: {profile['name']}")
 def choose_profile(self,profile):
  self.active_profile=profile
  self.current_version=profile['version']
  self.selected.setText(f"{profile['name']} • {profile['version']}")
  self.selected.setToolTip(profile['game_dir']);self.update_home_state()
 def login(self):
  if self.login_worker and self.login_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Logowanie już trwa.');return
  cid=client_id()
  if not cid:
   cid,ok=QInputDialog.getText(self,'Microsoft','Podaj Microsoft Application (Client) ID\nRedirect URI: http://localhost:8765/callback',QLineEdit.Normal)
   if not ok:return
   try:save_client_id(cid.strip())
   except Exception as exc:QMessageBox.warning(self,'Client ID',str(exc));return
  self.login_worker=LoginWorker(cid)
  self.login_worker.status.connect(lambda msg:self.statusBar().showMessage(msg))
  self.login_worker.done.connect(self.login_done)
  self.login_worker.error.connect(lambda msg:QMessageBox.critical(self,'Logowanie Microsoft',msg))
  self.login_worker.start()
 def login_done(self,session):
  if not isinstance(session,dict) or not all(session.get(x) for x in ('access_token','name','id')):
   self.session=None
   self.update_home_state()
   QMessageBox.critical(self,'Microsoft','Nie udało się potwierdzić sesji Minecraft. Sprawdź Client ID, aktualizację minecraft-launcher-lib i ponów logowanie.');return
  self.session=session
  self.sync_my_ranking()
  self.update_home_state()
  self.statusBar().showMessage('Zalogowano: '+str(session['name']))
  QMessageBox.information(self,'MINEVORA','Zalogowano: '+str(session['name']))
 def play(self):
  if self.oneclick_worker is not None and self.oneclick_worker.isRunning():
   self.statusBar().showMessage('Trwa instalacja ONE CLICK — Minecraft uruchomi się po zakończeniu.',10000);return
  if self.play_worker and self.play_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Minecraft jest już uruchomiony.');return
  if self.deps_worker and self.deps_worker.isRunning():
   self.statusBar().showMessage('Sprawdzam wymagane mody — nie uruchamiaj drugi raz.');return
  if not self.current_version:
   self.oneclick_play();return
  if not self.session:
   QMessageBox.information(self,'MINEVORA','Najpierw zaloguj się na konto Microsoft.')
   self.login();return
  ram=int(self.ram.currentText().split()[0])
  game_dir=(self.active_profile.get('game_dir') if isinstance(self.active_profile,dict) else None) or str(MC_DIR)
  version=str(self.current_version)
  if auto_pvp_enabled() or not __import__('minevora_pvp_auto').supports_hud(version):
   try:
    state,message=provision_pvp_hud(version,game_dir,alternate_dirs=(str(MC_DIR),))
    if state in ('ready','missing'):
     self.statusBar().showMessage(message,9000)
   except OSError as exc:
    QMessageBox.warning(self,'MINEVORA PvP HUD','Nie udało się automatycznie przygotować HUD: '+str(exc))
  if self.prefs.get('auto_install_missing_mods',True):
   mc_version,loader=detect_loader_and_version(version)
   # For vanilla Minecraft no mod loader can actually load JAR mods.
   if mc_version and loader and (Path(game_dir)/'mods').is_dir():
    self.pending_launch=(version,ram,dict(self.session),game_dir)
    self.deps_worker=AutoDependenciesWorker(game_dir,mc_version,loader,self)
    self.deps_worker.progress.connect(lambda msg:self.statusBar().showMessage(msg))
    self.deps_worker.done.connect(self.dependencies_ready)
    self.deps_worker.error.connect(self.dependencies_failed)
    self.deps_worker.start()
    self.statusBar().showMessage('MINEVORA sprawdza brakujące zależności modów…')
    return
  self.launch_minecraft(version,ram,dict(self.session),game_dir)
 def dependencies_ready(self,result):
  installed=result.get('installed',[])
  msg=('Installed required mods: ' if self.language=='en' else 'Zainstalowano wymagane mody: ')+str(len(installed))
  if result.get('unrecognized',0):
   msg+=(' • Unknown mods: ' if self.language=='en' else ' • Nieznane pliki: ')+str(result['unrecognized'])
  self.statusBar().showMessage(msg,10000)
  self.continue_launch()
 def dependencies_failed(self,message):
  QMessageBox.warning(self,'MINEVORA • Mody',('Automatic dependency check failed:\n' if self.language=='en' else 'Nie udało się automatycznie sprawdzić lub pobrać zależności:\n')+message)
  answer=QMessageBox.question(self,'MINEVORA',('Launch Minecraft anyway? Mods may not work.' if self.language=='en' else 'Uruchomić Minecraft mimo tego? Mody mogą nie działać.'),QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
  if answer==QMessageBox.Yes:self.continue_launch()
  else:self.pending_launch=None
 def continue_launch(self):
  launch=self.pending_launch
  self.pending_launch=None
  if launch and not (self.play_worker and self.play_worker.isRunning()):
   self.launch_minecraft(*launch)
 def launch_minecraft(self,version,ram,session,game_dir):
  self.play_worker=PlayWorker(version,ram,session,game_dir)
  self.play_worker.status.connect(lambda msg:self.statusBar().showMessage(msg))
  self.play_worker.error.connect(self.game_launch_failed)
  self.play_worker.finished_game.connect(self.game_finished)
  self.play_worker.start()
  self.update_home_state()
  self.session_started=time.monotonic()
  self._overlay_version=version
  self.discord_started=int(time.time())
  self.overlay_timer.start()
  self.update_overlay()
  self.discord_update()
 def feature_notice(self,title):
  QMessageBox.information(self,'MINEVORA 7.9',f'{title} — ta funkcja nie jest jeszcze przeniesiona do interfejsu Qt.\n\nNie jest wymagany plik minevora_4.py.')
 def together(self):
  self.together_panel.refresh_status()
  self.together_panel.refresh_screenshots()
  self.pages.setCurrentWidget(self.together_panel)
  self.mark(9)
 def on_workspace_changed(self,index):
  """Reclaim space from the chat on creative pages; restore it on exit."""
  panel=self.pages.widget(index)
  tool=panel in (self.skin_panel,self.mod_panel)
  if tool and self._workspace_prior_chat is None:
   self._workspace_prior_chat=self.chat_panel.isVisible()
   self.set_chat_visible(False,save=False)
  elif not tool and self._workspace_prior_chat is not None:
   was_visible=self._workspace_prior_chat
   self._workspace_prior_chat=None
   self.set_chat_visible(was_visible,save=False)
  if panel is self.skin_panel:
   self.skin_panel.restore_preview()
   self.skin_panel.refresh_account_status()
  QTimer.singleShot(0,lambda:apply_clear_icons(self))

 def modpack_profile_ready(self,profile):
  """Select successfully installed modpack's separate profile in launcher."""
  self.active_profile=profile
  self.current_version=profile['version']
  self._instance_signature=None
  self.refresh()
  self.statusBar().showMessage('Modpack gotowy: '+profile['name'],12000)

 def mods(self):
  """Modrinth catalog inside the launcher, using original installer callbacks."""
  try:
   self.mod_panel.mc_dir=str(self.active_profile.get('game_dir') if isinstance(self.active_profile,dict) else MC_DIR)
   self.mod_panel.language=self.language
   self.mod_panel.auto_dependencies=self.prefs.get('auto_install_missing_mods',True)
   import re as _re
   version=_re.search(r'\d+\.\d+(?:\.\d+)?',self.current_version or '')
   if version and self.mod_panel.version.text().strip()!=version.group():
    self.mod_panel.version.setText(version.group())
   self.pages.setCurrentWidget(self.mod_panel)
   self.highlight_nav(2)
  except Exception as exc:
   QMessageBox.warning(self,'Katalog modów',str(exc))

 def modpacks(self):
  self.mods()
  self.mod_panel.choose('Modpacki')

 def skins(self):
  """Skin Studio is a reusable page, never a separate QDialog window."""
  self.pages.setCurrentWidget(self.skin_panel)
  self.highlight_nav(3)

 def servers(self):self.render_ads('servers');self.pages.setCurrentWidget(self.server_catalog);self.mark(5)
 def chat(self):
  self.set_chat_visible(True);self.chat_input.setFocus();self.mark(7);self.refresh_chat()
 def save_local_pref(self, key, value):
  self.prefs[key]=value
  try:
   PREFS_PATH.parent.mkdir(parents=True,exist_ok=True)
   temp=PREFS_PATH.with_suffix('.tmp');temp.write_text(json.dumps(self.prefs,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(PREFS_PATH)
  except OSError as exc:QMessageBox.warning(self,'MINEVORA',str(exc))
 def quick_language_change(self,*_):
  language=self.language_quick.currentData()
  if language in ('pl','en'):
   self.language=language
   self.save_local_pref('language',language)
   self.apply_language()
 def apply_language(self):
  translate_widget_tree(self, self.language)
  self.update_home_state()
  if hasattr(self,'chat_toggle_button'):
   shown=self.chat_panel.isVisible()
   self.chat_toggle_button.setText(('☏ Hide chat' if shown else '☏ Show chat') if self.language=='en' else ('☏ Ukryj czat' if shown else '☏ Pokaż czat'))
  if hasattr(self,'hub_results'):self.filter_hub()
  self.setWindowTitle('MINEVORA 18.3 • ENCHANTED LAUNCHER')
 def mod_updates_dialog(self, mc_version=None, mod_loader=None):
  if self.game_active():
   QMessageBox.information(self,'MINEVORA','Zamknij Minecraft przed aktualizacją modów.' if self.language=='pl' else 'Close Minecraft before updating mods.');return
  dialog=ModUpdatesDialog(str(MC_DIR),self.current_version or '',self.language,
     prefs=self.prefs, save_pref=self.save_local_pref, game_running=self.game_active, parent=self)
  dialog.setStyleSheet(ENCHANTED_QSS)
  dialog.exec()
 def open_discord_tickets_tool(self):
  folder=BASE/'DISCORD_SETUP'
  if not folder.exists():
   QMessageBox.warning(self,'Discord','Brak folderu DISCORD_SETUP.');return
  QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
  QMessageBox.information(self,'Tickety Discord',
    'Uruchom INSTALUJ_TICKETY_I_REGULAMIN.bat (jeden raz), potem URUCHOM_BOTA_TICKETOW.bat.\n'
    'Bot musi działać stale, aby reagować na kliknięcia. Nie udostępniaj jego tokenu.')

 def open_discord_language_tool(self):
  folder=BASE/'DISCORD_SETUP'
  if folder.exists():
   QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
   QMessageBox.information(self,'Discord',('Uruchom ZMIEN_JEZYK_KANALOW.bat w otwartym folderze.\nBot wymaga uprawnienia Zarządzanie kanałami.\nZmiana nazw nie tłumaczy wiadomości.' if self.language=='pl' else
     'Run ZMIEN_JEZYK_KANALOW.bat in the opened folder.\nThe bot needs Manage Channels.\nRenaming does not translate messages.'))
  else:
   QMessageBox.warning(self,'Discord','Brak folderu DISCORD_SETUP.' if self.language=='pl' else 'DISCORD_SETUP folder is missing.')
 def apply_prefs(self):
  theme=self.prefs.get('theme','Fantasy')
  accent={'Fantasy':'#8554d9','Szmaragdowy':'#238a76','Niebieski':'#267fc0','Różowy':'#b74d95'}.get(theme,'#8554d9')
  scale=int(self.prefs.get('font_size',13))
  self.setStyleSheet(ENCHANTED_QSS+f"\nQWidget{{font-size:{scale}px}} QPushButton#nav[active='true']{{border-left:4px solid {accent}}}")
  if hasattr(self,'chat_timer'):
   self.chat_timer.setInterval(int(self.prefs.get('chat_interval',4))*1000)
  if hasattr(self,'hero'):
   self.hero.set_motion_mode(self.prefs.get('motion_mode','eco'),self.prefs.get('animations',True))
  if not self.prefs.get('animations',True) and getattr(self,'_transition_widget',None) is not None:
   self.finish_page_transition(self._transition_widget,self._transition_effect)
 def settings(self):
  self.highlight_nav(10)
  if hasattr(self,'settings_panel'):
   self.pages.setCurrentWidget(self.settings_panel)
   return
  dialog=QDialog(self);dialog.setWindowFlags(Qt.Widget);dialog.setWindowTitle('MINEVORA • Ustawienia');dialog.setMinimumSize(600,440)
  root=QVBoxLayout(dialog)
  settings_banner=EnchantedSectionBanner(dialog)
  settings_banner.set_section('USTAWIENIA MINEVORA','Wygląd, język, Discord, Minecraft i bezpieczeństwo.')
  # The main launcher already displays the Enchanted section banner.
  settings_banner.hide()
  dialog.setStyleSheet(ENCHANTED_QSS)
  tabs=QTabWidget();root.addWidget(tabs,1)
  basics=QWidget();bl=QVBoxLayout(basics);base_form=QFormLayout()
  language=QComboBox();language.addItem('Polski 🇵🇱','pl');language.addItem('English 🇬🇧','en');language.setCurrentIndex(1 if self.language=='en' else 0);base_form.addRow('Język:',language)
  theme=QComboBox();theme.addItems(['Fantasy','Szmaragdowy','Niebieski','Różowy']);theme.setCurrentText(self.prefs.get('theme','Fantasy'));base_form.addRow('Motyw:',theme)
  font=QSpinBox();font.setRange(11,18);font.setValue(int(self.prefs.get('font_size',13)));base_form.addRow('Tekst:',font)
  animations=QCheckBox('Włącz animacje portalu');animations.setChecked(bool(self.prefs.get('animations',True)));base_form.addRow('Animacje:',animations)
  motion=QComboBox();motion.addItem('Płynne • około 20 FPS','smooth');motion.addItem('Oszczędne • około 8 FPS','eco');motion.addItem('Wyłączone','off');motion.setCurrentIndex(['smooth','eco','off'].index(valid_motion_mode(self.prefs.get('motion_mode','eco'))));base_form.addRow('Płynność:',motion)
  chat_visible=QCheckBox('Pokaż czat po otwarciu launchera');chat_visible.setChecked(bool(self.prefs.get('chat_visible',False)));base_form.addRow('Czat:',chat_visible)
  hud_enabled=QCheckBox('Pokazuj nakładkę podczas gry');hud_enabled.setChecked(bool(self.prefs.get('hud_enabled',True)));base_form.addRow('HUD:',hud_enabled)
  bl.addLayout(base_form);bl.addStretch();tabs.addTab(basics,'Podstawowe')
  advanced=QWidget();al=QVBoxLayout(advanced);adv_form=QFormLayout()
  auto_deps=QCheckBox('Automatycznie instaluj brakujące zależności modów (Modrinth)')
  auto_deps.setChecked(bool(self.prefs.get('auto_install_missing_mods',True)))
  auto_deps.setToolTip('Przed grą i po instalacji moda; tylko wymagane biblioteki zgodne z Minecraft i loaderem.')
  adv_form.addRow('Mody:',auto_deps)
  chat=QSpinBox();chat.setRange(3,30);chat.setSuffix(' s');chat.setValue(int(self.prefs.get('chat_interval',4)));adv_form.addRow('Odświeżanie czatu:',chat)
  icon_style=QComboBox();icon_style.addItems(['Kolorowe ikony','Symbole fantasy']);icon_style.setCurrentText(self.prefs.get('icon_style','Kolorowe ikony'));adv_form.addRow('Ikony sklepu:',icon_style)
  al.addLayout(adv_form)
  al.addWidget(btn('Ustawienia HUD',self.overlay_settings_dialog))
  al.addWidget(btn('Discord Rich Presence',self.discord_page))
  al.addWidget(btn('Sprawdź aktualizacje modów',self.mod_updates_dialog))
  al.addWidget(btn('Diagnostyka i raport',self.show_logs))
  al.addWidget(btn('Utwórz kopię zapasową',self.open_backup_tool))
  al.addStretch();tabs.addTab(advanced,'Zaawansowane')
  controls=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel)
  controls.button(QDialogButtonBox.Save).setText('Zapisz ustawienia')
  controls.button(QDialogButtonBox.Cancel).setText('Anuluj')
  root.addWidget(controls)

  def save_settings():
    updated=dict(self.prefs)
    updated.update({'language':language.currentData(),'theme':theme.currentText(),'font_size':font.value(),
      'animations':animations.isChecked(),'motion_mode':motion.currentData(),'chat_visible':chat_visible.isChecked(),
      'hud_enabled':hud_enabled.isChecked(),'auto_mod_updates':False,
      'auto_install_missing_mods':auto_deps.isChecked(),
      'chat_interval':chat.value(),'icon_style':icon_style.currentText()})
    try:
     PREFS_PATH.parent.mkdir(parents=True,exist_ok=True)
     temp=PREFS_PATH.with_suffix('.tmp')
     temp.write_text(json.dumps(updated,ensure_ascii=False,indent=2),encoding='utf-8')
     temp.replace(PREFS_PATH)
    except OSError as exc:QMessageBox.warning(self,'Ustawienia',str(exc));return
    self.prefs=updated;self.language=updated['language']
    self.language_quick.blockSignals(True);self.language_quick.setCurrentIndex(1 if self.language=='en' else 0);self.language_quick.blockSignals(False)
    self.set_chat_visible(updated['chat_visible'],save=False)
    self.apply_prefs();self.apply_overlay_settings();self.apply_language()
    self.market_render();self.statusBar().showMessage('Ustawienia zapisane',5000)

  def cancel_changes():
   language.setCurrentIndex(1 if self.language=='en' else 0)
   theme.setCurrentText(self.prefs.get('theme','Fantasy'))
   font.setValue(int(self.prefs.get('font_size',13)))
   animations.setChecked(bool(self.prefs.get('animations',True)))
   motion.setCurrentIndex(['smooth','eco','off'].index(valid_motion_mode(self.prefs.get('motion_mode','eco'))))
   chat_visible.setChecked(bool(self.prefs.get('chat_visible',False)))
   hud_enabled.setChecked(bool(self.prefs.get('hud_enabled',True)))
   auto_deps.setChecked(bool(self.prefs.get('auto_install_missing_mods',True)))
   chat.setValue(int(self.prefs.get('chat_interval',4)))
   icon_style.setCurrentText(self.prefs.get('icon_style','Kolorowe ikony'))
   self.home()

  controls.accepted.connect(save_settings)
  controls.rejected.connect(cancel_changes)
  self.settings_panel=dialog
  self.pages.addWidget(self.settings_panel)
  self.pages.setCurrentWidget(self.settings_panel)
  QTimer.singleShot(0,lambda:apply_clear_icons(self))

 def show_logs(self):
  import platform, importlib.metadata
  dialog=QDialog(self);dialog.setWindowTitle('MINEVORA 10.9 • Diagnostyka');dialog.resize(640,520)
  v=QVBoxLayout(dialog);v.addWidget(text('🛠  CENTRUM DIAGNOSTYKI',22,True))
  data=[('System',platform.platform()),('Python',sys.version.split()[0]),('Folder launchera',str(BASE)),('Folder Minecraft',str(MC_DIR)),('Konto Microsoft','Zalogowano' if isinstance(self.session,dict) else 'Nie zalogowano'),('Wersja Minecraft',str(self.current_version or 'Nie wybrano'))]
  for pkg in ['PySide6','minecraft-launcher-lib','pypresence']:
   try: version=importlib.metadata.version(pkg)
   except importlib.metadata.PackageNotFoundError:version='Brak pakietu'
   data.append((pkg,version))
  report='MINEVORA 10.9 — Diagnostyka\n'+'\n'.join(f'{k}: {val}' for k,val in data)
  area=QTextEdit();area.setReadOnly(True);area.setPlainText(report);v.addWidget(area)
  v.addWidget(text('Raport nie zawiera tokenów, haseł ani identyfikatorów sesji.',11,muted=True))
  actions=QHBoxLayout()
  def save_report():
   filename,_=QFileDialog.getSaveFileName(dialog,'Zapisz raport','minevora_diagnostyka.txt','Pliki tekstowe (*.txt)')
   if filename:
    try:Path(filename).write_text(report,encoding='utf-8')
    except OSError as e:QMessageBox.warning(dialog,'Zapis',str(e))
  def backup_settings():
   filename,_=QFileDialog.getSaveFileName(dialog,'Eksport ustawień','minevora_ustawienia.json','JSON (*.json)')
   if filename:
    try:Path(filename).write_text(json.dumps(self.prefs,ensure_ascii=False,indent=2),encoding='utf-8')
    except OSError as e:QMessageBox.warning(dialog,'Eksport',str(e))
  actions.addWidget(btn('💾 Zapisz raport',save_report));actions.addWidget(btn('📦 Eksportuj ustawienia',backup_settings));actions.addWidget(btn('Zamknij',dialog.accept));v.addLayout(actions)
  dialog.exec()
 def oneclick_play(self):
  """Install only the selected release + loader; then start the same signed-in session."""
  if self.oneclick_worker is not None and self.oneclick_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Instalator ONE CLICK już działa.');return
  if self.play_worker is not None and self.play_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Minecraft jest już uruchomiony.');return
  if self.install_worker is not None and self.install_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Zakończ trwającą instalację.');return
  dialog=QDialog(self);dialog.setWindowTitle('MINEVORA 18.3 • ONE CLICK INSTALL');dialog.resize(560,440)
  root=QVBoxLayout(dialog);root.setSpacing(12)
  root.addWidget(text('✦  ZAINSTALUJ I GRAJ',23,True))
  root.addWidget(text('Wybierz wersję i loader. MINEVORA pobierze brakującą grę i biblioteki dopiero wtedy, gdy klikniesz GRAJ.',12,muted=True))
  loader_box=QComboBox()
  for title,kind in [('Minecraft bez modów','vanilla'),('Fabric','fabric'),('Forge','forge'),('NeoForge','neoforge'),('Quilt','quilt')]:loader_box.addItem(title,kind)
  root.addWidget(text('Rodzaj instalacji',12,True));root.addWidget(loader_box)
  version_box=QComboBox();version_box.setEditable(True)
  version_box.addItems(['1.21.1','1.20.1','1.19.4'])
  root.addWidget(text('Wersja Minecraft (możesz wpisać dowolną wspieraną)',12,True));root.addWidget(version_box)
  root.addWidget(text('Jeśli gra/loader są już zainstalowane, instalator użyje istniejącej wersji. Każdy loader otrzyma osobny profil i folder modów.',11,muted=True))
  info=text('PvP HUD: automatycznie tylko na zgodnym Fabric 1.21.1. Publiczna paczka musi zawierać skompilowany JAR, aby nowi gracze otrzymali go bez ręcznego wyboru.',11,muted=True)
  root.addWidget(info)
  help_row=QHBoxLayout();help_row.addWidget(btn('⚙ Lista wersji i loaderów',self.install_mod_loader));help_row.addStretch();root.addLayout(help_row)
  buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
  buttons.button(QDialogButtonBox.Ok).setText('▶  ZAINSTALUJ I GRAJ')
  buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);root.addWidget(buttons)
  loader_box.setCurrentIndex(1)
  version_box.setCurrentText('1.21.1')
  if dialog.exec()!=QDialog.Accepted:return
  loader=loader_box.currentData();version=version_box.currentText().strip()
  try:
   from minevora_oneclick_core import validate_choice
   loader,version=validate_choice(loader,version)
  except ValueError as exc:QMessageBox.warning(self,'ONE CLICK',str(exc));return
  self.oneclick_pending=True
  self.oneclick_worker=OneClickInstallWorker(loader,version)
  self.oneclick_worker.progress.connect(lambda message:self.statusBar().showMessage(message,15000))
  self._oneclick_result=None
  self.oneclick_worker.done.connect(lambda version,downloaded:setattr(self,'_oneclick_result',(version,downloaded)))
  self.oneclick_worker.error.connect(self.oneclick_failed)
  self.oneclick_worker.finished.connect(self.oneclick_finished)
  self.statusBar().showMessage(f'ONE CLICK: {loader} {version} — instalowanie…',15000)
  self.oneclick_worker.start()

 def oneclick_finished(self):
  result=getattr(self,'_oneclick_result',None)
  self._oneclick_result=None
  if result is not None:self.oneclick_ready(*result)

 def oneclick_ready(self,version,downloaded):
  self.oneclick_pending=False
  self.active_profile=None
  self.current_version=version
  profile=self.modloader_profile(version)
  if profile:self.active_profile=profile
  self._instance_signature=None;self.refresh()
  try:self.instances()
  except Exception:pass
  if not isinstance(self.session,dict) or not self.session.get('access_token'):
   QMessageBox.information(self,'MINEVORA • ONE CLICK',
     'Instalacja gotowa: '+version+'\nZaloguj się przez Microsoft, a następnie kliknij GRAJ.')
   return
  self.statusBar().showMessage('ONE CLICK: instalacja gotowa, uruchamianie '+version,9000)
  QTimer.singleShot(0,self.play)

 def oneclick_failed(self,message):
  self.oneclick_pending=False
  QMessageBox.warning(self,'MINEVORA • Instalacja jednym kliknięciem',
   'Instalacja nie powiodła się. Sprawdź połączenie, obsługę wybranej wersji i Javę.\n\n'+message)

 def install_mod_loader(self):
  """Integrated compatible-version selector for all supported mod loaders."""
  if getattr(self,'all_loaders_worker',None) is not None and self.all_loaders_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Trwa instalacja loaderów.');return
  if self.install_worker is not None and self.install_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Poczekaj na zakończenie instalacji.');return
  if self.play_worker is not None and self.play_worker.isRunning():
   QMessageBox.warning(self,'MINEVORA','Zamknij Minecraft przed instalacją loadera.');return
  dialog=QDialog(self);dialog.setWindowTitle('MINEVORA • Instalator modloaderów');dialog.resize(600,610)
  content=QVBoxLayout(dialog);content.setSpacing(10)
  content.addWidget(text('INSTALATOR FABRIC / FORGE / NEOFORGE / QUILT',21,True))
  content.addWidget(text('Wybierz loader i wspieraną wersję Minecraft. Lista pobierana jest na żywo. Nie wymagamy osobnego instalatora EXE.',12,muted=True))
  loader_row=QHBoxLayout();loader_row.addWidget(text('Modloader:',12,True))
  loader_box=QComboBox()
  for label,value in [('Fabric','fabric'),('Forge','forge'),('NeoForge','neoforge'),('Quilt','quilt')]:loader_box.addItem(label,value)
  loader_row.addWidget(loader_box,1);content.addLayout(loader_row)
  search=QLineEdit();search.setPlaceholderText('Szukaj Minecraft: np. 1.21.1, 1.20.1 lub 1.19.4');content.addWidget(search)
  snapshots=QCheckBox('Pokaż snapshoty / wersje testowe (jeżeli obsługiwane)');content.addWidget(snapshots)
  catalog_status=text('Pobieranie listy obsługiwanych wersji…',11,muted=True);content.addWidget(catalog_status)
  versions_list=QListWidget();content.addWidget(versions_list,1)
  content.addWidget(text('Uwaga: MINEVORA PvP HUD .jar zbudowano dla Fabric 1.21.1. Pozostałe wersje i loadery wymagają zgodnych z nimi modów.',11,muted=True))
  buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
  install_button=buttons.button(QDialogButtonBox.Ok);install_button.setText('Zainstaluj wybraną wersję');install_button.setEnabled(False)
  buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);content.addWidget(buttons)
  state={'all':[],'stable':[],'active':False}
  def render_list(*_):
   versions_list.clear()
   if not state['active']:
    install_button.setEnabled(False);return
   filtered=filter_loader_versions(state['all'],state['stable'],search.text(),snapshots.isChecked())
   for version in filtered:versions_list.addItem(version)
   if filtered:versions_list.setCurrentRow(0)
   install_button.setEnabled(bool(filtered))
   catalog_status.setText(f'Dostępnych wersji: {len(filtered)} • {loader_box.currentText()}')
  def on_catalog_done(all_versions,stable_versions):
   state.update(all=list(all_versions),stable=list(stable_versions),active=True)
   loader_box.setEnabled(True)
   render_list()
  def on_catalog_error(message):
   state['active']=False
   loader_box.setEnabled(True)
   versions_list.clear();install_button.setEnabled(False)
   catalog_status.setText('Nie udało się pobrać listy: '+message)
  def load_versions(*_):
   if getattr(self,'loader_catalog_worker',None) is not None and self.loader_catalog_worker.isRunning():return
   state.update(all=[],stable=[],active=False)
   loader_box.setEnabled(False);versions_list.clear();install_button.setEnabled(False)
   catalog_status.setText('Sprawdzanie wersji obsługiwanych przez '+loader_box.currentText()+'…')
   self.loader_catalog_worker=ModLoaderCatalogWorker(loader_box.currentData())
   self.loader_catalog_worker.done.connect(on_catalog_done)
   self.loader_catalog_worker.error.connect(on_catalog_error)
   self.loader_catalog_worker.start()
  loader_box.currentIndexChanged.connect(load_versions)
  search.textChanged.connect(render_list);snapshots.toggled.connect(render_list)
  versions_list.itemDoubleClicked.connect(lambda _:dialog.accept() if install_button.isEnabled() else None)
  QTimer.singleShot(0,load_versions)
  if dialog.exec()!=QDialog.Accepted or not versions_list.currentItem():return
  version=versions_list.currentItem().text();loader_id=loader_box.currentData()
  self.install_worker=ModLoaderInstallWorker(loader_id,version)
  self.install_worker.status.connect(lambda msg:self.statusBar().showMessage(msg))
  self.install_worker.error.connect(lambda message:self.mod_loader_install_failed(loader_id,version,message))
  self.install_worker.done.connect(self.installed)
  self.statusBar().showMessage('Instalacja '+loader_box.currentText()+' '+version+'…')
  self.install_worker.start()

 def install_all_loaders_for_version(self):
  """Opt-in: install all SUPPORTED loaders for one requested Minecraft version."""
  if self.install_worker is not None and self.install_worker.isRunning():
   QMessageBox.warning(self,'MINEVORA','Najpierw dokończ obecną instalację.');return
  if getattr(self,'all_loaders_worker',None) is not None and self.all_loaders_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Instalacja już trwa.');return
  selected=str(self.current_version or '')
  import re as _re
  match=_re.search(r'(?<!\d)(?:1\.\d+(?:\.\d+)?|26\.\d+(?:\.\d+)?)(?!\d)',selected)
  default=match.group() if match else '1.21.1'
  version,accepted=QInputDialog.getText(self,'MINEVORA • Wszystkie loadery',
   'Wpisz wersję Minecraft (np. 1.21.1):',QLineEdit.Normal,default)
  if not accepted or not version.strip():return
  version=version.strip()
  if not _re.fullmatch(r'[0-9]+\.[0-9]+(?:\.[0-9]+)?(?:-[A-Za-z0-9.]+)?',version):
   QMessageBox.warning(self,'MINEVORA','Podaj poprawny numer wersji Minecraft.');return
  answer=QMessageBox.question(self,'MINEVORA • Potwierdź instalację',
   'Zainstalować wszystkie DOSTĘPNE loadery dla Minecraft '+version+'?\n'
   'Nie każda wersja obsługuje wszystkie cztery. Instalacja pobierze pliki i może zająć dużo miejsca na dysku.\n'
   'Nie zostaną pobrane pozostałe wersje Minecraft.',
   QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
  if answer!=QMessageBox.Yes:return
  self.all_loaders_worker=AllLoadersForVersionWorker(version)
  self.all_loaders_worker.progress.connect(lambda message:self.statusBar().showMessage(message))
  def done(results):
   for loader_name,status in results:
    if status.startswith('OK: '):self.modloader_profile(status[4:].strip())
   self._instance_signature=None
   self.refresh()
   self.statusBar().showMessage('Zakończono instalację loaderów dla '+version,10000)
   QMessageBox.information(self,'MINEVORA • Wyniki instalacji',
    '\n'.join(name+': '+status for name,status in results))
  self.all_loaders_worker.done.connect(done)
  self.all_loaders_worker.start()

 def mod_loader_install_failed(self,loader_id,version,message):
  QMessageBox.critical(self,'MINEVORA • Błąd modloadera',
   f'Nie udało się zainstalować {loader_id.title()} dla Minecraft {version}.\n\n{message}\n\nSprawdź wersję, Javę i połączenie. Nie wyłączaj zabezpieczeń Windows.')

 def install_version(self):
  if getattr(self,'all_loaders_worker',None) is not None and self.all_loaders_worker.isRunning():
   QMessageBox.information(self,'MINEVORA','Trwa instalacja loaderów.');return
  if self.install_worker and self.install_worker.isRunning():
   QMessageBox.information(self,'Instalacja','Instalacja już trwa.');return
  if self.versions_worker and self.versions_worker.isRunning():return
  self.statusBar().showMessage('Pobieranie listy wersji Minecraft…')
  self.versions_worker=VersionsWorker()
  self.versions_worker.done.connect(self.pick_version)
  self.versions_worker.error.connect(lambda e:QMessageBox.critical(self,'Lista wersji',e))
  self.versions_worker.start()
 def pick_version(self,versions):
  if not versions:
   QMessageBox.warning(self,'MINEVORA','Nie pobrano żadnych wersji.');return
  dialog=QDialog(self);dialog.setWindowTitle('Instalacja Minecraft • wybierz wersję');dialog.resize(510,580)
  layout=QVBoxLayout(dialog);layout.addWidget(text('Wybierz wersję Minecraft Java',20,True))
  search=QLineEdit();search.setPlaceholderText('Szukaj, np. 1.21');layout.addWidget(search)
  show_snapshots=QCheckBox('Pokaż snapshoty');layout.addWidget(show_snapshots)
  items=QListWidget();layout.addWidget(items,1)
  def update_list():
   query=search.text().strip().lower();items.clear()
   for v,kind in versions:
    if not show_snapshots.isChecked() and kind!='release':continue
    if query in v.lower():items.addItem(v)
  search.textChanged.connect(update_list);show_snapshots.toggled.connect(update_list);update_list()
  buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
  buttons.button(QDialogButtonBox.Ok).setText('Instaluj wybraną wersję')
  buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject)
  items.itemDoubleClicked.connect(lambda _:dialog.accept());layout.addWidget(buttons)
  if dialog.exec()!=QDialog.Accepted or not items.currentItem():return
  version=items.currentItem().text()
  self.install_worker=InstallWorker(version)
  self.install_worker.status.connect(lambda msg:self.statusBar().showMessage(msg))
  self.install_worker.error.connect(lambda e:QMessageBox.critical(self,'Błąd instalacji',e))
  self.install_worker.done.connect(self.installed)
  self.statusBar().showMessage('Instalowanie Minecraft '+version+'…')
  self.install_worker.start()
 def open_backup_tool(self):
  import subprocess
  try:
   subprocess.Popen([sys.executable,str(BASE/'MINEVORA_BACKUP_RESTORE.py')],cwd=str(BASE))
   self.statusBar().showMessage('Uruchomiono MINEVORA Backup & Restore')
  except Exception as exc:
   QMessageBox.warning(self,'Kopia zapasowa',str(exc))
  self.mark(17)

 def closeEvent(self,event):
  if self.oneclick_worker is not None and self.oneclick_worker.isRunning():
   event.ignore();self.statusBar().showMessage('Trwa pobieranie ONE CLICK. Nie zamykaj programu w trakcie instalacji.',9000);return
  if hasattr(self,'mod_panel'):
   for worker_name in ('worker','deps_worker','install_worker','modpack_worker'):
    worker=getattr(self.mod_panel,worker_name,None)
    if worker is not None and worker.isRunning():
     event.ignore()
     self.statusBar().showMessage('Trwa wyszukiwanie lub instalacja Modrinth. Zakończ operację przed zamknięciem.',7000)
     return
   for worker in getattr(self.mod_panel,'icon_workers',[]):
    if worker.isRunning():
     event.ignore()
     self.statusBar().showMessage('Trwa pobieranie ikon Modrinth. Zamknij aplikację po zakończeniu.',7000)
     return
  if hasattr(self,'skin_panel'):
   worker=getattr(self.skin_panel,'skin_upload_worker',None)
   if worker is not None and worker.isRunning():
    event.ignore()
    self.statusBar().showMessage('Trwa aktualizacja skina Minecraft. Zaczekaj na wynik.',7000)
    return
  if self.deps_worker and self.deps_worker.isRunning():
   event.ignore();self.statusBar().showMessage('Trwa pobieranie modów. Zakończ instalację przed zamknięciem.');return
  if hasattr(self,'together_panel') and self.together_panel.worker and self.together_panel.worker.isRunning():
   event.ignore();self.statusBar().showMessage('Trwa instalacja Essential. Zakończ pobieranie przed zamknięciem.');return
  if hasattr(self,'hero'):self.hero.timer.stop()
  if hasattr(self,'overlay_timer'):self.overlay_timer.stop()
  if getattr(self,'_transition_anim',None):self._transition_anim.stop()
  if hasattr(self,'discord_rpc') and self.discord_rpc is not None:
   try:self.discord_rpc.clear();self.discord_rpc.close()
   except Exception:pass
   self.discord_rpc=None
  if hasattr(self,'chat_view'):self.chat_view.shutdown()
  if hasattr(self,'overlay'):self.overlay.hide()
  super().closeEvent(event)

 def installed(self,version):
  self.active_profile=None;self.current_version=version
  profile=self.modloader_profile(version)
  if profile:self.active_profile=profile
  self._instance_signature=None;self.refresh();self.instances()
  self.statusBar().showMessage('Zainstalowano Minecraft '+version)
  QMessageBox.information(self,'MINEVORA','Zainstalowano Minecraft '+version)

if __name__=='__main__':
 app=QApplication(sys.argv);app.setStyle('Fusion');w=Window();w.show();sys.exit(app.exec())
