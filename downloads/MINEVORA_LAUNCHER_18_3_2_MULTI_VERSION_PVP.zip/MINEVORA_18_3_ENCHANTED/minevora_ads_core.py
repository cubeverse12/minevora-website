"""Local-first MINEVORA advertisements prototype.

No remote accounts, payments, tracking or real moderator authentication.
"""
from __future__ import annotations

import json
import shutil
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
from uuid import uuid4
from ipaddress import ip_address

DATA_DIR = Path.home() / '.minevora'
ADS_PATH = DATA_DIR / 'ads_local.json'
ASSETS_DIR = DATA_DIR / 'ads_images'
SLOTS = {'Strona główna': 'home', 'Marketplace': 'market', 'Serwery': 'servers'}
TYPES = {'Własny baner': 'own', 'Sponsorowana': 'sponsored'}
ALLOWED_STATUSES = {'active', 'pending', 'rejected', 'paused'}
MAX_IMAGE_BYTES = 5 * 1024 * 1024


def default_data():
    return {'schema_version': 1, 'ads': [], 'events': []}


def load_data(path=ADS_PATH):
    try:
        raw = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError, UnicodeError):
        return default_data()
    if not isinstance(raw, dict) or not isinstance(raw.get('ads'), list):
        return default_data()
    data = default_data()
    for ad in raw['ads'][:500]:
        if not isinstance(ad, dict):
            continue
        if ad.get('type') not in ('own', 'sponsored') or ad.get('status') not in ALLOWED_STATUSES:
            continue
        if ad.get('slot') not in SLOTS.values():
            continue
        if not isinstance(ad.get('title'), str) or not isinstance(ad.get('id'), str) or not ad['id']:
            continue
        data['ads'].append(ad)
    events = raw.get('events', [])
    if isinstance(events, list):
        data['events'] = [e for e in events[-500:] if isinstance(e, dict)]
    return data


def save_data(data, path=ADS_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def validate_url(value):
    url = value.strip()
    if not url:
        return ''
    if len(url) > 1500 or any(ord(c) < 33 for c in url):
        raise ValueError('Niepoprawny link: spacje i znaki sterujące są niedozwolone.')
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Link reklamowy musi być adresem HTTPS bez danych logowania.')
    host = parsed.hostname.lower()
    if host in ('localhost',) or host.endswith(('.local', '.internal', '.localhost')):
        raise ValueError('Nie można reklamować lokalnych adresów.')
    try:
        addr = ip_address(host)
    except ValueError:
        if '.' not in host or host.startswith('.') or host.endswith('.'):
            raise ValueError('Link musi zawierać publiczną domenę internetową.')
    else:
        if not addr.is_global:
            raise ValueError('Nie można reklamować prywatnych adresów IP.')
    try:
        port = parsed.port
    except ValueError:
        raise ValueError('Niepoprawny port w adresie.')
    if port is not None and port != 443:
        raise ValueError('Dozwolone są wyłącznie standardowe połączenia HTTPS.')
    return url


def validate_day(value):
    if not value:
        return ''
    if not isinstance(value, str):
        raise ValueError('Nieprawidłowa data.')
    try:
        return date.fromisoformat(value).isoformat()
    except ValueError:
        raise ValueError('Data powinna być w formacie RRRR-MM-DD.')


def validate_campaign(*, title, description, advertiser, url, slot, kind, start='', end=''):
    title = title.strip()
    description = description.strip()
    advertiser = advertiser.strip()
    if not (3 <= len(title) <= 75):
        raise ValueError('Tytuł musi mieć od 3 do 75 znaków.')
    if not (3 <= len(description) <= 240):
        raise ValueError('Opis musi mieć od 3 do 240 znaków.')
    if not (2 <= len(advertiser) <= 70):
        raise ValueError('Podaj nazwę twórcy lub reklamodawcy (2–70 znaków).')
    if slot not in SLOTS.values() or kind not in ('own', 'sponsored'):
        raise ValueError('Nieobsługiwany typ kampanii lub miejsce wyświetlania.')
    start, end = validate_day(start), validate_day(end)
    if start and end and start > end:
        raise ValueError('Data końcowa nie może być wcześniejsza od początkowej.')
    return {'title': title, 'description': description, 'advertiser': advertiser,
            'url': validate_url(url), 'slot': slot, 'type': kind,
            'start': start, 'end': end}


def create_campaign(data, fields, image='', now=None):
    validated = validate_campaign(**fields)
    now = now or datetime.now(timezone.utc).isoformat()
    ad = {'id': uuid4().hex, **validated, 'image': str(image),
          'status': 'active' if validated['type'] == 'own' else 'pending',
          'created_at': now, 'impressions': 0, 'clicks': 0, 'moderation_note': ''}
    data['ads'].append(ad)
    data['events'].append({'at': now, 'id': ad['id'], 'action': 'created'})
    return ad


def change_status(data, ad_id, status, note=''):
    if status not in ('active', 'rejected', 'paused'):
        raise ValueError('Niepoprawny status kampanii.')
    match = next((a for a in data['ads'] if a.get('id') == ad_id), None)
    if not match:
        raise ValueError('Nie znaleziono reklamy.')
    match['status'] = status
    match['moderation_note'] = str(note)[:200]
    data['events'].append({'at': datetime.now(timezone.utc).isoformat(), 'id': ad_id,
                           'action': status})
    return match


def is_active(ad, today=None):
    if ad.get('status') != 'active':
        return False
    today = today or date.today().isoformat()
    return (not ad.get('start') or ad['start'] <= today) and (not ad.get('end') or ad['end'] >= today)


def ads_for_slot(data, slot, today=None):
    return sorted((a for a in data['ads'] if a.get('slot') == slot and is_active(a, today)),
                  key=lambda a: a.get('created_at', ''), reverse=True)


def record_event(data, ad_id, action):
    if action not in ('impression', 'click'):
        raise ValueError('Niepoprawna metryka.')
    ad = next((x for x in data['ads'] if x.get('id') == ad_id), None)
    if ad is None:
        raise ValueError('Brak reklamy.')
    key = 'impressions' if action == 'impression' else 'clicks'
    count = ad.get(key, 0)
    ad[key] = max(0, count if type(count) is int else 0) + 1


def store_image(source, assets_dir=ASSETS_DIR):
    """Copy a verified small PNG/JPEG/WEBP image into MINEVORA-owned directory."""
    from PIL import Image, UnidentifiedImageError
    src = Path(source)
    if not src.is_file() or src.is_symlink() or src.stat().st_size > MAX_IMAGE_BYTES:
        raise ValueError('Grafika musi być istniejącym plikiem o rozmiarze do 5 MB.')
    try:
        with Image.open(src) as image:
            if image.format not in ('PNG', 'JPEG', 'WEBP'):
                raise ValueError('Obsługiwane obrazy: PNG, JPG lub WebP.')
            image.verify()
        with Image.open(src) as image:
            if image.width < 100 or image.height < 60 or image.width > 8192 or image.height > 8192:
                raise ValueError('Grafika musi mieć od 100×60 do 8192×8192 px.')
            fmt = image.format
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError('Nie można odczytać obrazu lub plik jest uszkodzony.') from exc
    ext = {'PNG': '.png', 'JPEG': '.jpg', 'WEBP': '.webp'}[fmt]
    dst_dir = Path(assets_dir)
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / (uuid4().hex + ext)
    shutil.copyfile(src, dst)
    return str(dst)
