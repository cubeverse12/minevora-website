# MINEVORA 18.2 — PvP HUD z GitHuba jednym kliknięciem

To pełna zaktualizowana paczka na bazie MINEVORA 18.1 ONE CLICK INSTALL. Zachowuje pozostałe moduły launchera.

## Szybkie uruchomienie na Windows 11

1. Rozpakuj `MINEVORA_18_2_ENCHANTED`, np. do folderu Pobrane.
2. Uruchom `URUCHOM_MINEVORA.bat`. Jeżeli brakuje bibliotek, użyj `INSTALUJ_ZALEZNOSCI.bat`.
3. Otwórz `PvP Mod Menu` w launcherze.
4. Kliknij `POBIERZ I ZAINSTALUJ PVP HUD Z GITHUBA`.
5. Wybierz profil `Minecraft Java 1.21.1 + Fabric`, z dostępnym Fabric API.
6. Po zakończeniu instalacji uruchom Minecraft. Prawy Shift lub klawisz K otwiera menu HUD w dołączonej wersji 2.0.2.

**Ważne:** sprawdzana jest najnowsza publiczna publikacja GitHub Releases repozytorium `cubeverse12/minevora-pvp-hud.`. Sam ZIP w GitHub Actions nie jest równoważny publicznemu GitHub Release. Jeśli release nie istnieje lub nie ma połączenia, launcher używa dołączonego, sprawdzonego JAR 2.0.2 i informuje o tym w interfejsie. Jeśli pobranie narusza integralność, JAR nie będzie instalowany. Gdy dostępny release ma starszą wersję niż JAR w paczce, program nie cofa wersji.

Launcher nie zapisuje tokenów GitHub ani nie wymaga logowania do GitHuba. Pobiera tylko bezpośrednie pliki `.jar` z oficjalnego repozytorium, weryfikuje `fabric.mod.json`, klasę główną i — jeśli udostępniono — SHA256. Przed podmianą starego moda tworzy lokalną kopię zapasową.

## Aby przyszłe kompilacje z GitHub Actions były dostępne jednym kliknięciem

Repozytorium na GitHubie: `https://github.com/cubeverse12/minevora-pvp-hud.`

1. W tym repozytorium umieść plik z naszej paczki `GITHUB_DO_REPO/.github/workflows/publish-pvp-hud-release.yml` pod ścieżką `.github/workflows/publish-pvp-hud-release.yml` (np. przez Add file → Create new file). GitHub Actions w repo musi mieć prawo tworzyć Releases (Settings → Actions → General → Workflow permissions → Read and write permissions), a repo powinno być publiczne.
2. Ponownie uruchom dotychczasowe zadanie `Build MINEVORA PvP HUD` na gałęzi `main`.
3. Po sukcesie zadanie `Publish MINEVORA PvP HUD Release` utworzy publiczne GitHub Release z JAR i sumą SHA256.
4. Od tej chwili przycisk launchera będzie pobierał nowe wydanie bezpośrednio z GitHub Releases — w profilu Fabric 1.21.1.

Nie zamieniaj całej paczki ZIP na pojedynczy plik JSON; plik `fabric.mod.json` musi pozostać **wewnątrz** prawidłowego moda `.jar`.

## Naprawione błędy

- Identyfikator moda: **minevorapvphud**, a nie `minevora_pvp_hud`.
- Zaktualizowany JAR zastępuje także starszy, ale nadal poprawny JAR w `mods`.
- Automatyczne kopiowanie HUD między zgodnymi instancjami Fabric 1.21.1.
- Instalacja nowej wersji w tle interfejsu: bez blokowania okna MINEVORA.
- Dołączony do launchera sprawdzony JAR 2.0.2, z przypisaniem Right Shift i K.

## Testy

`python TESTY_AUTO_PVP.py`
`python TESTY_GITHUB_PVP_18_2.py`

Testy automatyczne sprawdzają identyfikator, migrację między profilami, brak cofania wersji, wymianę JAR, obsługę braku Release i odrzucanie nieprawidłowych modów. Wykonywane są bez internetu i bez uruchamiania Minecrafta. Uruchomienie GUI i gry na Windows 11 wymaga testu na komputerze gracza.
