"""MINEVORA PvP HUD: per-version Fabric provisioning with strict JAR validation.

Never treat a JAR built for 1.21.1 as compatible with arbitrary Minecraft versions.
Only matching verified builds, bundled or downloaded from GitHub Releases, install.
"""
from __future__ import annotations
import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

CACHE_DIR = Path.home()/'.minevora'/'pvp'
CACHE_JAR = CACHE_DIR/'minevora-pvp-hud-fabric-1.21.1.jar'  # legacy cache, kept for compatibility
SETTINGS_PATH = CACHE_DIR/'settings.json'
BUNDLED_JAR = Path(__file__).resolve().parent/'pvp_mods'/'minevora-pvp-hud-fabric-1.21.1.jar'
PREFIX = 'minevora-pvp-hud-'
MOD_ID='minevorapvphud'
MOD_CLASS='pl/minevora/pvphud/MinevoraPvpHud.class'
_VERSION_PATTERN=re.compile(r'(?<![0-9.])(?:1\.\d{1,2}(?:\.\d{1,2})?|26\.\d{1,2}(?:\.\d{1,2})?)(?![0-9.])')


def profile_target(version):
    """Return (loader, minecraft_version), or (None, None) for ambiguous ids."""
    v=str(version or '').lower()
    loaders=[name for name in ('fabric','neoforge','forge','quilt') if re.search(r'(?<![a-z])'+name+r'(?![a-z])',v)]
    if len(loaders)!=1:return None,None
    matches=_VERSION_PATTERN.findall(v)
    if not matches:return None,None
    # Avoid mistakenly treating loader versions such as 0.16.10 as game versions.
    return loaders[0],matches[-1]


def _manifest_mc(dep):
    """Accept only a single, explicitly declared Minecraft version."""
    if not isinstance(dep,str):return None
    value=dep.strip().removeprefix('~').removeprefix('=')
    return value if _VERSION_PATTERN.fullmatch(value) else None


def jar_minecraft_version(jar):
    try:
        p=Path(jar)
        if not p.is_file() or not 200 < p.stat().st_size <= 20_000_000:return None
        with zipfile.ZipFile(p) as z:
            if z.testzip() is not None or MOD_CLASS not in z.namelist():return None
            meta=json.loads(z.read('fabric.mod.json'))
        if not isinstance(meta,dict) or meta.get('id')!=MOD_ID or meta.get('environment')!='client':return None
        return _manifest_mc((meta.get('depends') or {}).get('minecraft'))
    except (OSError,ValueError,TypeError,KeyError,zipfile.BadZipFile):
        return None


def is_hud_jar(jar, minecraft_version=None):
    mc=jar_minecraft_version(jar)
    return bool(mc and (minecraft_version is None or mc==minecraft_version))


def version_cache(mc):
    if not _VERSION_PATTERN.fullmatch(str(mc or '')):raise ValueError('Niepoprawna wersja Minecrafta.')
    if mc=='1.21.1':return CACHE_JAR
    return CACHE_DIR/'versions'/mc/('minevora-pvp-hud-fabric-'+mc+'.jar')


def bundled_for(mc):
    return BUNDLED_JAR if mc=='1.21.1' else None


def available_jar(mc):
    candidate=version_cache(mc)
    if is_hud_jar(candidate,mc):return candidate
    bundle=bundled_for(mc)
    return bundle if bundle and is_hud_jar(bundle,mc) else None


def supports_hud(version):
    loader,mc=profile_target(version)
    return loader=='fabric' and bool(mc) and available_jar(mc) is not None


def read_auto_enabled():
    try:
        value=json.loads(SETTINGS_PATH.read_text(encoding='utf-8'))
        return bool(value.get('auto_enabled',True)) if isinstance(value,dict) else True
    except (OSError,ValueError,TypeError):return True


def set_auto_enabled(value):
    CACHE_DIR.mkdir(parents=True,exist_ok=True)
    SETTINGS_PATH.write_text(json.dumps({'auto_enabled':bool(value)},indent=2),encoding='utf-8')


def atomic_copy(source,dest):
    target=Path(dest);target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_name(target.name+'.minevora-tmp')
    try:
        shutil.copy2(source,temp)
        temp.replace(target)
    finally:
        if temp.exists():temp.unlink()


def cache_jar(source):
    mc=jar_minecraft_version(source)
    if not mc:raise ValueError('Nieprawidłowy JAR: wymagany mod MINEVORA Fabric z pojedynczą wersją gry.')
    path=version_cache(mc)
    if Path(source).resolve()!=path.resolve():atomic_copy(source,path)
    return path


def hud_files(mods):
    folder=Path(mods)
    if not folder.is_dir() or folder.is_symlink():return []
    return sorted(p for p in folder.iterdir() if p.is_file() and p.name.lower().startswith(PREFIX)
                  and (p.name.lower().endswith('.jar') or p.name.lower().endswith('.jar.disabled')))


def ensure_fabric_api(game_dir, *, version='1.21.1',progress=None):
    """Only install Fabric API for the explicit target version. Never mix releases."""
    from minevora_auto_dependencies import _get_json, _candidate_jar, _download_verified, DependencyError
    mods=Path(game_dir)/'mods'
    if mods.is_symlink() or Path(game_dir).is_symlink():raise DependencyError('Nieprawidłowa ścieżka Minecraft.')
    if not _VERSION_PATTERN.fullmatch(str(version)):
        raise DependencyError('Nieznana wersja Minecrafta.')
    if mods.is_dir():
        present=[p for p in mods.iterdir() if p.is_file() and p.name.lower().startswith('fabric-api-') and p.name.lower().endswith('.jar')]
        if present:return 'Fabric API już obecny; zweryfikuj zgodność z '+version+'.'
    versions=_get_json('/project/fabric-api/version',params={
        'loaders':json.dumps(['fabric']), 'game_versions':json.dumps([version]),'include_changelog':'false'})
    if not isinstance(versions,list) or not versions:raise DependencyError('Brak Fabric API dla '+version+'.')
    versions=[v for v in versions if 'fabric' in v.get('loaders',[]) and version in v.get('game_versions',[])]
    if not versions:raise DependencyError('Brak zgodnego Fabric API dla '+version+'.')
    item=_candidate_jar(next((v for v in versions if v.get('version_type')=='release'),versions[0]))
    if progress:progress('Pobieram Fabric API dla '+version+'…')
    mods.mkdir(parents=True,exist_ok=True)
    tmp=_download_verified(item,mods)
    destination=mods/item['filename']
    try:
        if destination.exists() or destination.is_symlink():
            raise DependencyError('Fabric API już istnieje: '+destination.name)
        tmp.replace(destination)
    finally:
        if tmp.exists():tmp.unlink()
    return 'Zainstalowano Fabric API dla '+version+'.'


def provision(version,game_dir,alternate_dirs=()):
    """Return state/message. Never install to incompatible Fabric/Forge profiles."""
    game=Path(game_dir)
    mods=game/'mods'
    if game.is_symlink() or mods.is_symlink():return ('error','Niebezpieczna ścieżka instancji Minecrafta.')
    loader,mc=profile_target(version)
    existing=hud_files(mods)
    if loader!='fabric' or not mc:
        disabled=0
        for p in existing:
            if p.suffix=='.jar' and is_hud_jar(p):
                p.rename(p.with_name(p.name+'.disabled'));disabled+=1
        return ('unsupported','Ten profil nie jest rozpoznanym profilem Fabric.' + (' Wyłączono niezgodny MINEVORA HUD.' if disabled else ''))
    # Automatically adopt a correctly versioned JAR from alternative instances if available.
    if not available_jar(mc):
        for folder in (mods,*(Path(d)/'mods' for d in alternate_dirs)):
            for candidate in hud_files(folder):
                if candidate.suffix=='.jar' and is_hud_jar(candidate,mc):
                    cache_jar(candidate);break
            if available_jar(mc):break
    jar=available_jar(mc)
    if jar is None:
        for p in existing:
            if p.suffix=='.jar' and is_hud_jar(p) and jar_minecraft_version(p)!=mc:
                p.rename(p.with_name(p.name+'.disabled'))
        return ('missing','Brak opublikowanego moda MINEVORA PvP HUD dla Fabric '+mc+'. Nie zainstalowano niezgodnego JAR.')
    if not mods.is_dir():mods.mkdir(parents=True,exist_ok=True)
    if mods.is_symlink():return ('error','Folder mods nie może być dowiązaniem symbolicznym.')
    dest=mods/('minevora-pvp-hud-fabric-'+mc+'.jar')
    source_digest=hashlib.sha256(jar.read_bytes()).digest()
    if not (is_hud_jar(dest,mc) and hashlib.sha256(dest.read_bytes()).digest()==source_digest):
        if dest.exists():
            if not is_hud_jar(dest):return ('error','Plik docelowy o tej nazwie nie jest modem MINEVORA; przerwano.')
            backup=CACHE_DIR/'backups'/('minevora-'+hashlib.sha256(dest.read_bytes()).hexdigest()[:16]+'.jar')
            if not backup.exists():atomic_copy(dest,backup)
        atomic_copy(jar,dest)
    for p in hud_files(mods):
        if p!=dest and p.suffix=='.jar' and is_hud_jar(p):
            p.rename(p.with_name(p.name+'.disabled'))
    return ('ready','Zainstalowano MINEVORA PvP HUD zgodny z Fabric '+mc+'.')
