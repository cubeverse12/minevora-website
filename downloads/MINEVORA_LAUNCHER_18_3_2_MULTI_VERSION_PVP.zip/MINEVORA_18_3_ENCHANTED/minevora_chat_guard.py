"""Heuristic MINEVORA Chat Guard Bot rules (standard library, no AI profiling).

Signals are narrow, explainable anti-spam checks. They do not assert that a user
is cheating or malicious. This module does not authenticate Minecraft users.
"""
import re
import unicodedata

DEFAULT_RULES = {
    'enabled': True,
    'max_messages': 5,
    'flood_seconds': 20,
    'repeat_seconds': 60,
    'max_repeats': 2,
    'max_mentions': 3,
    'caps_filter': True,
    'link_limit': 1,
    'blocked_phrases': [],
    'mute_after': 3,
    'mute_minutes': 10,
    'warning_window_minutes': 60,
}


def validate_rules(payload):
    if not isinstance(payload, dict):
        raise ValueError('Ustawienia bota muszą być obiektem')
    if set(payload) - set(DEFAULT_RULES):
        raise ValueError('Nieznane ustawienie bota')
    values = {**DEFAULT_RULES, **payload}
    if type(values['enabled']) is not bool or type(values['caps_filter']) is not bool:
        raise ValueError('Włączniki muszą być wartościami tak/nie')
    limits = {
        'max_messages': (3, 20), 'flood_seconds': (5, 120),
        'repeat_seconds': (10, 300), 'max_repeats': (1, 5),
        'max_mentions': (1, 15), 'link_limit': (0, 10),
        'mute_after': (2, 10), 'mute_minutes': (1, 1440),
        'warning_window_minutes': (10, 1440),
    }
    for key, (low, high) in limits.items():
        value = values[key]
        if type(value) is not int or not low <= value <= high:
            raise ValueError(f'{key}: dozwolone wartości {low}–{high}')
    phrases = values['blocked_phrases']
    if not isinstance(phrases, list) or len(phrases) > 50 or not all(
            isinstance(p, str) and 2 <= len(p.strip()) <= 40 and
            not any(ord(ch) < 32 for ch in p) for p in phrases):
        raise ValueError('Lista blokowanych fraz: maksymalnie 50 tekstów po 2–40 znaków')
    values['blocked_phrases'] = list(dict.fromkeys(p.strip().casefold() for p in phrases))
    return values


def normalized(text):
    # Normalize the text for duplicate detection, not for identifying authors.
    return ' '.join(unicodedata.normalize('NFKC', text).casefold().split())


def check_text(body, rules):
    """Return (rule_name, human-readable_reason) or None."""
    if not rules['enabled']:
        return None
    plain = normalized(body)
    for phrase in rules['blocked_phrases']:
        if phrase in plain:
            return 'blocked_phrase', 'Wiadomość zawiera frazę z listy moderacji'
    links = re.findall(r'(?i)(?:https?://|www\.|discord\.gg/|discord\.com/invite/|\b[a-z0-9-]+\.(?:com|pl|net|org|gg)/)', body)
    if len(links) > rules['link_limit']:
        return 'links', 'Zbyt wiele linków w jednej wiadomości'
    mentions = re.findall(r'(?<!\w)@[\w]{2,24}', body, flags=re.UNICODE)
    if len(mentions) > rules['max_mentions']:
        return 'mentions', 'Zbyt wiele oznaczeń użytkowników'
    letters = [c for c in body if c.isalpha()]
    if rules['caps_filter'] and len(letters) >= 16 and sum(ch.isupper() for ch in letters) / len(letters) >= .85:
        return 'caps', 'Nie pisz całych wiadomości wielkimi literami'
    if re.search(r'(.)\1{13,}', plain):
        return 'repeated_characters', 'Zbyt wiele powtórzonych znaków'
    return None


def check_history(body, history, rules):
    """history: accepted (text, unix_timestamp) messages, newest first."""
    if not rules['enabled']:
        return None
    if len(history) >= rules['max_messages'] - 1:
        return 'flood', 'Wysyłasz zbyt wiele wiadomości w krótkim czasie'
    same = sum(normalized(text) == normalized(body) for text, _ in history)
    if same >= rules['max_repeats']:
        return 'repeat', 'Nie wysyłaj wielokrotnie tej samej wiadomości'
    return None
