# MINEVORA PvP HUD — aktualizator wielu wersji Minecrafta

## Co obsługuje aktualna paczka

- **Fabric 1.21.1** — zawiera rzeczywiście skompilowany plik `minevora-pvp-hud-fabric-1.21.1.jar` (mod 2.0.5).
- **Pozostałe profile Fabric** — launcher potrafi wykryć wersję i zainstalować osobny plik zgodny z nią, ale dopiero **gdy opublikujesz rzeczywisty port moda dla tej wersji w GitHub Releases**.
- **Vanilla / Forge / NeoForge / Quilt** — brak kompilacji zgodnych z tymi loaderami; aplikacja nie kopiuje do nich moda Fabric.

Nie ma uniwersalnego JAR-a dla wszystkich wersji i loaderów. Mod dla 1.21.1 nie będzie automatycznie instalowany do 1.21.4.

## Instalacja

1. Rozpakuj paczkę launchera na Windows.
2. W razie potrzeby uruchom `INSTALUJ_ZALEZNOSCI.bat`.
3. Uruchom `URUCHOM_MINEVORA.bat`.
4. Wybierz właściwy profil Minecraft Java **Fabric**.
5. Otwórz **PvP Mod Menu** i kliknij **POBIERZ I ZAINSTALUJ PVP HUD Z GITHUBA**.
6. Jeśli istnieje wydanie zgodne z wybraną wersją, mod zostanie pobrany i zainstalowany. W przeciwnym razie zobaczysz informację o braku kompilacji.

Zachowano ograniczenia wersji wewnątrz `fabric.mod.json`, weryfikację identyfikatora moda, klas Java i kopię zapasową przy zastępowaniu starszej kompilacji.

## Jak publikować kolejne wersje

Najpierw faktycznie przenieś, skompiluj i przetestuj mod na nowej wersji gry. Do publicznego GitHub Release dodaj plik nazwany:

`minevora-pvp-hud-fabric-1.21.4.jar`

Dla każdej kolejnej wersji zmienia się numer (np. `1.20.1`, `1.21.8`). Nazwa pliku **i** pole `depends.minecraft` w jego `fabric.mod.json` muszą dokładnie wskazywać docelową wersję. Możesz dołączyć `*.jar.sha256`.

Aktualizator przegląda publiczne stabilne wydania: `https://github.com/cubeverse12/minevora-pvp-hud./releases`. Przy braku wydania nie pobierze niesprawdzonej kopii.

## Testy

`python -m unittest -v TESTY_MULTI_VERSION_PVP`

Testy są lokalne, nie łączą się z GitHub i nie wymagają uruchomienia Minecrafta.

## Ograniczenia

- Ten pakiet nie zawiera gotowych portów do innych Minecraftów ani do Forge/NeoForge.
- Tworzenie kolejnych wydanych plików `.jar` wymaga zgodnego API/mappingów, procesu Gradle i testu w grze.
- Nie uruchamiano programu na Windows; w tej paczce sprawdzono składnię i symulacje instalacji.
