"""MINEVORA public one-click setup.

Uses minecraft-launcher-lib and official version manifests. No Minecraft client or
third-party mod is bundled by this module. Network installers run outside the UI thread.
"""
import re
from pathlib import Path

LOADERS=('vanilla','fabric','forge','neoforge','quilt')
VERSION_RE=re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,75}$')

def validate_choice(loader,version):
    loader=str(loader).lower().strip()
    version=str(version).strip()
    if loader not in LOADERS:raise ValueError('Nieznany loader: '+loader)
    if not VERSION_RE.fullmatch(version) or version in ('.','..'):
        raise ValueError('Nieprawidłowy identyfikator wersji Minecraft.')
    return loader,version

def installed_json(mc_dir, version_id):
    if not VERSION_RE.fullmatch(str(version_id)) or str(version_id) in ('.','..'):
        return False
    root=Path(mc_dir)/'versions'/version_id
    path=root/(version_id+'.json')
    return path.is_file() and path.stat().st_size>2

def find_installed(mc_dir, loader,version):
    loader,version=validate_choice(loader,version)
    if loader=='vanilla':return version if installed_json(mc_dir,version) else None
    versions_dir=Path(mc_dir)/'versions'
    if not versions_dir.is_dir():return None
    # Match complete release number and loader token; never confuse 1.21.1 and 1.21.10.
    token=re.compile(r'(?<![A-Za-z0-9.])'+re.escape(version)+r'(?![A-Za-z0-9.])',re.I)
    loader_token=re.compile(r'(?<![a-z])'+re.escape(loader)+r'(?![a-z])',re.I)
    candidates=[]
    for folder in versions_dir.iterdir():
        if not folder.is_dir():continue
        name=folder.name
        if loader_token.search(name) and token.search(name) and installed_json(mc_dir,name):
            candidates.append(name)
    return sorted(candidates)[-1] if candidates else None

def install_selected(library,mc_dir,loader,version,notify=None):
    """Return (installed_id, was_installed). Never download unrelated versions."""
    loader,version=validate_choice(loader,version)
    notify=notify or (lambda message:None)
    root=Path(mc_dir)
    existing=find_installed(root,loader,version)
    if existing:
        notify('Wersja już jest zainstalowana: '+existing)
        return existing,False
    if loader=='vanilla':
        notify('Sprawdzanie oficjalnego katalogu Minecraft…')
        catalog=library.utils.get_version_list()
        if version not in {x['id'] for x in catalog if isinstance(x,dict) and isinstance(x.get('id'),str)}:
            raise ValueError('Wersji Minecraft '+version+' nie ma w oficjalnym katalogu.')
        root.mkdir(parents=True,exist_ok=True)
        notify('Pobieranie Minecraft '+version+'…')
        library.install.install_minecraft_version(version,str(root))
        installed=version
    else:
        notify('Sprawdzanie zgodności '+loader.title()+' z Minecraft '+version+'…')
        mod_loader=library.mod_loader.get_mod_loader(loader)
        if not mod_loader.is_minecraft_version_supported(version):
            raise ValueError(loader.title()+' nie obsługuje wersji '+version+'. Wybierz inną.')
        root.mkdir(parents=True,exist_ok=True)
        notify('Instalowanie '+loader.title()+' '+version+' (gra i wymagane biblioteki)…')
        installed=mod_loader.install(version,str(root))
    if not isinstance(installed,str) or not installed.strip() or not installed_json(root,installed.strip()):
        raise RuntimeError('Instalator nie potwierdził poprawnej instalacji '+loader+' '+version)
    notify('Instalacja gotowa: '+installed)
    return installed.strip(),True
